<?php
// Heading
$_['heading_title']                    = 'ADVisor - tema rosso';

// Text
$_['text_extension']                   = 'Estensioni';
$_['text_success']                     = 'Hai modificato il tema con successo!';
$_['text_edit']                        = 'Edita il tema ADVisor rosso';
$_['text_general']                     = 'Generale';
$_['text_product']                     = 'Prodotti';
$_['text_image']                       = 'Immagini';

// Entry
$_['entry_directory']                  = 'Directory del tema';
$_['entry_status']                     = 'Stato';
$_['entry_product_limit']              = 'Articoli per pagina di default';
$_['entry_product_description_length'] = 'Limite lunghezza descrizioni';
$_['entry_image_category']             = 'Dimensioni dell\'immagine delle categorie (L x H)';
$_['entry_image_thumb']                = 'Dimensioni dell\'immagine di anteprima articolo (L x H)';
$_['entry_image_popup']                = 'Dimensioni dell\'immagine popup (L x H)';
$_['entry_image_product']              = 'Dimensioni dell\'immagine articolo in lista (L x H)';
$_['entry_image_additional']           = 'Dimensioni dell\'immagine degli articoli aggiuntivi (L x H)';
$_['entry_image_related']              = 'Dimensione immagini articoli collegati (L x H)';
$_['entry_image_compare']              = 'Dimensione immagini articoli comparati (L x H)';
$_['entry_image_wishlist']             = 'Dimensione immagini articoli preferiti (L x H)';
$_['entry_image_cart']                 = 'Dimensione immagini articoli nel carrello(L x H)';
$_['entry_image_location']             = 'Dimensione immagini allocazione (L x H)';
$_['entry_width']                      = 'Larghezza';
$_['entry_height']                     = 'Altezza';

// Help
$_['help_directory']                   = 'Questo campo serve solo per consentire ai temi precedenti di essere compatibili con il nuovo sistema di temi. È possibile impostare la directory del tema da utilizzare sulle impostazioni della dimensione dell\'immagine definite qui.';
$_['help_product_limit']               = 'Determina quanti articoli del catalogo vengono mostrati per pagina (articoli, categorie, ecc.)';
$_['help_product_description_length']  = 'Nella visualizzazione elenco, limite di caratteri per la descrizione breve (categorie, speciali ecc.)';

// Error
$_['error_permission']                 = 'Attenzione: non sei autorizzato a modificare il tema ADVisor!';
$_['error_limit']                      = 'Il numero massimo di articoli per pagina è richiesto!';
$_['error_image_thumb']                = 'Dimensioni dell\'immagine di anteprima articolo è richiesto!';
$_['error_image_popup']                = 'Dimensioni dell\'immagine popup è richiesto!';
$_['error_image_product']              = 'Dimensioni dell\'immagine articolo in lista è richiesto!';
$_['error_image_category']             = 'Dimensioni dell\'immagine delle categorie è richiesto!';
$_['error_image_additional']           = 'Dimensioni dell\'immagine degli articoli aggiuntivi è richiesto!';
$_['error_image_related']              = 'Dimensione immagini articoli collegati è richiesto!';
$_['error_image_compare']              = 'Dimensione immagini articoli comparati è richiesto!';
$_['error_image_wishlist']             = 'Dimensione immagini articoli preferiti è richiesto!';
$_['error_image_cart']                 = 'Dimensione immagini articoli nel carrello è richiesto!';
$_['error_image_location']             = 'Dimensione immagini allocazione è richiesto!';