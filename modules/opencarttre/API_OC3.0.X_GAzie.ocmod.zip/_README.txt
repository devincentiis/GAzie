
******************** ATTENZIONE! **********************************************

1) Prima di poter accedere alle API si deve attivare la modification sul file "catalog/controller/startup/session.php" altrimenti di prende il token ma poi non lo si può usare. Per poterlo fare andare su Extensions->Modifications prima cliccare su "Clear" e poi "Refresh"