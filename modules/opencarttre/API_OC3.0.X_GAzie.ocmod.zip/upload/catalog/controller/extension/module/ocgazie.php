<?php
/*
 --------------------------------------------------------------------------
  GAzie - Gestione Azienda
  Copyright (C) 2004-present - Antonio De Vincentiis Montesilvano (PE)
  (https://www.devincentiis.it)
  <https://gazie.sourceforge.net>
  --------------------------------------------------------------------------
  Questo programma e` free software;   e` lecito redistribuirlo  e/o
  modificarlo secondo i  termini della Licenza Pubblica Generica GNU
  come e` pubblicata dalla Free Software Foundation; o la versione 2
  della licenza o (a propria scelta) una versione successiva.

  Questo programma  e` distribuito nella speranza  che sia utile, ma
  SENZA   ALCUNA GARANZIA; senza  neppure  la  garanzia implicita di
  NEGOZIABILITA` o di  APPLICABILITA` PER UN  PARTICOLARE SCOPO.  Si
  veda la Licenza Pubblica Generica GNU per avere maggiori dettagli.

  Ognuno dovrebbe avere   ricevuto una copia  della Licenza Pubblica
  Generica GNU insieme a   questo programma; in caso  contrario,  si
  scriva   alla   Free  Software Foundation, 51 Franklin Street,
  Fifth Floor Boston, MA 02110-1335 USA Stati Uniti.
  --------------------------------------------------------------------------
***

1) Sul file catalog/model/extension/module/ocgazie.php ci saranno tutte le funzioni per listare, aggiungere,eliminare, modificare i prodotti, quindi lo si deve ampliare : es. con la funzione "setItemQuantity"; $this->model_extension_module_ocgazie->setItemQuantity($product_id);

2) Nello scenario in cui il gestionale è installato dentro una LAN con connessione ad internet con IP dinamico si deve rimuovere dal file catalog/controller/api/login.php la condizione seguente:
	if (!in_array($this->request->server['REMOTE_ADDR'], $ip_data)) {
		$json['error']['ip'] = sprintf($this->language->get('error_ip'), $this->request->server['REMOTE_ADDR']);
	}
	
*/
class ControllerExtensionModuleOcgazie extends Controller
{
	public function okToken() {
		if (!isset($this->session->data['api_id'])) {
			$r=false;
		} else {
			$r=true;
		}
		$this->response->setOutput($r);
	}
	public function setupStore() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['store_id'])&&isset($this->request->post['data'])) {
				$this->load->model('extension/module/ocgazie');
				$this->model_extension_module_ocgazie->setupStore($this->request->post['store_id'],$this->request->post['data']);
				$json['Ocgazie'] = 'hai aggiornato gli archivi di base dello store ';
			} else {
				$json['error']['store'] = $this->language->get('error_store');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function setitemquantity() {
		$this->load->language('api/cart');

		$json = array();
			
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['product_id'])&&isset($this->request->post['quantity'])) {
				$this->load->model('extension/module/ocgazie');
				$this->model_extension_module_ocgazie->setItemQuantity($this->request->post['product_id'],$this->request->post['quantity']);
				$json['Ocgazie'] = 'hai aggiornato il prodotto id='.$this->request->post['product_id'].' con il nuovo valore '.$this->request->post['quantity'];
			} else {
				$json['error']['store'] = $this->language->get('error_store');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function upsertTaxRate() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['tax_rate_id'])&&isset($this->request->post['data'])) {
				$this->load->model('extension/module/ocgazie');
				$this->model_extension_module_ocgazie->upsertTaxRate($this->request->post['tax_rate_id'],$this->request->post['data']);
				$json['Ocgazie'] = 'hai aggiornato l\'aliquota IVA codice='.$this->request->post['tax_rate_id'].' con il nuovi valori ';
			} else {
				$json['error']['store'] = $this->language->get('error_store');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function setStockStatus() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['status'])) {
				$this->load->model('extension/module/ocgazie');
				$this->model_extension_module_ocgazie->setStockStatus();
				$json['Ocgazie'] = 'hai aggiornato le descrizioni degli stati di magazzino  ';
			} else {
				$json['error']['store'] = $this->language->get('error_store');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function setProductQuantity() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['product_id'])) {
				$this->load->model('extension/module/ocgazie');
				$this->model_extension_module_ocgazie->setProductQuantity($this->request->post['product_id'],$this->request->post['quantity']);
				$json['Ocgazie'] = 'hai aggiornato la quantità del prodotto  ID='.$this->request->post['product_id'].' '.$this->request->post['quantity'];
			} else {
				$json['error']['store'] = 'il prodotto ID='.$this->request->post['product_id'].'non è stato trovato!';
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function setGeoZone() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['gzone'])) {
				$this->load->model('extension/module/ocgazie');
				$this->model_extension_module_ocgazie->setGeoZone();
				$json['Ocgazie'] = 'hai aggiornato la descrizione della zona IVA Italia';
			} else {
				$json['error']['store'] = 'Non è stata aggiornata la geo_zone!';
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function setCustomField() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['customfield'])) {
				$this->load->model('extension/module/ocgazie');
				$this->model_extension_module_ocgazie->setCustomField();
				$json['Ocgazie'] = 'hai inserito i custom field per PI/CF';
			} else {
				$json['error']['store'] = 'Non sono stati inseriti i custom field per PI/CF!';
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function upsertCategory() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['category_id'])&&isset($this->request->post['data'])) {
				$this->load->model('extension/module/ocgazie');
				$json=$this->model_extension_module_ocgazie->upsertCategory($this->request->post['category_id'],$this->request->post['data']);
			} else {
				$json['error']['store'] = $this->language->get('error_store');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function upsertProduct() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['product_id'])&&isset($this->request->post['data'])) {
				$this->load->model('extension/module/ocgazie');
				$json=$this->model_extension_module_ocgazie->upsertProduct($this->request->post['product_id'],$this->request->post['data']);
			} else {
				$json['error']['store'] = 'il prodotto ID='.$this->request->post['product_id'].'non è stato trovato!';
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function getOrder() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['last_id'])) {
				$this->load->model('extension/module/ocgazie');
				$json= $this->model_extension_module_ocgazie->getOrder($this->request->post['last_id']);
			} else {
				$json['error']['store'] = 'non ho trovato ordini!';
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function getCustomers() {
		$this->load->language('api/cart');
		$json = array();
		if (!isset($this->session->data['api_id'])) {
			$json['error']['warning'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->post['last_customer'])) {
				$this->load->model('extension/module/ocgazie');
				$json= $this->model_extension_module_ocgazie->getCustomers($this->request->post['last_customer']);
			} else {
				$json['error']['store'] = 'non ho trovato clienti!';
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

}