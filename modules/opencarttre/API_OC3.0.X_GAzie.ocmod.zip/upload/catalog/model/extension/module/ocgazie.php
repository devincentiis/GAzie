<?php
/*
  --------------------------------------------------------------------------
  GAzie - Gestione Azienda
  Copyright (C) 2004-2023 - Antonio De Vincentiis Montesilvano (PE)
  (http://www.devincentiis.it)
  <http://gazie.sourceforge.net>
  --------------------------------------------------------------------------
  Questo programma e` free software;   e` lecito redistribuirlo  e/o
  modificarlo secondo i  termini della Licenza Pubblica Generica GNU
  come e` pubblicata dalla Free Software Foundation; o la versione 2
  della licenza o (a propria scelta) una versione successiva.

  Questo programma  e` distribuito nella speranza  che sia utile, ma
  SENZA   ALCUNA GARANZIA; senza  neppure  la  garanzia implicita di
  NEGOZIABILITA` o di  APPLICABILITA` PER UN  PARTICOLARE SCOPO.  Si
  veda la Licenza Pubblica Generica GNU per avere maggiori dettagli.

  Ognuno dovrebbe avere   ricevuto una copia  della Licenza Pubblica
  Generica GNU insieme a   questo programma; in caso  contrario,  si
  scriva   alla   Free  Software Foundation, 51 Franklin Street,
  Fifth Floor Boston, MA 02110-1335 USA Stati Uniti.
  --------------------------------------------------------------------------
  
Classe che viene istanziata su catalog/controller/extension/module/ocgazie.php e che contiene tutte le
funzioni necessarie ad interagire con il database ed aggiornare tramite API le tabelle di
opencart

l'endpoin d'accesso per il login/token è:
http(s)://mydomanin/index.php?route=api/login

la tabella geo_zone avrà un geo_zone_id=0 per IVA Italia

*/

class ModelExtensionModuleOcgazie extends Model {

	public function setupStore($store_id,$data) {
		// aggiorno i dati di configurazione dello store
		$nf="";
		if(strlen($data['image'])>100){
			$im=imagecreatefromstring(hex2bin(urldecode($data['image'])));
			imagepng($im, DIR_IMAGE."catalog/store0_logo.png");
			$nf="catalog/store0_logo.png";
			$this->db->query("UPDATE " . DB_PREFIX . "setting SET `value`='".$nf."' WHERE `store_id`=0 AND `code`='config' AND `key`='config_logo'");
			$this->db->query("UPDATE " . DB_PREFIX . "setting SET `value`='".$nf."' WHERE `store_id`=0 AND `code`='config' AND `key`='config_icon'");
		}
		$this->db->query("UPDATE " . DB_PREFIX . "setting SET `value`='".addslashes(urldecode($data['config_name']))."' WHERE `store_id`=0 AND `code`='config' AND `key`='config_name'");
		$this->db->query("UPDATE " . DB_PREFIX . "setting SET `value`='".addslashes(urldecode($data['config_name']))."' WHERE `store_id`=0 AND `code`='config' AND `key`='config_name'");
		$this->db->query("UPDATE " . DB_PREFIX . "setting SET `value`='".addslashes(urldecode($data['config_name']))."' WHERE `store_id`=0 AND `code`='config' AND `key`='config_meta_title'");
		$this->db->query("UPDATE " . DB_PREFIX . "setting SET `value`='".addslashes(urldecode($data['config_address']))."' WHERE `store_id`=0 AND `code`='config' AND `key`='config_address'");
		$this->db->query("UPDATE " . DB_PREFIX . "setting SET `value`='".addslashes(urldecode($data['config_email']))."' WHERE `store_id`=0 AND `code`='config' AND `key`='config_email'");
		$this->db->query("UPDATE " . DB_PREFIX . "setting SET `value`='".addslashes(urldecode($data['config_telephone']))."' WHERE `store_id`=0 AND `code`='config' AND `key`='config_telephone'");
		$this->db->query("UPDATE " . DB_PREFIX . "setting SET `value`='".addslashes(urldecode($data['config_fax']))."' WHERE `store_id`=0 AND `code`='config' AND `key`='config_fax'");
	}



	public function setItemQuantity($product_id,$quantity) {
		$query = $this->db->query("UPDATE " . DB_PREFIX . "product SET quantity=".(float)$quantity." WHERE product_id=".(int)$product_id);
		return $query;
	}



	public function upsertTaxRate($tax_rate_id,$data) {
		$data['geo_zone_id']=urldecode($data['geo_zone_id']);
		$data['name']=addslashes(urldecode($data['name']));
		$data['rate']=urldecode($data['rate']); 
		$data['type']=urldecode($data['type']); 
		$qtr = $this->db->query("SELECT * FROM " . DB_PREFIX . "tax_rate WHERE `tax_rate_id`= ".$tax_rate_id);
		if ($qtr->num_rows>=1){ 
			$this->db->query("UPDATE " . DB_PREFIX . "tax_rate SET `name`='".$data['name']."',`rate`='".$data['rate']."',`type`='".$data['type']."'  WHERE `geo_zone_id`=".$data['geo_zone_id']." AND `tax_rate_id`= ".$tax_rate_id);
		} else { 
			$this->db->query("INSERT INTO " . DB_PREFIX . "tax_rate (`tax_rate_id`,`geo_zone_id`,`name`,`rate`,`type`) VALUES (".$tax_rate_id.",".$data['geo_zone_id'].",'".$data['name']."','".$data['rate']."','".$data['type']."')");
		}
		// creo anche in tax_class la medesima aliquota
		$gz=array('tax_class_id'=>$tax_rate_id,'title'=>$data['name'],'description'=>$data['name']);
		$qgz=$this->db->query("SELECT * FROM " . DB_PREFIX . "tax_class WHERE `tax_class_id`= ".$gz['tax_class_id']);
		if ($qgz->num_rows>=1){ // update path
			$this->db->query("UPDATE " . DB_PREFIX . "tax_class SET `title`='".$gz['title']."', `description`='".$gz['description']."' WHERE `tax_class_id`=".$gz['tax_class_id']);
		} else { // insert path
			$this->db->query("INSERT INTO " . DB_PREFIX . "tax_class (`tax_class_id`,`title`,`description`) VALUES (".$gz['tax_class_id'].",'".$gz['title']."','".$gz['description']."')");
		}
		// eventualmente inserisco il collegamento su tax_rule
		$qtcr = $this->db->query("SELECT * FROM " . DB_PREFIX . "tax_rule WHERE `tax_rate_id`= ".$tax_rate_id." AND `tax_class_id`=".$tax_rate_id);
		if ($qtcr->num_rows<1){ 
			$this->db->query("INSERT INTO " . DB_PREFIX . "tax_rule (`tax_class_id`,`tax_rate_id`,`based`,`priority`) VALUES (".$tax_rate_id.",".$tax_rate_id.",'store',0)");
		}
		// eventualmente inserisco il collegamento su tax_rate_to_customer_group
		$qtcg = $this->db->query("SELECT * FROM " . DB_PREFIX . "tax_rate_to_customer_group WHERE `tax_rate_id`= ".$tax_rate_id." AND `customer_group_id`=1");
		if ($qtcg->num_rows<1){ 
			$this->db->query("INSERT INTO " . DB_PREFIX . "tax_rate_to_customer_group (`tax_rate_id`,`customer_group_id`) VALUES (".$tax_rate_id.",1)");
		}
		
	}

	public function setStockStatus(){
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "language WHERE 1");
		$ss_descri[0]=array(1=>'In magazzino',2=>'Sottoscorta',3=>'In arrivo');
		$ss_descri[1]=array(1=>'In stock',2=>'Under-stock',3=>'In arrival');
		foreach($query->rows as $k=>$v){
			// inserisco o aggiorno le descrizioni degli stati 1-In magazzino, 2-Sottoscorta, 3-In arrivo nelle lingue disponibili
			$ssd=$ss_descri[1];
			if ($v['code']=='it-it'){ // per l'italiano scelgo l'array specifico
				$ssd=$ss_descri[0];
			}
			foreach($ssd as $kss=>$vss){
				$qstock_status = $this->db->query("SELECT * FROM " . DB_PREFIX . "stock_status WHERE `language_id`=".$v['language_id']." AND `stock_status_id`= ".$kss);
				if ($qstock_status->num_rows>=1){ // update path
					$qr=$this->db->query("UPDATE " . DB_PREFIX . "stock_status SET `name`='".$vss."'  WHERE `stock_status_id`=".$kss." AND `language_id`= ".$v['language_id']);
				} else { // insert path
					$qr=$this->db->query("INSERT INTO " . DB_PREFIX . "stock_status (`stock_status_id`,`language_id`,`name`) VALUES (".$kss.",".$v['language_id'].",'".$vss."')");
				}
			}
		}
		return $qr;		
	}

	public function setProductQuantity($product_id,$quantity){
		$qquant = $this->db->query("SELECT `product_id` FROM " . DB_PREFIX . "product WHERE `product_id`=".urldecode($product_id));
		if ($qquant->num_rows>=1){ // update
			$qr=$this->db->query("UPDATE " . DB_PREFIX . "product SET `quantity`='".urldecode($quantity)."'  WHERE `product_id`=".urldecode($product_id));
			return $qr;	
		}
		return 'prodotto:'.$product_id.' quant:'.$quantity.' non trovato!';		
	}
	
	public function setGeoZone(){
		$gz=array('geo_zone_id'=>'380','name'=>'Italia (IVA)','description'=>'Zona IVA Italia');
		$qgz=$this->db->query("SELECT * FROM " . DB_PREFIX . "geo_zone WHERE `geo_zone_id`= ".$gz['geo_zone_id']);
		if ($qgz->num_rows>=1){ // update path
			$this->db->query("UPDATE " . DB_PREFIX . "geo_zone SET `name`='".$gz['name']."', `description`='".$gz['description']."' WHERE `geo_zone_id`=".$gz['geo_zone_id']);
		} else { // insert path
			$this->db->query("INSERT INTO " . DB_PREFIX . "geo_zone (`geo_zone_id`,`name`,`description`) VALUES (".$gz['geo_zone_id'].",'".$gz['name']."','".$gz['description']."')");
		}
		$qzgz=$this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE `geo_zone_id`= ".$gz['geo_zone_id']);
		if ($qzgz->num_rows<1){
			$this->db->query("INSERT INTO " . DB_PREFIX . "zone_to_geo_zone (`country_id`,`zone_id`,`geo_zone_id`) VALUES (105,0,".$gz['geo_zone_id'].")");
		}
	}

	public function setCustomField(){
		$cusfie=
		array('custom_field'=>
			array(1=>
				array('custom_field_id'=>1,'type'=>'text','validation'=>'/^[a-zA-Z]{6}[0-9]{2}[abcdehlmprstABCDEHLMPRST]{1}[0-9]{2}([a-zA-Z]{1}[0-9]{3})[a-zA-Z]{1}$|^[0-9]{11}$|^NO$/','location'=>'account','status'=>1,'sort_order'=>6),
			2=>
				array('custom_field_id'=>2,'type'=>'text','validation'=>'','location'=>'account','status'=>1,'sort_order'=>7)
			),
				'custom_field_customer_group'=>
			array(1=>
				array('custom_field_id'=>1,'customer_group_id'=>1,'required'=>1),
			2=>
				array('custom_field_id'=>2,'customer_group_id'=>1,'required'=>0)
			),
				'custom_field_description'=>
			array('it-it'=>
				array(1=>array('name'=>'Codice Fiscale (scrivere &quot;NO&quot; per scontrino)'),2=>array('name'=>'Partita IVA'))
			,'en-gb'=>
				array(1=>array('name'=>'Fiscal Code (write &quot;NO&quot; for ticket)'),2=>array('name'=>'Company Fiscal ID'))
			)
		);
	
		// custom_field
		$forcf=$cusfie['custom_field'];
		foreach($forcf as $k=>$v){
			$qcfd = $this->db->query("SELECT * FROM " . DB_PREFIX . "custom_field WHERE `custom_field_id`= ".$v['custom_field_id']);
			if ($qcfd->num_rows>=1){ // update
				$qr=$this->db->query("UPDATE " . DB_PREFIX . "custom_field SET `type`='".$v['type']."',`validation`='".$v['validation']."',`location`='".$v['location']."',`status`=".$v['status'].",`sort_order`=".$v['sort_order']."  WHERE `custom_field_id`=".$v['custom_field_id']);
			} else { // insert
				$qr=$this->db->query("INSERT INTO " . DB_PREFIX . "custom_field (`custom_field_id`,`type`,`validation`,`location`,`status`,`sort_order`) VALUES (".$v['custom_field_id'].",'".$v['type']."','".$v['validation']."','".$v['location']."',".$v['status'].",".$v['sort_order'].")");
			}
		}
		// custom_field_customer_group
		$forcf=$cusfie['custom_field_customer_group'];
		foreach($forcf as $k=>$v){
			$qcfd = $this->db->query("SELECT * FROM " . DB_PREFIX . "custom_field_customer_group WHERE `custom_field_id`= ".$v['custom_field_id']);
			if ($qcfd->num_rows>=1){ // update
				$qr=$this->db->query("UPDATE " . DB_PREFIX . "custom_field_customer_group SET `customer_group_id`=".$v['customer_group_id'].",`required`=".$v['required']."  WHERE `custom_field_id`=".$v['custom_field_id']);
			} else { // insert
				$qr=$this->db->query("INSERT INTO " . DB_PREFIX . "custom_field_customer_group (`custom_field_id`,`customer_group_id`,`required`) VALUES (".$v['custom_field_id'].",".$v['customer_group_id'].",".$v['required'].")");
			}
		}
		// custom_field_description
		$qlang= $this->db->query("SELECT * FROM " . DB_PREFIX . "language WHERE 1");
		foreach($qlang->rows as $k=>$v){
			// inserisco o aggiorno le descrizioni dei custom field CF/PI
			$cfd=$cusfie['custom_field_description']['en-gb'];
			if ($v['code']=='it-it'){ // per l'italiano scelgo l'array specifico
				$cfd=$cusfie['custom_field_description']['it-it'];
			}
			foreach($cfd as $kss=>$vss){
				$qcfd = $this->db->query("SELECT * FROM " . DB_PREFIX . "custom_field_description WHERE `language_id`=".$v['language_id']." AND `custom_field_id`= ".$kss);
				if ($qcfd->num_rows>=1){ // update
					$qr=$this->db->query("UPDATE " . DB_PREFIX . "custom_field_description SET `name`='".$vss['name']."'  WHERE `custom_field_id`=".$kss." AND `language_id`= ".$v['language_id']);
				} else { // insert
					$qr=$this->db->query("INSERT INTO " . DB_PREFIX . "custom_field_description (`custom_field_id`,`language_id`,`name`) VALUES (".$kss.",".$v['language_id'].",'".$vss['name']."')");
				}
			}
		}
		return $qr;		
	}

	public function upsertCategory($category_id,$data) {
		$nf="";
		if(strlen($data['image'])>100){
			$im=imagecreatefromstring(hex2bin(urldecode($data['image'])));
			imagepng($im, DIR_IMAGE."catalog/category_".$category_id.".png");
			$nf="catalog/category_".$category_id.".png";
		}
		$data['descri']=addslashes(urldecode($data['descri']));
		$data['top']=urldecode($data['top']);
		$data['annota']=addslashes(urldecode($data['annota'])); // le annotazioni vanno in meta keywords
		$qtostore = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_to_store WHERE `store_id`=0 AND `category_id`= ".$category_id);
		if ($qtostore->num_rows>=1){ // update path
			$this->db->query("UPDATE " . DB_PREFIX . "category_to_store SET `category_id`=".$category_id.",`store_id`=0  WHERE `category_id`=".$category_id." AND `store_id`= 0");
		} else { // insert path
			$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_store (`category_id`,`store_id`) VALUES (".$category_id.",0)");
		}
		$qpath = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_path WHERE `path_id`=".$category_id." AND `category_id`= ".$category_id);
		if ($qpath->num_rows>=1){ // update path
			$this->db->query("UPDATE " . DB_PREFIX . "category_path SET `category_id`='".$category_id."',`path_id`='".$category_id."',`level`= 0  WHERE `category_id`=".$category_id." AND `path_id`= ".$category_id);
		} else { // insert path
			$this->db->query("INSERT INTO " . DB_PREFIX . "category_path (`category_id`,`path_id`,`level`) VALUES (".$category_id.",".$category_id.",0)");
		}
		$qlangit = $this->db->query("SELECT * FROM " . DB_PREFIX . "language WHERE `code`='it-it'");
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "language WHERE 1");
		foreach($query->rows as $k=>$v){
			$qcate = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_description WHERE `language_id`=".$v['language_id']." AND `category_id`= ".$category_id);
			if ($qcate->num_rows>=1){ // sovrascrivo
			  if (isset($qlangit->row['language_id']) && $qcate->row['language_id']==$qlangit->row['language_id']){ // in caso di upload sovrascrivo solo l'italiano, GAzie non ha altre lingue...
				$this->db->query("UPDATE " . DB_PREFIX . "category_description SET `name`='".$data['descri']."',`description`='".$data['descri']."',`meta_title`='".$data['descri']."',`meta_description`='".$data['descri']."',`meta_keyword`='".$data['annota']."'  WHERE `language_id`=".$v['language_id']." AND `category_id`= ".$category_id);
			  }
			} else { // insert description
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_description (`category_id`,`language_id`,`name`,`description`,`meta_title`,`meta_description`,`meta_keyword`) VALUES (".$category_id.",".$v['language_id'].",'".$data['descri']."','".$data['descri']."','".$data['descri']."','".$data['descri']."','".$data['annota']."')");
			}
		}
		$qcat = $this->db->query("INSERT INTO " . DB_PREFIX . "category (`category_id`,`image`,`top`,`column`,`sort_order`,`status`) VALUES (".$category_id.",'".$nf."','".$data['top']."',6,".$category_id.",1) ON DUPLICATE KEY UPDATE `image`='".$nf."',`top`='".$data['top']."', `column` = 6,`sort_order`=".$category_id.",`status`=1");
		if ($qcat){
			return json_encode(array('category_id'=>$category_id,'description'=>$data['descri'],'top'=>$data['top']));
		}
		return false;
	}

	public function upsertProduct($product_id,$data) {
		$nf="";
		if(strlen($data['image'])>100){
			$im=imagecreatefromstring(hex2bin(urldecode($data['image'])));
			imagepng($im, DIR_IMAGE."catalog/product_".$product_id.".png");
			$nf="catalog/product_".$product_id.".png";
		}
		$data['name']=addslashes(urldecode($data['name']));
		$data['model']=urldecode($data['model']);
		$data['quantity']=urldecode($data['quantity']);
		$data['description']=addslashes(urldecode($data['description']));
		$data['description']=(strlen($data['description'])<6)?$data['name']:$data['description'];
		$data['category_id']=urldecode($data['category_id']);
		$data['weight']=urldecode($data['weight']);
		$data['length']=urldecode($data['length']);
		$data['width']=urldecode($data['width']);
		$data['height']=urldecode($data['height']);
		$data['manufacturer_id']=urldecode($data['manufacturer_id']);
		$data['price']=urldecode($data['price']);
		$data['status']=urldecode($data['status']);
		$data['tax_class_id']=urldecode($data['tax_class_id']);
		$data['meta_keyword']=urldecode($data['meta_keyword']);
		$data['stock_status_id']=urldecode($data['stock_status_id']);
		$data['date_available']=date("Y-m-d");
		$qtostore = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_to_store WHERE `store_id`=0 AND `product_id`= ".$product_id);
		if ($qtostore->num_rows>=1){ // update path
			$this->db->query("UPDATE " . DB_PREFIX . "product_to_store SET `product_id`=".$product_id.",`store_id`=0  WHERE `product_id`=".$product_id." AND `store_id`= 0");
		} else { // insert path
			$this->db->query("INSERT INTO " . DB_PREFIX . "product_to_store (`product_id`,`store_id`) VALUES (".$product_id.",0)");
		}
		$qtocategory = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_to_category WHERE `category_id`=".$data['category_id']." AND `product_id`= ".$product_id);
		if ($qtocategory->num_rows>=1){ // update path
			$this->db->query("UPDATE " . DB_PREFIX . "product_to_category SET `product_id`=".$product_id.",`category_id`=".$data['category_id']."  WHERE `product_id`=".$product_id." AND `category_id`= ".$data['category_id']);
		} else { // insert path
			$this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category (`product_id`,`category_id`) VALUES (".$product_id.",".$data['category_id'].")");
		}
		$qlangit = $this->db->query("SELECT * FROM " . DB_PREFIX . "language WHERE `code`='it-it'");
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "language WHERE 1");
		foreach($query->rows as $k=>$v){
			$qprod = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_description WHERE `language_id`=".$v['language_id']." AND `product_id`= ".$product_id);
			if ($qprod->num_rows>=1){ // update 
			  if (isset($qlangit->row['language_id']) && $qprod->row['language_id']==$qlangit->row['language_id']){ // in caso di upload sovrascrivo solo l'italiano, GAzie non ha altre lingue...
				$this->db->query("UPDATE " . DB_PREFIX . "product_description SET `name`='".$data['name']."',`description`='".$data['description']."',`meta_title`='".$data['name']."',`meta_description`='".$data['name']."',`meta_keyword`='".$data['meta_keyword']."'  WHERE `language_id`=".$v['language_id']." AND `product_id`= ".$product_id);
			  }
			} else { // insert 
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_description (`product_id`,`language_id`,`name`,`description`,`meta_title`,`meta_description`,`meta_keyword`) VALUES (".$product_id.",".$v['language_id'].",'".$data['name']."','".$data['description']."','".$data['name']."','".$data['name']."','".$data['meta_keyword']."')");
			}
		}
		$qpro = $this->db->query("INSERT INTO " . DB_PREFIX . "product (`product_id`,`model`,`quantity`,`stock_status_id`,`image`,`price`, `tax_class_id`, `weight`, `length`, `width`, `height`,`manufacturer_id`, `status`) VALUES (".$product_id.",'".$data['model']."','".$data['quantity']."','".$data['stock_status_id']."','".$nf."',".$data['price'].", ".$data['tax_class_id'].",'".$data['weight']."','".$data['length']."','".$data['width']."','".$data['height']."','".$data['manufacturer_id']."',".$data['status'].") ON DUPLICATE KEY UPDATE `model`='".$data['model']."',`quantity`='".$data['quantity']."',`stock_status_id`='".$data['stock_status_id']."',`image`='".$nf."',`price`=".$data['price'].",`tax_class_id`=".$data['tax_class_id'].",`date_available`='".$data['date_available']."',`weight`=".$data['weight'].",`length`=".$data['length'].",`width`=".$data['width'].",`height`=".$data['height'].",`manufacturer_id`=".$data['manufacturer_id'].",`status`=".$data['status']);
		if ($qpro){
			return json_encode(array('model'=>$data['model'],'name'=>$data['name'],'quantity'=>$data['quantity']));
		}
		return false;
	}
	public function getOrder($last_id){
		$qord = $this->db->query("SELECT " . DB_PREFIX . "order.*, " . DB_PREFIX . "customer.`customer_id`, " . DB_PREFIX . "customer.`custom_field`, " . DB_PREFIX . "address.`city`,".DB_PREFIX . "address.`address_1`, " . DB_PREFIX . "address.`postcode`, " . DB_PREFIX . "zone.`code`, " . DB_PREFIX . "country.`iso_code_2` FROM " . DB_PREFIX . "order LEFT JOIN " . DB_PREFIX . "customer ON " . DB_PREFIX . "order.`customer_id`=" . DB_PREFIX . "customer.`customer_id` LEFT JOIN " . DB_PREFIX . "address ON " . DB_PREFIX . "address.`customer_id` = " . DB_PREFIX . "customer.`customer_id` LEFT JOIN " . DB_PREFIX . "zone ON " . DB_PREFIX . "address.`zone_id` = " . DB_PREFIX . "zone.`zone_id` LEFT JOIN " . DB_PREFIX . "country ON " . DB_PREFIX . "zone.`country_id` = " . DB_PREFIX . "country.`country_id` WHERE `order_id`>".urldecode($last_id));
		if ($qord->num_rows>=1){
			foreach($qord->rows as $k=>$v){
				$qordrow = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE `order_id`=".$v['order_id']);
				$qord->rows[$k]['product']=$qordrow->rows;	
				$qordtot = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_total WHERE `order_id`=".$v['order_id']);
				$qord->rows[$k]['total']=$qordtot->rows;	
				$qordshi = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone WHERE `zone_id`=".$v['shipping_zone_id']);
				$qord->rows[$k]['shipping']=$qordshi->rows;	
			}
			return $qord->rows;	
		}
		return array();		
	}
	public function getCustomers($last_customer){
		$id=intval(urldecode($last_customer));
		$acc=($id>0)?('='.$id):'>=0';
		$qcus = $this->db->query("SELECT ".DB_PREFIX . "customer.*,".DB_PREFIX . "address.`address_1`,".DB_PREFIX . "address.`city`,".DB_PREFIX . "address.`zone_id`,".DB_PREFIX . "zone.`code` FROM " . DB_PREFIX . "customer LEFT JOIN " . DB_PREFIX . "address ON " . DB_PREFIX . "address.`customer_id` = " . DB_PREFIX . "customer.`customer_id` LEFT JOIN " . DB_PREFIX . "zone ON " . DB_PREFIX . "address.`zone_id` = " . DB_PREFIX . "zone.`zone_id` WHERE " . DB_PREFIX . "customer.`customer_id`".$acc." ORDER BY " . DB_PREFIX . "customer.`customer_id` DESC");
		if ($qcus->num_rows>=1){
			return $qcus->rows;	
		}
		return array();		
	}
}