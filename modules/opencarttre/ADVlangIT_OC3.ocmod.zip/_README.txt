
******************** ATTENTION! **********************************************

Dies ist ein "Modul", um es zu aktivieren, gehen Sie zu Erweiterungen->Erweiterungen und wählen Sie Module.
Das Element „Italienisch Sprache“ wird in der Liste angezeigt, um es zu aktivieren und dann zu aktivieren, indem Sie auf Bearbeiten gehen.

This is a "module" to activate it go to Extensions->Extensions choose Modules.
The "Italian Language" item will appear on the list to activate and then enable by going to Edit.

Este es un "módulo" para activarlo vaya a Extensiones->Extensiones elija Módulos.
El elemento "Idioma italiano" aparecerá en la lista para activar y luego habilite yendo a Editar.

Questo è un "modulo" per attivarlo vai su Estensioni->Estensioni scegli Moduli.
La voce "Lingua italiana" apparirà nell'elenco da attivare e quindi abilitare andando su Modifica.