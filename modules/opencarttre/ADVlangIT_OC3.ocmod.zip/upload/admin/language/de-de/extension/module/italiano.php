<?php
// Heading
$_['heading_title']    = 'Italienische Sprache';

// Text
$_['text_extension']   = 'Verlängerung';
$_['text_success']     = 'Die italienische Sprache ist aktiviert!';
$_['text_edit']        = 'Aktivieren Sie die italienische Sprache';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Achtung fehlende Berechtigungen!';