<?php
// Heading
$_['heading_title']    = 'Spanische Sprache';

// Text
$_['text_extension']   = 'Verlängerung';
$_['text_success']     = 'Die spanische Sprache ist aktiviert!';
$_['text_edit']        = 'Aktivieren Sie die spanische Sprache';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Achtung fehlende Berechtigungen!';;