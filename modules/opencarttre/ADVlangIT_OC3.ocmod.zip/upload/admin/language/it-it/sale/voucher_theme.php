<?php 

$_['heading_title']     =  'Temi Voucher';
$_['text_success']     =  'Hai modificato i temi voucher!';
$_['text_list']     =  'Lista temi voucher';
$_['text_add']     =  'Aggiungi tema voucher';
$_['text_edit']     =  'Modifica tema voucher';
$_['column_name']     =  'Nome del tema:';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Nome del tema:';
$_['entry_description']     =  'Descrizione del tema voucher:';
$_['entry_image']     =  'Immagine categoria';
$_['error_permission']     =  'Attenzione: Non hai i permessi per modificare i temi voucher!';
$_['error_name']     =  'Nome Tema Voucher deve essere lungo dai 3 ai 32 caratteri!';
$_['error_image']     =  'Immagine richiesta!';
$_['error_voucher']     =  'Attenzione: Questo tema non pu&ograve; essere eliminato perch&eacute; &egrave; correntemente assegnato a %s voucher!';
