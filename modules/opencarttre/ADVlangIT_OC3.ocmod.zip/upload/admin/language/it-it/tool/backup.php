<?php 

$_['heading_title']     =  'Backup &amp; Ripristina';
$_['text_success']     =  'Riuscito: è stato importato con successo il database!';
$_['entry_progress']     =  'Progresso';
$_['entry_export']     =  'Esportare';
$_['tab_backup']     =  'di riserva';
$_['tab_restore']     =  'Ristabilire';
$_['error_permission']     =  'Attenzione: Non si dispone dei permessi per modificare Backup & amp; Ripristina!';
$_['error_export']     =  'Attenzione: Devi selezionare almeno una tabella da esportare!';
$_['error_file']     =  'Impossibile trovare il file!';
