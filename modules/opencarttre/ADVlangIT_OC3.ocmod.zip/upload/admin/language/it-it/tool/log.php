<?php 

$_['heading_title']     =  'Registro errori';
$_['text_success']     =  'Riuscito: hai cancellato correttamente il tuo registro di errori!';
$_['text_list']     =  'Errors Lista errori';
$_['error_warning']     =  'Il tuo log file errori %s &egrave; %s!';
$_['error_permission']     =  'Non hai i permessi per pulire il log file!';
