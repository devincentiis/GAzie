<?php 

$_['heading_title']     =  'Upload';
$_['text_success']     =  'Hai modificato gli upload con successo!';
$_['text_list']     =  'Lista upload';
$_['column_name']     =  'Nome upload';
$_['column_filename']     =  'Nome file';
$_['column_date_added']     =  'Aggiunto il';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Nome upload';
$_['entry_filename']     =  'Nome file';
$_['entry_date_added']     =  'Aggiunto il';
$_['error_permission']     =  'non hai i permessi per modificare gli upload!';
