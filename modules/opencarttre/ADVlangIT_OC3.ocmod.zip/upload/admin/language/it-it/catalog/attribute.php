<?php 

$_['heading_title']     =  'attributi';
$_['text_success']     =  'Attributi modificati correttamente!';
$_['text_list']     =  'Lista attributi';
$_['text_add']     =  'Aggiungi attributo';
$_['text_edit']     =  'Modifica attributo';
$_['column_name']     =  'Nome attributo';
$_['column_attribute_group']     =  'Gruppo attributo';
$_['column_sort_order']     =  'Ordina';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Nome attributo';
$_['entry_attribute_group']     =  'Gruppo attributo';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Attenzione: Non hai il permesso per modificare gli attributi!';
$_['error_attribute_group']     =  'Gruppo attributo Required!';
$_['error_name']     =  'Nome attributo must be between 1 and 64 characters!';
$_['error_product']     =  'Attenzione: Questo attributo non pu&ograve; essere eliminato perch&eacute; assegnato a %s prodotti!';
