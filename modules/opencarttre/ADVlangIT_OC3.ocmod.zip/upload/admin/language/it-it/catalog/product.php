<?php
// Heading
$_['heading_title']          = 'Prodotti';

// Text
$_['text_success']           = 'Riuscito: hai modificato i prodotti!';
$_['text_list']              = 'Lista prodotti';
$_['text_add']               = 'Aggiungi prodotto';
$_['text_edit']              = 'Edita prodotto';
$_['text_filter']            = 'Filtro';
$_['text_plus']              = '+';
$_['text_minus']             = '-';
$_['text_default']           = 'Default';
$_['text_option']            = 'Opzione';
$_['text_option_value']      = 'Valore Opzione';
$_['text_percent']           = 'Percentuale';
$_['text_amount']            = 'Importo fisso';
$_['text_keyword']           = 'Non usare spazi, sostituiscili con - e assicurati che l\'URL SEO sia l\'unico globale.';

// Column
$_['column_name']            = 'Nome prodotto';
$_['column_model']           = 'Modello';
$_['column_image']           = 'Immagine';
$_['column_price']           = 'Prezzo';
$_['column_quantity']        = 'Quantità';
$_['column_status']          = 'Stato';
$_['column_action']          = 'Azione';

// Entry
$_['entry_name']             = 'Nome prodotto';
$_['entry_description']      = 'Descrizione';
$_['entry_meta_title']       = 'Meta Tag titolo';
$_['entry_meta_keyword']     = 'Meta Tag parole chiave';
$_['entry_meta_description'] = 'Meta Tag descrizione';
$_['entry_store']            = 'Negozi';
$_['entry_keyword']          = 'Parola chiave';
$_['entry_model']            = 'Modello';
$_['entry_sku']              = 'Booking Alert';
$_['entry_upc']              = 'UPC';
$_['entry_ean']              = 'EAN';
$_['entry_jan']              = 'JAN';
$_['entry_isbn']             = 'ISBN';
$_['entry_mpn']              = 'MPN';
$_['entry_location']         = 'Quantità 1 (Booking)';
$_['entry_shipping']         = 'Richiede spedizione';
$_['entry_manufacturer']     = 'Produttore';
$_['entry_date_available']   = 'Data disponibile';
$_['entry_quantity']         = 'Quantità';
$_['entry_minimum']          = 'Quantità minima';
$_['entry_stock_status']     = 'Stato esaurito';
$_['entry_price']            = 'Prezzo';
$_['entry_tax_class']        = 'Classe di imposta';
$_['entry_points']           = 'Punti';
$_['entry_option_points']    = 'Punti';
$_['entry_subtract']         = 'Sottrae giacenza';
$_['entry_weight_class']     = 'Unità peso';
$_['entry_weight']           = 'Peso';
$_['entry_dimension']        = 'Dimensioni (L x P x A)';
$_['entry_length_class']     = 'Unità Lunghezza';
$_['entry_length']           = 'Lunghezza';
$_['entry_width']            = 'Larghezza';
$_['entry_height']           = 'Altezza';
$_['entry_image']            = 'Immagine';
$_['entry_additional_image'] = 'Immagini aggiuntive';
$_['entry_customer_group']   = 'Gruppo clienti';
$_['entry_date_start']       = 'Data inizio';
$_['entry_date_end']         = 'Data fine';
$_['entry_priority']         = 'Priorità';
$_['entry_attribute']        = 'Attributo';
$_['entry_attribute_group']  = 'Gruppo dell\'attributo';
$_['entry_text']             = 'Testo';
$_['entry_option']           = 'Opzione';
$_['entry_option_value']     = 'Valore Opzione';
$_['entry_required']         = 'Richiesto';
$_['entry_status']           = 'Stato';
$_['entry_sort_order']       = 'Ordinamento';
$_['entry_category']         = 'Categorie';
$_['entry_filter']           = 'Filtri';
$_['entry_download']         = 'Downloads';
$_['entry_related']          = 'Prodotti correlati';
$_['entry_tag']              = 'Tag Prodotti';
$_['entry_reward']           = 'Punti premio';
$_['entry_layout']           = 'Sostituzione layout';
$_['entry_recurring']        = 'Profilo ricorrente';

// Help
$_['help_sku']               = 'Il sistema di prenotazioni (booking) allerta quando la disponibilità raggiunge questo numero minimo';
$_['placeholder_sku']   	 = 'esempio: indicare 6, per allertare l\'utente quando la disponibilità si riduce a questo valore';
$_['help_location']          = 'Il sistema di prenotazioni (b0oking) indicare "QUANTITY1" per prodotti (es. appuntamenti) che non necessitano dell\'inserimento della quantità da parte dell\'utente';
$_['placeholder_location']   = 'QUANTITY1 per quantità fissa, l\'utente non inserirà la quantità';
$_['help_upc']               = 'Universal Product Code (UPC)';
$_['help_ean']               = 'European Article Number (EAN)';
$_['help_jan']               = 'Japanese Article Number (JAN)';
$_['help_isbn']              = 'International Standard Book Number (ISBN)';
$_['help_mpn']               = 'Numero seriale produttore';
$_['help_manufacturer']      = '(Autocompleta)';
$_['help_minimum']           = 'Forza ad un importo minimo ordinabile';
$_['help_stock_status']      = 'Visualizza stato quando un prodotto è esaurito';
$_['help_points']            = 'Numero di punti necessari per acquistare questo articolo. Se non si desidera acquistare questo prodotto con punti lasciare a 0.';
$_['help_category']          = '(Autocompleta)';
$_['help_filter']            = '(Autocompleta)';
$_['help_download']          = '(Autocompleta)';
$_['help_related']           = '(Autocompleta)';
$_['help_tag']               = 'Separato da virgola';

// Error
$_['error_warning']          = 'Avvertenza: si prega di controllare attentamente il modulo per errori!';
$_['error_permission']       = 'Attenzione: non hai i permessi per modificare prodotti!';
$_['error_name']             = 'Nome prodotto deve essere maggiore di 1 e inferiore a 255 caratteri!';
$_['error_meta_title']       = 'Meta Titolo deve essere maggiore di 1 e inferiore a 255 caratteri!';
$_['error_model']            = 'Modello del prodotto deve essere maggiore di 1 e inferiore a 64 caratteri!';
$_['error_keyword']          = 'URL SEO già in uso!';
$_['error_unique']           = 'URL SEO deve essere unico!';