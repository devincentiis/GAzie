<?php 

$_['heading_title']     =  'Gruppi Attributi';
$_['text_success']     =  'Hai modificato i gruppi attributi!';
$_['text_list']     =  'Lista gruppo attributi';
$_['text_add']     =  'Aggiungi gruppo attributi';
$_['text_edit']     =  'Modifica gruppo attributi';
$_['column_name']     =  'Nome Gruppo Attributi';
$_['column_sort_order']     =  'Ordina';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Nome Gruppo Attributi';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Attenzione: Non hai il permesso di modificare i gruppi attributo!';
$_['error_name']     =  'Nome Gruppo Attributi must be between 1 and 64 characters!';
$_['error_attribute']     =  'Attenzione: Questo gruppo non pu&ograve; essere eliminato perch&eacute; assegnato a %s attributi!';
$_['error_product']     =  'Attenzione: Questo gruppo non pu&ograve; essere eliminato perch&eacute; assegnato a %s prodotti!';
