<?php 

$_['heading_title']     =  'filtri';
$_['text_success']     =  'Complimenti: Hai modificato i filtri!';
$_['text_list']     =  'Lista filtri';
$_['text_add']     =  'Aggiunfi filtro';
$_['text_edit']     =  'Modifica filtro';
$_['text_group']     =  'Gruppo Filtri';
$_['text_value']     =  'Valori filtro';
$_['column_group']     =  'Gruppo Filtri';
$_['column_sort_order']     =  'Ordina';
$_['column_action']     =  'Azione';
$_['entry_group']     =  'Nome Gruppo Filtri:';
$_['entry_name']     =  'Nome Filtri:';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Attenzione:  Non hai i permessi per modificare i filtri!';
$_['error_group']     =  'Il gruppo del filro deve essere compreso tra 1 e 64 caratteri!';
$_['error_name']     =  'Il nome del filtro deve essere compreso tra 1 e 64 caratteri!';
