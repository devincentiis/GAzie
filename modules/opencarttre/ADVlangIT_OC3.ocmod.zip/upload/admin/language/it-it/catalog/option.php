<?php
// Heading
$_['heading_title']      = 'Opzioni';

// Text
$_['text_success']       = 'Riuscito: hai modificato le opzioni!';
$_['text_list']          = 'Lista Opzioni';
$_['text_add']           = 'Aggiungi l\'opzione';
$_['text_edit']          = 'Edita l\'opzione';
$_['text_choose']        = 'Scegli';
$_['text_select']        = 'Select';
$_['text_radio']         = 'Radio';
$_['text_checkbox']      = 'Checkbox';
$_['text_input']         = 'Input';
$_['text_text']          = 'Testo';
$_['text_textarea']      = 'Textarea';
$_['text_file']          = 'File';
$_['text_date']          = 'Data';
$_['text_datetime']      = 'Data e ora';
$_['text_calendar']      = 'Calendario';
$_['text_time']          = 'Time';
$_['text_option']        = 'Opzione';
$_['text_value']         = 'Valore Opzione';

// Column
$_['column_name']        = 'Nome Opzione';
$_['column_sort_order']  = 'Ordinamento';
$_['column_action']      = 'Azione';

// Entry
$_['entry_name']         = 'Nome opzione';
$_['entry_type']         = 'Tipo';
$_['entry_option_value'] = 'Valore nome opzione';
$_['entry_image']        = 'Immagine';
$_['entry_sort_order']   = 'Ordinamento';

// Error
$_['error_permission']   = 'Attenzione: non hai i permessi per modificare le opzioni!';
$_['error_name']         = 'Nome opzione deve contenere da 1 a 128 caratteri!';
$_['error_type']         = 'Attenzione: Valori dell\'opzione required!';
$_['error_option_value'] = 'Nome del Valore Opzione deve contenere da 1 a 128 caratteri!';
$_['error_product']      = 'Attenzione: questa opzione non può essere eliminato poiché è attualmente assegnata a %s prodotti!';