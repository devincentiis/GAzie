<?php 

$_['heading_title']     =  'Rapporto online';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato i clienti online rapporto!';
$_['text_list']     =  'Elenco online';
$_['text_filter']     =  'Filtro';
$_['text_guest']     =  'ospite';
$_['column_ip']     =  'IP';
$_['column_customer']     =  'Nome cliente';
$_['column_url']     =  'Ultima pagina visitata';
$_['column_referer']     =  'Referente';
$_['column_date_added']     =  'Ultimo clic';
$_['column_action']     =  'Azione';
$_['entry_ip']     =  'IP';
$_['entry_customer']     =  'Nome cliente';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i rapporti online dei clienti!';
