<?php 

$_['heading_title']     =  'Rapporti';
$_['text_success']     =  'Riuscito: hai modificato i rapporti!';
$_['text_list']     =  'Elenco dei rapporti';
$_['text_type']     =  'Scegli il tipo di report';
$_['text_filter']     =  'Filtro';
