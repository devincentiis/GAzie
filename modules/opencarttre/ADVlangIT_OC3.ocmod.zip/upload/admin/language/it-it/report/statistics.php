<?php 

$_['heading_title']     =  'statistica';
$_['text_success']     =  'Riuscito: hai modificato le statistiche!';
$_['text_list']     =  'Elenco Statistiche';
$_['text_order_sale']     =  'Ordine delle vendite';
$_['text_order_processing']     =  'Ordini di elaborazione';
$_['text_order_complete']     =  'Ordini completati';
$_['text_order_other']     =  'Ordini Altro';
$_['text_returns']     =  'Restituisce';
$_['text_customer']     =  'Nome clientes Waiting for Approval';
$_['text_affiliate']     =  'Affiliati in attesa di approvazione';
$_['text_product']     =  'Stato magazzino products';
$_['text_review']     =  'Recensioni in attesa';
$_['column_name']     =  'Nome delle statistiche';
$_['column_value']     =  'Valore';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare le statistiche!';
