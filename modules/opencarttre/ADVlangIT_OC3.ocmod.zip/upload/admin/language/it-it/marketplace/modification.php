<?php 

$_['heading_title']     =  'modifiche';
$_['text_success']     =  'Riuscito: hai modificato le modifiche!';
$_['text_refresh']     =  'Ogni volta che abiliti / disabilita o elimina una modifica, è necessario fare clic sul pulsante di aggiornamento per ricostruire la cache di modifica!';
$_['text_list']     =  'Elenco modifica';
$_['column_name']     =  'Nome di modifica';
$_['column_author']     =  'Autore';
$_['column_version']     =  'Versione';
$_['column_status']     =  'Stato Categoria';
$_['column_date_added']     =  'Aggiunto il';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare le modifiche!';
