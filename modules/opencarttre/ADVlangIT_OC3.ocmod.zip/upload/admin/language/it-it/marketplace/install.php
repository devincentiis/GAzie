<?php 

$_['text_success']     =  'Riuscito: hai modificato le estensioni!';
$_['text_unzip']     =  'Estrarre i file!';
$_['text_move']     =  'Copia di file!';
$_['text_xml']     =  'Applicare modifiche!';
$_['text_remove']     =  'Rimozione di file temporanei!';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione a modificare le estensioni!';
$_['error_install']     =  'L\'installazione dell\'estensione avviene attendere qualche secondo prima di provare ad installare!';
$_['error_unzip']     =  'Impossibile aprire il file Zip!';
$_['error_file']     =  'Impossibile trovare il file di installazione!';
$_['error_directory']     =  'Impossibile trovare la directory di installazione!';
$_['error_code']     =  'Il codice univoco è necessario per l\'XML di modifica!';
$_['error_xml']     =  'La modifica %s è già stata utilizzata!';
$_['error_exists']     =  'Il file %s esiste già!';
$_['error_allowed']     =  'La directory %s non può essere scritta!';
