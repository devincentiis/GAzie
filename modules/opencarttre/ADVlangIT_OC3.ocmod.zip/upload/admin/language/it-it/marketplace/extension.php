<?php 

$_['heading_title']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato le estensioni!';
$_['text_list']     =  'Lista di estensione';
$_['text_type']     =  'Scegli il tipo di estensione';
$_['text_filter']     =  'Filtro';
