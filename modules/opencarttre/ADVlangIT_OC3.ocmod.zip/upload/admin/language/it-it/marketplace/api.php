<?php 

$_['heading_title']     =  'API Opencart Marketplace';
$_['text_success']     =  'Riuscito: hai modificato le tue informazioni sull\'API!';
$_['text_signup']     =  'Inserisci le informazioni dell\'API Opencart che puoi ottenere <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link"> qui </a>.';
$_['entry_username']     =  'Nome utente';
$_['entry_secret']     =  'Segreto';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare l\'API del Marketplace!';
$_['error_username']     =  'Nome utente richiesto!';
$_['error_secret']     =  'Chiave segreta obbligatorio!';
