<?php 

$_['heading_title']     =  'Installatore di estensioni';
$_['text_progress']     =  'Progressione installazione';
$_['text_upload']     =  'Carica le tue estensioni';
$_['text_history']     =  'Cronologia di installazione';
$_['text_success']     =  'Riuscito: L\'estensione è stata installata!';
$_['text_install']     =  'Installazione';
$_['column_filename']     =  'Nome file';
$_['column_date_added']     =  'Aggiunto il';
$_['column_action']     =  'Azione';
$_['entry_upload']     =  'Caricare un file';
$_['entry_progress']     =  'Progressione';
$_['help_upload']     =  'Richiede un file di modifica con estensione \'.ocmod.zip\'.';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione a modificare le estensioni!';
$_['error_install']     =  'Attendere qualche secondo prima di provare ad installare!';
$_['error_upload']     =  'Il file non pu&ograve; essere caricato!';
$_['error_filetype']     =  'Tipo file non valido!';
$_['error_file']     =  'Impossibile trovare il file!';
