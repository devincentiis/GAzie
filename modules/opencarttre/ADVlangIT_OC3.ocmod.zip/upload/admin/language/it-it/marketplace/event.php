<?php 

$_['heading_title']     =  'eventi';
$_['text_success']     =  'Riuscito: hai modificato gli eventi!';
$_['text_list']     =  'Elenco eventi';
$_['text_event']     =  'Gli eventi vengono utilizzati dalle estensioni per ignorare le funzionalità predefinite del tuo negozio. Se hai problemi puoi disattivare o abilitare gli eventi qui.';
$_['text_info']     =  'Event Pagine informative';
$_['text_trigger']     =  'grilletto';
$_['text_action']     =  'Azione';
$_['column_code']     =  'Codice evento';
$_['column_status']     =  'Stato Categoria';
$_['column_sort_order']     =  'Ordina';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione a modificare le estensioni!';
