<?php 

$_['heading_title']     =  'Impostazioni dello sviluppatore';
$_['text_success']     =  'Riuscito: hai modificato le impostazioni dello sviluppatore!';
$_['text_theme']     =  'Tema';
$_['text_sass']     =  'SASS';
$_['text_cache']     =  'Riuscito: hai eliminato la cache %s!';
$_['column_component']     =  'Componente';
$_['column_action']     =  'Azione';
$_['entry_theme']     =  'Tema';
$_['entry_sass']     =  'SASS';
$_['entry_cache']     =  'Nascondiglio';
$_['button_on']     =  'Sopra';
$_['button_off']     =  'Via';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare le impostazioni dello sviluppatore!';
