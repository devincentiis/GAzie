<?php 

$_['heading_title']     =  'Manager immagini';
$_['text_uploaded']     =  'File caricato con successo!';
$_['text_directory']     =  'Cartella creata con successo!';
$_['text_delete']     =  'Rimozione file o cartella eseguita con successo!';
$_['entry_search']     =  'Ricerca...';
$_['entry_folder']     =  'Nuova Cartella';
$_['error_permission']     =  'Attenzione: Permesso negato!';
$_['error_filename']     =  'Attenzione: il nome del file deve essere maggiore di 3 caratteri e minore di 255!';
$_['error_folder']     =  'Attenzione: il nome della cartella deve essere maggiore di 3 caratteri e minore di 255!';
$_['error_exists']     =  'Attenzione: Un file o un percorso con lo stesso nome esiste gi&agrave;!';
$_['error_directory']     =  'Attenzione: seleziona un percorso!';
$_['error_filesize']     =  'Attenzione: Dimensione del file non corretta!';
$_['error_filetype']     =  'Attenzione: tipo di file non valido!';
$_['error_upload']     =  'Attenzione: il file non pu&ograve; essere caricato per motivi sconosciuti!';
$_['error_delete']     =  'Attenzione: non puoi eliminare questo percorso!';
