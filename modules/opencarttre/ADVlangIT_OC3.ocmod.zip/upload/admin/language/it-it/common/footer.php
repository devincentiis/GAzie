<?php 
$_['text_footer']     =  'Powered By <a href="https://www.opencart.com">OpenCart</a> & <a href="https://www.devincentiis.it">ADVisor</a>';
$_['text_version']     =  'Versione %s';
