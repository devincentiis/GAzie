<?php 

$_['heading_title']     =  'Reimposta la tua password';
$_['text_password']     =  'Immettere la nuova password che si desidera utilizzare.';
$_['text_success']     =  'Password reimpostata con successo.';
$_['entry_password']     =  'Password';
$_['entry_confirm']     =  'Conferma password';
$_['error_password']     =  'La password deve essere tra 4 e 20 caratteri!';
$_['error_confirm']     =  'Le password non coincidono!';
