<?php 

$_['heading_title']     =  'Amministrazione';
$_['text_heading']     =  'Amministrazione';
$_['text_login']     =  'Inserisci i tuoi dati di accesso.';
$_['text_forgotten']     =  'Password dimenticata?';
$_['entry_username']     =  'Nome utente';
$_['entry_password']     =  'Password';
$_['button_login']     =  'Accesso';
$_['error_login']     =  'Nome utente e/o password inesistenti.';
$_['error_token']     =  'Sessione scaduta, effettua di nuovo il login.';
