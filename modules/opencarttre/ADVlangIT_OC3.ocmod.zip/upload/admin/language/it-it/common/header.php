<?php 

$_['heading_title']     =  'Opencart';
$_['text_profile']     =  'Il tuo profilo';
$_['text_store']     =  'I negozi';
$_['text_help']     =  'Aiuto';
$_['text_homepage']     =  'Homepage';
$_['text_support']     =  'Forum di supporto';
$_['text_documentation']     =  'Documentazione';
$_['text_logout']     =  'Esci';
