<?php 

$_['heading_title']     =  'Dashboard';
$_['error_install']     =  'Attenzione: La cartella d\'installazione esiste ancora e deve essere eliminata per motivi di sicurezza!';
