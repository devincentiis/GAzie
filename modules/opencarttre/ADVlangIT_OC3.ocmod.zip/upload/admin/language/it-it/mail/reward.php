<?php 

$_['text_subject']     =  '%s - Punti';
$_['text_received']     =  'Hai ricevuto %s punti!';
$_['text_total']     =  'Il tuo numero totale di punti di ricompensa è ora %s.';
