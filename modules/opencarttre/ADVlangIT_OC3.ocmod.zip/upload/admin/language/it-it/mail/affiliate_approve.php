<?php 

$_['text_subject']     =  '%s - Il tuo account affiliato è stato attivato!';
$_['text_welcome']     =  'Benvenuto e grazie per esserti registrato su %s!';
$_['text_login']     =  'Il tuo account è stato approvato e puoi accedere utilizzando il tuo indirizzo e-mail e la password visitando il nostro sito web o all\'indirizzo seguente:';
$_['text_services']     =  'Una volta effettuato il login, sarai in grado di generare codici di tracciamento, tracciare le commissioni di pagamento e modificare le informazioni del tuo account.';
$_['text_thanks']     =  'Grazie,';
