<?php 

$_['text_success']     =  'Hai modificato i voucher con successo!';
$_['text_subject']     =  'Ti &egrave; stato inviato un voucher regalo da %s';
$_['text_greeting']     =  'Congratulazioni, hai ricevuto un voucher regalo del valore di %s';
$_['text_from']     =  'Questo regalo ti &egrave; stato inviato da %s';
$_['text_message']     =  'Con un messaggio che dice';
$_['text_redeem']     =  'Per utilizzare il tuo regalo, segnati il codice <b>%s</b> poi clicca nel link qui sotto ed acquista il prodotto che vuoi. Potrai inserire il codice del tuo voucher regalo prima di effettuare il checkout.';
$_['text_footer']     =  'Per favore, rispondi a questa email per qualsiasi dubbio o domanda.';
