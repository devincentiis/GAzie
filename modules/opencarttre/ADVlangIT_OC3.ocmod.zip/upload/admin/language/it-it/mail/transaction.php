<?php 

$_['text_subject']     =  ' %s - credito di affiliazione';
$_['text_received']     =  'Hai ricevuto credito %s!';
$_['text_total']     =  'Il tuo credito totale e\' %s.';
$_['text_credit']     =  'Il credito dell\'account può essere detratto dal tuo acquisto successivo.';
