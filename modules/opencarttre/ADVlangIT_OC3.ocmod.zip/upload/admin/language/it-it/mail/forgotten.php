<?php 

$_['text_subject']     =  '%s - Richiesta reset password';
$_['text_greeting']     =  'Una nuova password &egrave; stata richiesta per l\'amministrazione di %s.';
$_['text_change']     =  'Per reimpostare la password clicca sul seguente link:';
$_['text_ip']     =  'L\'IP utilizzato per effettuare questa richiesta è stato:';
