<?php 

$_['text_subject']     =  '%s - Aggiornamento restituzione %s';
$_['text_return_id']     =  'ID restituzione:';
$_['text_date_added']     =  'Data restituzione:';
$_['text_return_status']     =  'La tua restituzione &egrave; stata aggiornata al seguente stato:';
$_['text_comment']     =  'I commenti sulla restituzione sono i seguenti:';
$_['text_footer']     =  'Per favore, rispondi a questa email per qualsiasi dubbio o domanda.';
