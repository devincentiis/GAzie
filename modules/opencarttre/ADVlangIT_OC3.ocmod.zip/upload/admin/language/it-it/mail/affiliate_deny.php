<?php 

$_['text_subject']     =  ' %s - Il tuo account affiliato è stato negato!';
$_['text_welcome']     =  'Benvenuto e grazie per esserti registrato su %s!';
$_['text_denied']     =  'Purtroppo la tua richiesta è stata negata. Per ulteriori informazioni potete contattare il proprietario del negozio qui:';
$_['text_thanks']     =  'Grazie,';
