<?php 

$_['text_subject']     =  '%s - Il tuo account è stato attivato!';
$_['text_welcome']     =  'Benvenuto e grazie per esserti registrato su %s!';
$_['text_login']     =  'Il tuo account è stato creato e puoi accedere usando il tuo indirizzo e-mail e la password visitando il nostro sito o all\'indirizzo seguente:';
$_['text_service']     =  'Al momento della registrazione potrai accedere ad altri servizi, tra cui la revisione degli ordini passati, la stampa di fatture e la modifica delle informazioni relative all\'account.';
$_['text_thanks']     =  'Grazie,';
