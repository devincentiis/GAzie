<?php 

$_['heading_title']     =  'posta';
$_['text_success']     =  'Messaggio inviato con successo!';
$_['text_sent']     =  'Messaggio inviato con successo a %s di %s destinatari!';
$_['text_list']     =  'Lista layout';
$_['text_default']     =  'Predefinito';
$_['text_newsletter']     =  'Iscritti alla Newsletter ';
$_['text_customer_all']     =  'Tutti i Clienti';
$_['text_customer_group']     =  'Gruppo Clienti';
$_['text_customer']     =  'Nome clientes';
$_['text_affiliate_all']     =  'Tutti gli Affiliati';
$_['text_affiliate']     =  'Affiliati';
$_['text_product']     =  'Prodotti';
$_['entry_store']     =  'A partire dal';
$_['entry_to']     =  'A';
$_['entry_customer_group']     =  'Gruppo Clienti';
$_['entry_customer']     =  'Nome cliente';
$_['entry_affiliate']     =  'affiliato';
$_['entry_product']     =  'Prodotti';
$_['entry_subject']     =  'Soggetto';
$_['entry_message']     =  'Messaggio';
$_['help_customer']     =  '(Autocomplete)';
$_['help_affiliate']     =  '(Autocomplete)';
$_['help_product']     =  'Invia solo ai clienti che hanno ordinato prodotti nell\'elenco. (Autocomplete)';
$_['error_permission']     =  'Attenzione: Non si hanno permessi per inviare E-Mail!';
$_['error_subject']     =  'E\' necessario inserire l\'oggetto dell\'E-Mail!';
$_['error_message']     =  'E\' necessario inserire il messaggio dell\'E-Mail!';
