<?php 

$_['heading_title']     =  'Elenco eBay';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo eBay in evidenza!';
$_['text_edit']     =  'Modifica modulo eBay';
$_['text_list']     =  'Elenco Layout';
$_['text_register']     =  'Devi registrarsi e abilitare OpenBay Pro per eBay!';
$_['text_about']     =  'Il modulo display eBay consente di visualizzare i prodotti dal tuo account eBay direttamente sul tuo sito web.';
$_['text_latest']     =  'Più recente';
$_['text_random']     =  'Casuale';
$_['entry_name']     =  'Nome del modulo';
$_['entry_username']     =  'Nome utente eBay';
$_['entry_keywords']     =  'Cerca parole chiave';
$_['entry_description']     =  'Includi Descrizione Cerca';
$_['entry_limit']     =  'Limite';
$_['entry_length']     =  'Lunghezza';
$_['entry_width']     =  'Larghezza';
$_['entry_height']     =  'Altezza';
$_['entry_site']     =  'Sito eBay';
$_['entry_sort']     =  'Ordina per';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo eBay!';
$_['error_name']     =  'Il nome del modulo deve essere compreso tra 3 e 64 caratteri!';
$_['error_width']     =  'Larghezza richiesta!';
$_['error_height']     =  'Altezza richiesta!';
