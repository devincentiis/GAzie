<?php 

$_['heading_title']     =  'Pulsante PayPal (Powered by Braintree)';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo PayPal (Powered by Braintree)!';
$_['text_edit']     =  'Modifica il pulsante Modulo PayPal (Powered by Braintree)';
$_['text_info']     =  'Il pulsante <u> non </u> viene visualizzato in determinate condizioni:';
$_['text_info_li1']     =  'Il carrello è vuoto e non sono stati applicati voucher';
$_['text_info_li2']     =  'Il carrello ha download o pagamenti ricorrenti e l\'utente non è connesso';
$_['text_info_li3']     =  'Stato magazzino item checkout is disabled and the cart contains an out of stock item';
$_['text_layouts']     =  'Dopo aver abilitato il modulo, utilizzare il gestore di layout per aggiungere il pulsante alle aree del negozio.';
$_['text_layout_link']     =  'Clicca qui per accedere alla pagina dei layout';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo PayPal (Powered by Braintree)!';
