<?php 

$_['heading_title']     =  'IP antifrode';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato IP Anti-Frode!';
$_['text_edit']     =  'Modifica IP antifrode';
$_['text_ip_add']     =  'Aggiungi Indirizzo IP';
$_['text_ip_list']     =  'Indirizzo IP Frode';
$_['column_ip']     =  'IP';
$_['column_total']     =  'Totale Conti';
$_['column_date_added']     =  'Aggiunto il';
$_['column_action']     =  'Azione';
$_['entry_ip']     =  'IP';
$_['entry_status']     =  'Stato Categoria';
$_['entry_order_status']     =  'Stato:';
$_['help_order_status']     =  'I clienti che dispongono di un IP vietato nei loro account verranno assegnati a questo stato dell\'ordine e non saranno autorizzati a raggiungere automaticamente lo stato completo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare IP Anti-Frode!';
