<?php 

$_['heading_title']     =  'Transazione di rimborso';
$_['text_pp_express']     =  'PayPal Express Checkout';
$_['text_current_refunds']     =  'Sono già stati effettuati rimborsi per questa transazione. Il rimborso massimo è';
$_['text_refund']     =  'Rimborso';
$_['entry_transaction_id']     =  'ID transazione';
$_['entry_full_refund']     =  'Rimborso completo';
$_['entry_amount']     =  'Quantità';
$_['entry_message']     =  'Messaggio';
$_['button_refund']     =  'Rimborso dell\'emissione';
$_['error_partial_amt']     =  'Devi inserire un importo parziale di rimborso';
$_['error_data']     =  'Dati mancanti dalla richiesta';
