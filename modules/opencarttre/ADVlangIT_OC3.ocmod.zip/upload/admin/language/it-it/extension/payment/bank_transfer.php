<?php 

$_['heading_title']     =  'Bonifico Bancario';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli del trasferimento bancario!';
$_['text_edit']     =  'Edit Bonifico Bancario';
$_['entry_bank']     =  'Bonifico Bancario Instructions';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il bonifico bancario di pagamento!';
$_['error_bank']     =  'Bonifico Bancario Instructions Required!';
