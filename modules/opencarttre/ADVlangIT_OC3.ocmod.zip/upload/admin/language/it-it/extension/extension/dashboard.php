<?php 

$_['heading_title']     =  'Dashboard';
$_['text_success']     =  'Riuscito: hai modificato Dashboard!';
$_['text_list']     =  'Elenco dei dashboard';
$_['column_name']     =  'Nome del dashboard';
$_['column_width']     =  'Larghezza';
$_['column_status']     =  'Stato Categoria';
$_['column_sort_order']     =  'Ordina';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i dashboard!';
