<?php 

$_['heading_title']     =  'Buono regalo';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il voucher regalo totale!';
$_['text_edit']     =  'Modifica voucher regalo Total';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il voucher regalo totale!';
