<?php 

$_['heading_title']     =  'Persone Online';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato la dashboard!';
$_['text_edit']     =  'Modifica Dashboard Online';
$_['text_view']     =  'Visualizza altro ...';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['entry_width']     =  'Larghezza';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il dashboard online!';
