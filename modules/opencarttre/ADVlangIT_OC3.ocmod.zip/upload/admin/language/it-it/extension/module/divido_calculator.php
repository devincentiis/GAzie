<?php 

$_['heading_title']     =  'Calcolatrice Divido pagina prodotti';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato la calcolatrice di pagine di prodotto di Divido!';
$_['text_edit']     =  'Modifica il calcolatore della pagina dei prodotti di Divido';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo Calcolatrice pagina dei prodotti di Divido!';
