<?php 

$_['heading_title']     =  'spedizione';
$_['text_success']     =  'Riuscito: hai modificato la spedizione!';
$_['text_list']     =  'Lista di spedizione';
$_['column_name']     =  'Metodo Spedizione';
$_['column_status']     =  'Stato Categoria';
$_['column_sort_order']     =  'Ordina';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare la spedizione!';
