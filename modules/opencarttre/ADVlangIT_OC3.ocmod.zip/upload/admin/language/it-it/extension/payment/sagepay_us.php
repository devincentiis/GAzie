<?php 

$_['heading_title']     =  'Sage Payment Solutions (US)';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato i dettagli dell\'account SagePay!';
$_['text_edit']     =  'Modifica soluzioni di pagamento saggio (US)';
$_['entry_merchant_id']     =  'ID Commerciante';
$_['entry_merchant_key']     =  'Chiave del commerciante';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento SagePay!';
$_['error_merchant_id']     =  'Obbligatorio ID Merchant!';
$_['error_merchant_key']     =  'Merchant Key Required!';
