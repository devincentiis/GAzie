<?php 

$_['heading_title']     =  'Rapporto sui coupon';
$_['text_extension']     =  'Estensione';
$_['text_edit']     =  'Modifica Coupons Report';
$_['text_success']     =  'Riuscito: hai modificato la relazione coupon!';
$_['text_filter']     =  'Filtro';
$_['column_name']     =  'Nome Coupon';
$_['column_code']     =  'Codice';
$_['column_orders']     =  'Ordini';
$_['column_total']     =  'Totale';
$_['column_action']     =  'Azione';
$_['entry_date_start']     =  'Data inizio';
$_['entry_date_end']     =  'Data Fine';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il rapporto coupon!';
