<?php 

$_['heading_title']     =  'Tasso fisso';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato la tariffa forfettaria!';
$_['text_edit']     =  'Modifica la tariffa flat rate';
$_['entry_cost']     =  'Costo';
$_['entry_tax_class']     =  'categoria fiscale';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare la spedizione a tasso fisso!';
