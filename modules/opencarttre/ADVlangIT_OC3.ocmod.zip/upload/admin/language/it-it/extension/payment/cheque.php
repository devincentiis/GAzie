<?php 

$_['heading_title']     =  'Verifica / ordine di soldi';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli del conto di controllo / conto corrente!';
$_['text_edit']     =  'Modifica controllo / ordine di soldi';
$_['entry_payable']     =  'Pagabile a';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento / ordine di pagamento!';
$_['error_payable']     =  'Pagabile a richiesto!';
