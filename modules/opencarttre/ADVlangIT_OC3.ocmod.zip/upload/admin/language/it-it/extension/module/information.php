<?php 

$_['heading_title']     =  'Pagine informative';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo di informazione!';
$_['text_edit']     =  'Modifica informazione Module';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo di informazioni!';
