<?php 

$_['heading_title']     =  'Categoria';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il modulo di categoria!';
$_['text_edit']     =  'Modifica categoria Module';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo di categoria!';
