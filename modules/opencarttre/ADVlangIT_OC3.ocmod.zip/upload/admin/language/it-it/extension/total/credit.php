<?php 

$_['heading_title']     =  'Conserva il credito';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il totale credito del negozio!';
$_['text_edit']     =  'Modifica negozio di credito totale';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare totalmente il credito negozio!';
