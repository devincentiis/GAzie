<?php 

$_['heading_title']     =  'Amazon UE';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_dashboard']     =  'Amazon Dashboard';
$_['text_heading_settings']     =  'impostazioni';
$_['text_heading_account']     =  'Modifica piano';
$_['text_heading_links']     =  'Articoli link';
$_['text_heading_register']     =  'Registrati qui';
$_['text_heading_bulk_listing']     =  'Bulk listing';
$_['text_heading_stock_updates']     =  'Aggiornamenti delle scorte';
$_['text_heading_saved_listings']     =  'Elenchi salvati';
$_['text_heading_bulk_linking']     =  'Collegamento in massa';
