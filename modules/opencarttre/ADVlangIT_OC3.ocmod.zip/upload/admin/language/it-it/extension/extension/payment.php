<?php 

$_['heading_title']     =  'pagamenti';
$_['text_success']     =  'Riuscito: hai modificato i pagamenti!';
$_['text_list']     =  'Lista di pagamento';
$_['text_recommended']     =  'Pagamenti - Soluzioni consigliate';
$_['column_name']     =  'Metodo Pagamento';
$_['column_status']     =  'Stato Categoria';
$_['column_sort_order']     =  'Ordina';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i pagamenti!';
