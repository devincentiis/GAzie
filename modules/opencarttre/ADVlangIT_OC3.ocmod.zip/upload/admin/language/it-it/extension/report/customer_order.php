<?php 

$_['heading_title']     =  'Nome cliente Orders Report';
$_['text_extension']     =  'Estensione';
$_['text_edit']     =  'Modifica cliente Orders Report';
$_['text_success']     =  'Riuscito: hai modificato i rapporti sugli ordini dei clienti!';
$_['text_filter']     =  'Filtro';
$_['text_all_status']     =  'Tutti gli stati';
$_['column_customer']     =  'Nome cliente';
$_['column_email']     =  'E-mail';
$_['column_customer_group']     =  'Gruppo Clienti';
$_['column_status']     =  'Stato Categoria';
$_['column_orders']     =  'No. Ordini';
$_['column_products']     =  'Num. Prodotti';
$_['column_total']     =  'Totale';
$_['column_action']     =  'Azione';
$_['entry_date_start']     =  'Data inizio';
$_['entry_date_end']     =  'Data Fine';
$_['entry_customer']     =  'Nome cliente';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il rapporto di ordini dei clienti!';
