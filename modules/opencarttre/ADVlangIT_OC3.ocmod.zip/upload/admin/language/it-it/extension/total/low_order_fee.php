<?php 

$_['heading_title']     =  'Tariffa bassa';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il totale delle commissioni a basso costo!';
$_['text_edit']     =  'Modifica tariffa bassa Ordine totale';
$_['entry_total']     =  'Ordine totale';
$_['entry_fee']     =  'tassa';
$_['entry_tax_class']     =  'categoria fiscale';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo totale ordine venga disattivato.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il totale delle commissioni basse!';
