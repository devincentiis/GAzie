<?php 

$_['heading_title']     =  'Contenuto HTML';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo HTML Content!';
$_['text_edit']     =  'Modifica modulo contenuto HTML';
$_['entry_name']     =  'Nome del modulo';
$_['entry_title']     =  'Titolo del titolo';
$_['entry_description']     =  'Descrizione';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo HTML Content!';
$_['error_name']     =  'Il nome del modulo deve essere compreso tra 3 e 64 caratteri!';
