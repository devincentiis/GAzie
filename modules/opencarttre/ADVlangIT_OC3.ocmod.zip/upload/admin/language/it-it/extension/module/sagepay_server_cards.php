<?php 

$_['heading_title']     =  'Gestione della scheda di server Sagepay';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo Sagepay Server Management Card!';
$_['text_edit']     =  'Modifica modulo di gestione scheda Sagepay';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo di gestione della scheda Sagepay Server!';
