<?php 

$_['heading_title']     =  'Totali Vendite';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato le vendite di dashboard!';
$_['text_edit']     =  'Modifica le vendite dashboard';
$_['text_view']     =  'Visualizza altro ...';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['entry_width']     =  'Larghezza';
$_['error_permission']     =  'Avviso: Non hai permesso di modificare le vendite dashboard!';
