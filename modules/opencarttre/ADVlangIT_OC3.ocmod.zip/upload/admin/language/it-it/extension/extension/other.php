<?php 

$_['heading_title']     =  'Altro';
$_['text_success']     =  'Riuscito: hai modificato un\'altra estensione!';
$_['text_list']     =  'Altro elenco';
$_['column_name']     =  'Altro';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare un\'altra estensione!';
