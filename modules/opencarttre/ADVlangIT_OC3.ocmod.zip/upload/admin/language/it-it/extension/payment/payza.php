<?php 

$_['heading_title']     =  'Payza';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli del conto Payza!';
$_['text_edit']     =  'Modifica Payza';
$_['entry_merchant']     =  'ID Commerciante';
$_['entry_security']     =  'Codice di sicurezza';
$_['entry_callback']     =  'URL di avviso';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_callback']     =  'This has to be set in the Payza control panel. You will also need to check the "IPN Stato Categoria" to enabled.';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento Payza!';
$_['error_merchant']     =  'Obbligatorio ID Merchant!';
$_['error_security']     =  'Codice di sicurezza richiesto!';
