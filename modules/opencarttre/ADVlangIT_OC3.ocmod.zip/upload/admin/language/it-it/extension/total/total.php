<?php 

$_['heading_title']     =  'Totale';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato totali totali!';
$_['text_edit']     =  'Modifica totali totali';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare totali totali!';
