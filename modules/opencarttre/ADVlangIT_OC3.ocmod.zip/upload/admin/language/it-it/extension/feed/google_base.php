<?php 

$_['heading_title']     =  'Google Base';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Hai modificato Google Base feed con successo!';
$_['text_edit']     =  'Modifica Google Base';
$_['text_import']     =  'Per scaricare l\'elenco di categorie Google più recente per <a href="https://support.google.com/merchants/answer/160081?hl=it" target="_blank" class="alert-link"> fare clic qui </a> e scegliere la tassonomia con ID numerici nel file di testo normale (txt). Carica tramite il pulsante di importazione verde.';
$_['column_google_category']     =  'Categoria Google';
$_['column_category']     =  'Categoria';
$_['column_action']     =  'Azione';
$_['entry_google_category']     =  'Categoria Google';
$_['entry_category']     =  'Categoria';
$_['entry_data_feed']     =  'Feed Url:';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Attenzione: Non hai i permessi per modifcare il Google Base feed!';
$_['error_upload']     =  'Il file non pu&ograve; essere caricato!';
$_['error_filetype']     =  'Tipo file non valido!';
