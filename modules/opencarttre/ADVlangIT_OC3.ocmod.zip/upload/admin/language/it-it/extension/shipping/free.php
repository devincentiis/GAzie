<?php 

$_['heading_title']     =  'Spedizione Gratuita';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il trasporto libero!';
$_['text_edit']     =  'Edit Spedizione Gratuita';
$_['entry_total']     =  'Totale';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'L\'importo totale del subappalto necessario prima che il modulo di spedizione gratuito diventi disponibile.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il trasporto gratuito!';
