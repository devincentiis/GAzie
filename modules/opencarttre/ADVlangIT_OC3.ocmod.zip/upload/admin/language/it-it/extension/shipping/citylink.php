<?php 

$_['heading_title']     =  'Citylink';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato la spedizione Citylink!';
$_['text_edit']     =  'Modifica la spedizione Citylink';
$_['entry_rate']     =  'Tariffe Citylink';
$_['entry_tax_class']     =  'categoria fiscale';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_rate']     =  'Inserisci valori fino a 5,2 punti decimali. (12345.67) Esempio: .1: 1, .25: 1.27 - Pesi inferiori o uguali a 0,1 Kg avrebbero un costo pari a 1,00, Pesi inferiori o uguali a 0,25 g ma più di 0,1 Kg costa 1,27. Non immettere KG o simboli.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare la spedizione Citylink!';
