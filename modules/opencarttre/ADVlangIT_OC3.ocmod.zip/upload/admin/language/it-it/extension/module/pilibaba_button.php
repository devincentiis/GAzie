<?php 

$_['heading_title']     =  'Pulsante Pilibaba Checkout';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo Pilibaba Checkout Button!';
$_['text_edit']     =  'Modifica modulo Pilibaba Button Checkout';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo Pilibaba Checkout Button!';
