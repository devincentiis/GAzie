<?php 

$_['heading_title']     =  'Free Checkout';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo di pagamento gratuito Checkout!';
$_['text_edit']     =  'Modifica il pagamento gratuito';
$_['entry_order_status']     =  'Stato:';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento gratuito Checkout!';
