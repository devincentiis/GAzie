<?php 

$_['heading_title']     =  'Sottoscrizione';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_ebay']     =  'eBay';
$_['button_plan_change']     =  'Cambi da pianificare';
$_['column_plan']     =  'Nome del piano';
$_['column_call_limit']     =  'Limite di chiamata';
$_['column_price']     =  'Prezzo (p / mese)';
$_['column_description']     =  'Descrizione';
$_['column_current']     =  'Piano attuale';
$_['text_subscription_current']     =  'Piano attuale';
$_['text_subscription_avail']     =  'Piani disponibili';
$_['text_subscription_avail1']     =  'Modificare i piani saranno immediati e le chiamate inutilizzate non saranno accreditate.';
$_['text_ajax_acc_load_plan']     =  'ID di sottoscrizione PayPal:';
$_['text_ajax_acc_load_plan2']     =  ', devi cancellare tutte le altre sottoscrizioni da noi';
$_['text_load_my_plan']     =  'Caricamento del tuo piano';
$_['text_load_plans']     =  'Caricamento di piani disponibili';
$_['text_subscription']     =  'Modifica il tuo abbonamento OpenBay Pro';
$_['error_ajax_load']     =  'Spiacenti, non è stato possibile ottenere una risposta. Prova più tardi.';
