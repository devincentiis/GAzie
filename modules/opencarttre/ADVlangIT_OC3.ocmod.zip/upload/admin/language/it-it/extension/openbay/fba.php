<?php 

$_['heading_title']     =  'Fulfillment di Amazon';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_dashboard']     =  'Compilazione da Amazon Dashboard';
$_['text_heading_settings']     =  'impostazioni';
$_['text_heading_account']     =  'Conto / abbonamento';
$_['text_heading_fulfillments']     =  'adempimenti';
$_['text_heading_register']     =  'Registrati qui';
$_['text_heading_orders']     =  'Ordini';
