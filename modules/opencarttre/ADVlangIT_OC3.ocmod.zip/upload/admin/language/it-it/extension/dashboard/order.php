<?php 

$_['heading_title']     =  'Ordini totali';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato gli ordini sulla dashboard!';
$_['text_edit']     =  'Modifica ordini del dashboard';
$_['text_view']     =  'Visualizza altro ...';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['entry_width']     =  'Larghezza';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare gli ordini del dashboard!';
