<?php 

$_['heading_title']     =  'Punti';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato totalmente i punti di ricompensa!';
$_['text_edit']     =  'Edit Punti Total';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare totalmente i punti di ricompensa!';
