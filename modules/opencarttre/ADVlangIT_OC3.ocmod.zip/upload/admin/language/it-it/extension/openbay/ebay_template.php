<?php 

$_['heading_title']     =  'Modelli di elenchi';
$_['text_ebay']     =  'eBay';
$_['text_openbay']     =  'OpenBay Pro';
$_['column_name']     =  'Nome modello';
$_['column_action']     =  'Azione';
$_['entry_template_name']     =  'Nome';
$_['entry_template_html']     =  'HTML';
$_['text_added']     =  'È stato aggiunto un nuovo modello';
$_['text_updated']     =  'Il modello è stato aggiornato';
$_['text_deleted']     =  'Il modello è stato eliminato';
$_['text_confirm_delete']     =  'Sei sicuro? you want to delete the template?';
$_['text_list']     =  'Elenco modelli';
$_['text_add']     =  'Aggiungi profilo';
$_['text_edit']     =  'Modifica Profilo';
$_['error_name']     =  'È necessario immettere un nome di modello';
$_['error_permission']     =  'Non hai l\'autorizzazione a modificare i modelli';
$_['error_no_template']     =  'L\'ID del modello non esiste';
