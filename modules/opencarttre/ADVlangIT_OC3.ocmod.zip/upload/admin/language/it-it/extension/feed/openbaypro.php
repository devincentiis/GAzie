<?php 

$_['heading_title']     =  'OpenBay Pro';
