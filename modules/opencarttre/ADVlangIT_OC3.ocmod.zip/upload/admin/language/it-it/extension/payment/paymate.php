<?php 

$_['heading_title']     =  'Paymate';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli dell\'account Paymate!';
$_['text_edit']     =  'Modifica Paymate';
$_['text_paymate']     =  '<img src = "view / image / payment / paymate.png" alt = "Paymate" title = "Paymate" style = "confine: 1px solid #EEEEEE;" />';
$_['entry_username']     =  'Paymate Nome utente';
$_['entry_password']     =  'Parola d\'ordine';
$_['entry_test']     =  'Modalità di prova';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_password']     =  'Utilizza solo una password casuale. Questo verrà utilizzato per assicurarsi che le informazioni sul pagamento non siano interferite dopo essere state inviate al gateway di pagamento.';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento Paymate!';
$_['error_username']     =  'Paymate Nome utente required!';
$_['error_password']     =  'Password richiesta!';
