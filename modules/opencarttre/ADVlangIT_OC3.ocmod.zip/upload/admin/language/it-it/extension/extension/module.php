<?php 

$_['heading_title']     =  'moduli';
$_['text_success']     =  'Riuscito: hai modificato i moduli!';
$_['text_layout']     =  'Dopo aver installato e configurato un modulo è possibile aggiungerlo a un layout <a href="%s" class="alert-link"> qui </a>!';
$_['text_add']     =  'Add moodulo';
$_['text_list']     =  'Elenco dei moduli';
$_['column_name']     =  'Nome del modulo';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['entry_code']     =  'Modulo';
$_['entry_name']     =  'Nome del modulo';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i moduli!';
$_['error_name']     =  'Il nome del modulo deve essere compreso tra 3 e 64 caratteri!';
$_['error_code']     =  'Estensione richiesta!';
