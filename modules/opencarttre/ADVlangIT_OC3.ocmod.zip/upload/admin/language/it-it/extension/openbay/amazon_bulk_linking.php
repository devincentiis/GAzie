<?php 

$_['heading_title']     =  'Collegamento in massa';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_amazon']     =  'Amazon UE';
$_['button_load']     =  'Caricare';
$_['button_link']     =  'collegamento';
$_['text_local']     =  'Locale';
$_['text_load_listings']     =  'Caricamento di tutti i tuoi annunci da Amazon può richiedere un certo tempo (fino a 2 ore in alcuni casi). Se si collega i tuoi articoli, i livelli di magazzino su Amazon verranno aggiornati con i livelli di magazzino del tuo negozio.';
$_['text_report_requested']     =  'Ha richiesto con successo la relazione di inserzione da Amazon';
$_['text_report_request_failed']     =  'Impossibile richiedere il rapporto di inserimento';
$_['text_loading']     =  'Caricamento di oggetti';
$_['text_choose_marketplace']     =  'Scegli il mercato';
$_['text_uk']     =  'Regno Unito';
$_['text_de']     =  'Germania';
$_['text_fr']     =  'Francia';
$_['text_it']     =  'Italia';
$_['text_es']     =  'Spagna';
$_['column_asin']     =  'COME IN';
$_['column_price']     =  'Prezzo';
$_['column_name']     =  'Nome';
$_['column_sku']     =  'SKU';
$_['column_quantity']     =  'Quantità';
$_['column_combination']     =  'Combinazione';
$_['error_bulk_link_permission']     =  'Il link di massa non è disponibile sul tuo piano, ti preghiamo di aggiornare per utilizzare questa funzionalità.';
