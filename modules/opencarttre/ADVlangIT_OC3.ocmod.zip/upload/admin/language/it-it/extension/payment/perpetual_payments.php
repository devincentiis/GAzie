<?php 

$_['heading_title']     =  'Pagamenti perpetui';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli del conto Payments Perpetual!';
$_['text_edit']     =  'Modifica pagamenti perpetui';
$_['entry_auth_id']     =  'ID di autorizzazione';
$_['entry_auth_pass']     =  'Password di autorizzazione';
$_['entry_test']     =  'Modalità di prova';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_test']     =  'Utilizzare questo modulo in Test (YES) o in modalità di produzione (NO)?';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i pagamenti perpetui di pagamento!';
$_['error_auth_id']     =  'Obbligatorio dell\'autorizzazione!';
$_['error_auth_pass']     =  'Password di autorizzazione richiesta!';
