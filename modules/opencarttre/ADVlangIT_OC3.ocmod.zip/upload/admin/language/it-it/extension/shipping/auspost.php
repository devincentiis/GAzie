<?php 

$_['heading_title']     =  'Australia Post';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato la spedizione dell\'Australia!';
$_['text_edit']     =  'Modifica Australia Spedizione Postale';
$_['entry_api']     =  'Chiave API';
$_['entry_postcode']     =  'Codice postale';
$_['entry_weight_class']     =  'Classe peso';
$_['entry_tax_class']     =  'categoria fiscale';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_weight_class']     =  'Impostare a chilogrammi.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare la spedizione in Australia!';
$_['error_postcode']     =  'Il codice postale deve essere di 4 cifre!';
