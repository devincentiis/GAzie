<?php 

$_['heading_title']     =  'Anti frode';
$_['text_success']     =  'Riuscito: hai modificato l\'anti-frode!';
$_['text_list']     =  'Lista antifrode';
$_['column_name']     =  'Nome antifrode';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare l\'antifrode!';
