<?php 

$_['heading_title']     =  'Feed';
$_['text_success']     =  'Riuscito: hai modificato i feed!';
$_['text_list']     =  'Elenco dei feed';
$_['column_name']     =  'Nome del prodotto';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i feed!';
