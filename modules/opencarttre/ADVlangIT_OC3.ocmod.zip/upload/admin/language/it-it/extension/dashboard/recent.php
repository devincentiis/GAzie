<?php 

$_['heading_title']     =  'Ultimi ordini';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato gli ordini recenti sulla dashboard!';
$_['text_edit']     =  'Modifica gli ordini recenti di Dashboard';
$_['column_order_id']     =  'ID Ordine';
$_['column_customer']     =  'Nome cliente';
$_['column_status']     =  'Stato Categoria';
$_['column_total']     =  'Totale';
$_['column_date_added']     =  'Aggiunto il';
$_['column_action']     =  'Azione';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['entry_width']     =  'Larghezza';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare gli ordini recenti sul dashboard!';
