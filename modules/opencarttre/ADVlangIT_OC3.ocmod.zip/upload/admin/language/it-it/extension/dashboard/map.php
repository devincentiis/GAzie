<?php 

$_['heading_title']     =  'Mappa dell\'Europa';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato la mappa della dashboard!';
$_['text_edit']     =  'Modifica la mappa dashboard';
$_['text_order']     =  'Ordini';
$_['text_sale']     =  'I saldi';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['entry_width']     =  'Larghezza';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare la mappa della dashboard!';
