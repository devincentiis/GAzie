<?php
// Heading
$_['heading_title']    = 'Lingua italiana';

// Text
$_['text_extension']   = 'Estensione';
$_['text_success']     = 'La lingua italiana è stata attivata!';
$_['text_edit']        = 'Abilita la lingua italiana';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Attenzione permessi mancanti!';