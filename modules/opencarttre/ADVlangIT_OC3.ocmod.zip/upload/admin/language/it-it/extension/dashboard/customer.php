<?php 

$_['heading_title']     =  'Clienti totali';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il cliente dashboard!';
$_['text_edit']     =  'Edit Dashboard Nome cliente';
$_['text_view']     =  'Visualizza altro ...';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['entry_width']     =  'Larghezza';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il cliente dashboard!';
