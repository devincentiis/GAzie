<?php 

$_['heading_title']     =  'PayPoint';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli dell\'account PayPoint!';
$_['text_edit']     =  'Modifica PayPoint';
$_['text_paypoint']     =  '<a href="https://www.paypoint.net/partners/opencart" target="_blank"> <img src = "visualizza / image / payment / paypoint.png" alt = "PayPoint" title = "PayPoint" style = "border: 1px solid #EEEEEE;" /> </a>';
$_['text_live']     =  'Produzione';
$_['text_successful']     =  'Sempre successo';
$_['text_fail']     =  'Sempre fallito';
$_['entry_merchant']     =  'ID Commerciante';
$_['entry_password']     =  'Password remota';
$_['entry_test']     =  'Modalità di prova';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_password']     =  'Lasciare vuoto se non è abilitata "Digest Key Authentication" nel tuo account.';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento PayPoint!';
$_['error_merchant']     =  'Obbligatorio ID Merchant!';
