<?php 

$_['heading_title']     =  'Klarna Checkout';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo Klarna Checkout!';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo Klarna Checkout!';
