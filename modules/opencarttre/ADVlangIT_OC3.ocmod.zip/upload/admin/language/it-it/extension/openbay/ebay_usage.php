<?php 

$_['heading_title']     =  'uso';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_ebay']     =  'eBay';
$_['text_usage']     =  'L\'utilizzo del tuo account';
$_['error_ajax_load']     =  'Spiacenti, non è stato possibile ottenere una risposta. Prova più tardi.';
