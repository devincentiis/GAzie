<?php 

$_['heading_title']     =  'Totale parziale';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il totale sub totale!';
$_['text_edit']     =  'Modifica totale sub-totale';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il totale sub totale!';
