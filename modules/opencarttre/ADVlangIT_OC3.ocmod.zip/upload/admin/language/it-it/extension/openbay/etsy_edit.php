<?php 

$_['heading_title']     =  'Modifica elenchi';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_etsy']     =  'Etsy';
$_['text_option']     =  'Select (Dropdown) option';
$_['text_listing_id']     =  'ID dell\'annuncio';
$_['text_updated']     =  'Il tuo elenco Etsy è stato aggiornato';
$_['text_edit']     =  'Aggiorna il tuo elenco Etsy';
$_['entry_title']     =  'Titolo del prodotto';
$_['entry_description']     =  'Descrizione';
$_['entry_price']     =  'Prezzo';
$_['entry_state']     =  'Stato';
$_['error_price_missing']     =  'Il prezzo manca o è vuoto';
$_['error_title_length']     =  'Il titolo è troppo lungo';
$_['error_title_missing']     =  'Il titolo è mancante';
$_['error_desc_missing']     =  'Descrizione manca o vuota';
$_['error_state_missing']     =  'Stato manca o vuota';
