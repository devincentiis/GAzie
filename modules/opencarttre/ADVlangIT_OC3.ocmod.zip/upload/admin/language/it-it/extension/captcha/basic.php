<?php 

$_['heading_title']     =  'Basic Captcha';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Hai modificato i Basic Captcha! con successo!';
$_['text_edit']     =  'Modifica Captcha di base';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Non hai i permessi per modificare i Basic Captcha!';
