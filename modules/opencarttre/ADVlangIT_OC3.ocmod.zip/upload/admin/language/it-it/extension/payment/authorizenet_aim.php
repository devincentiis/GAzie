<?php 

$_['heading_title']     =  'Authorize.Net (AIM)';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli dell\'account Authorize.Net (AIM)!';
$_['text_edit']     =  'Modifica Authorize.Net (AIM)';
$_['text_test']     =  'Test';
$_['text_live']     =  'Vivere';
$_['text_authorization']     =  'Autorizzazione';
$_['text_capture']     =  'Catturare';
$_['text_authorizenet_aim']     =  '<a onclick="window.open(\'http://reseller.authorize.net/application/?id=5561142\');"> <img src = "visualizza / image / payment / authorizenet.png" alt = "Autorizza .Net "title =" Authorize.Net "style =" confine: 1px solido #EEEEEE; " /> </a>';
$_['entry_login']     =  'Utente';
$_['entry_key']     =  'Chiave di transazione';
$_['entry_hash']     =  'MD5 Hash';
$_['entry_server']     =  'Server di transazione';
$_['entry_mode']     =  'Modalità transazione';
$_['entry_method']     =  'Metodo di transazione';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento Autorize.Net (SIM)!';
$_['error_login']     =  'ID di accesso richiesto!';
$_['error_key']     =  'Chiave di transazione richiesta!';
