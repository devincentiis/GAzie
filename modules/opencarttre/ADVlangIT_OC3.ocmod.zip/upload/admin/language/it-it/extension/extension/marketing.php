<?php 

$_['heading_title']     =  'Marketing';
$_['text_success']     =  'Riuscito: Hai modificato il marketing!';
$_['text_list']     =  'Elenco Analytics';
$_['column_name']     =  'Nome di marketing';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il marketing!';
