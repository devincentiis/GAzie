<?php 

$_['heading_title']     =  'spedizione';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il totale di spedizione!';
$_['text_edit']     =  'Modifica spedizione Totale';
$_['entry_estimator']     =  'Estimatore di spedizione';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il totale di spedizione!';
