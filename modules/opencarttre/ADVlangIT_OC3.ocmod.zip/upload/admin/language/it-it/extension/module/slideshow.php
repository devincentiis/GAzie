<?php 

$_['heading_title']     =  'Presentazione';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il modulo slideshow!';
$_['text_edit']     =  'Modifica Modulo Slideshow';
$_['entry_name']     =  'Nome del modulo';
$_['entry_banner']     =  'Banner';
$_['entry_width']     =  'Larghezza';
$_['entry_height']     =  'Altezza';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo Slideshow!';
$_['error_name']     =  'Il nome del modulo deve essere compreso tra 3 e 64 caratteri!';
$_['error_width']     =  'Larghezza richiesta!';
$_['error_height']     =  'Altezza richiesta!';
