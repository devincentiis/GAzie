<?php 

$_['heading_title']     =  'captcha';
$_['text_success']     =  'Riuscito: hai cambiato captcha!';
$_['text_list']     =  'Lista Captcha';
$_['column_name']     =  'Captcha Nome';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare le captache!';
