<?php 

$_['heading_title']     =  'Pickup Dall\'Azienda';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai cambiato il pickup dal negozio!';
$_['text_edit']     =  'Modifica pickup dal negozio di spedizione';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pickup dal negozio!';
