<?php
// Heading
$_['heading_title']    = 'Lingua spagnola';

// Text
$_['text_extension']   = 'Estensione';
$_['text_success']     = 'La lingua spagnola è stata attivata!';
$_['text_edit']        = 'Abilita la lingua spagnola';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Attenzione permessi mancanti!';