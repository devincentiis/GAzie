<?php 

$_['heading_title']     =  'I più venduti';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il modulo bestseller!';
$_['text_edit']     =  'Modifica Modulo Più Bestseller';
$_['entry_name']     =  'Nome del modulo';
$_['entry_limit']     =  'Limite';
$_['entry_image']     =  'Immagine categoria (W x H) and Resize Type';
$_['entry_width']     =  'Larghezza';
$_['entry_height']     =  'Altezza';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo bestseller!';
$_['error_name']     =  'Il nome del modulo deve essere compreso tra 3 e 64 caratteri!';
$_['error_width']     =  'Larghezza richiesta!';
$_['error_height']     =  'Altezza richiesta!';
