<?php 

$_['heading_title']     =  'Annunci salvati';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_amazon']     =  'Amazon UE';
$_['text_description']     =  'Questa è l\'elenco degli elenchi di prodotti salvati e pronti per essere caricati su Amazon.';
$_['text_uploaded_alert']     =  'Annunci salvati caricati!';
$_['text_delete_confirm']     =  'Sei sicuro??';
$_['text_complete']     =  'Annunci caricati';
$_['column_name']     =  'Nome';
$_['column_model']     =  'Modello';
$_['column_sku']     =  'SKU';
$_['column_amazon_sku']     =  'Articolo Amazon SKU';
$_['column_action']     =  'Azione';
