<?php 

$_['heading_title']     =  'Ordine Totale';
$_['text_success']     =  'Riuscito: Hai modificato i totali!';
$_['text_list']     =  'Ordine elenco totale';
$_['column_name']     =  'Ordine Totale';
$_['column_status']     =  'Stato Categoria';
$_['column_sort_order']     =  'Ordina';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i totali!';
