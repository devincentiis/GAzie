<?php 

$_['heading_title']     =  '2Checkout';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli dell\'account 2Checkout!';
$_['text_edit']     =  'Modifica 2Checkout';
$_['text_twocheckout']     =  '<a href="https://www.2checkout.com/2co/affiliate?affiliate=1596408" target="_blank"> <img src = "vista / immagine / pagamento / 2checkout.png" alt = "titolo 2Checkout" = "2Checkout" style = "confine: 1px solid #EEEEEE;" /> </a>';
$_['entry_account']     =  'ID account 2Checkout';
$_['entry_secret']     =  'Parola segreta';
$_['entry_display']     =  'Checkout diretto';
$_['entry_test']     =  'Modalità di prova';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_secret']     =  'La parola segreta per confermare le transazioni con (deve essere la stessa definita nella pagina di configurazione del conto commerciante).';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento 2Checkout!';
$_['error_account']     =  'No. Account richiesto!';
$_['error_secret']     =  'Parola segreta richiesta!';
