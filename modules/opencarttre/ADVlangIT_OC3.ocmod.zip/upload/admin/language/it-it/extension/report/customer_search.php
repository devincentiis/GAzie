<?php 

$_['heading_title']     =  'Nome cliente Searches Report';
$_['text_extension']     =  'Estensione';
$_['text_edit']     =  'Modifica cliente Searches Report';
$_['text_success']     =  'Riuscito: hai modificato il rapporto di ricerche di clienti!';
$_['text_filter']     =  'Filtro';
$_['text_guest']     =  'ospite';
$_['text_customer']     =  '<a href="%s">%s</a>';
$_['column_keyword']     =  'Parola chiave';
$_['column_products']     =  'Prodotti trovati';
$_['column_category']     =  'Categoria';
$_['column_customer']     =  'Nome cliente';
$_['column_ip']     =  'IP';
$_['column_date_added']     =  'Aggiunto il';
$_['entry_date_start']     =  'Data inizio';
$_['entry_date_end']     =  'Data Fine';
$_['entry_keyword']     =  'Parola chiave';
$_['entry_customer']     =  'Nome cliente';
$_['entry_ip']     =  'IP';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il rapporto di ricerca dei clienti!';
