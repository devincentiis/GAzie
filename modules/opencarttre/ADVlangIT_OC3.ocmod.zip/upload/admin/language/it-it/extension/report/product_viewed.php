<?php 

$_['heading_title']     =  'Prodotti visualizzati';
$_['text_extension']     =  'Estensione';
$_['text_edit']     =  'Modifica prodottos Viewed Report';
$_['text_success']     =  'Riuscito: è stato resettato il rapporto di prodotti visualizzato!';
$_['column_name']     =  'Nome prodotto';
$_['column_model']     =  'Modello';
$_['column_viewed']     =  'Visto';
$_['column_percent']     =  'Per cento';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione a modificare i report di prodotti visualizzati!';
