<?php 

$_['heading_title']     =  'Klarna Fee';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il totale della quota di Klarna!';
$_['text_edit']     =  'Modifica Klarna Fee Total';
$_['text_sweden']     =  'Svezia';
$_['text_norway']     =  'Norvegia';
$_['text_finland']     =  'Finlandia';
$_['text_denmark']     =  'Danimarca';
$_['text_germany']     =  'Germania';
$_['text_netherlands']     =  'Paesi Bassi';
$_['entry_total']     =  'Ordine totale';
$_['entry_fee']     =  'Commissione di fatturazione';
$_['entry_tax_class']     =  'categoria fiscale';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il totale di Klarna fee!';
