<?php 

$_['heading_title']     =  'analitica';
$_['text_success']     =  'Riuscito: hai modificato le analisi!';
$_['text_list']     =  'Elenco Analytics';
$_['column_name']     =  'Nome Analytics';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare le analisi!';
