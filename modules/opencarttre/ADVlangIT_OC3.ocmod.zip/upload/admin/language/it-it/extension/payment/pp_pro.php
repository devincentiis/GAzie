<?php 

$_['heading_title']     =  'PayPal Pro';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli dell\'account PayPal per il sito web Payment Pro Checkout!';
$_['text_edit']     =  'Modifica PayPal Pro';
$_['text_pp_pro']     =  '<a target="_BLANK" href="https://www.paypal.com/it/mrb/pal=V4T754QB63XXL"> <img src = "view / image / payment / paypal.png" alt = "Pagamento del sito PayPal Pro "title =" PayPal sito web Pagamento Pro iFrame "style =" confine: 1px solid #EEEEEE; " /> </a>';
$_['text_authorization']     =  'Autorizzazione';
$_['text_sale']     =  'saldi';
$_['entry_username']     =  'API Nome utente';
$_['entry_password']     =  'Password API';
$_['entry_signature']     =  'Firma API';
$_['entry_test']     =  'Modalità di prova';
$_['entry_transaction']     =  'Metodo di transazione:';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_test']     =  'Utilizzare il server gateway live o testing (sandbox) per elaborare le transazioni?';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento PayPal Pagamento sito web Pagamento!';
$_['error_username']     =  'API Nome utente Required!';
$_['error_password']     =  'Password API richiesto!';
$_['error_signature']     =  'Firma API richiesto!';
