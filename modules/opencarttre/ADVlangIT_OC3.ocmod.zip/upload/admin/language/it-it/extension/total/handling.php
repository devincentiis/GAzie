<?php 

$_['heading_title']     =  'Tassa di gestione';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato la tassa di gestione totale!';
$_['text_edit']     =  'Modifica la tariffa di gestione totale';
$_['entry_total']     =  'Ordine totale';
$_['entry_fee']     =  'tassa';
$_['entry_tax_class']     =  'categoria fiscale';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo totale di ordine diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare la tassa di gestione totale!';
