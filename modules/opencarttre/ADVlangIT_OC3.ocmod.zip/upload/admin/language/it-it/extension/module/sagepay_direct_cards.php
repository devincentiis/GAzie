<?php 

$_['heading_title']     =  'Gestione diretta della carta Sagepay';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo Sagepay Direct Card Management!';
$_['text_edit']     =  'Modifica modulo Sagepay Direct Card Management';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo Sagepay Direct Card Management!';
