<?php 

$_['heading_title']     =  'Temi';
$_['text_success']     =  'Riuscito: hai modificato i temi!';
$_['text_list']     =  'Lista tematica';
$_['column_name']     =  'Nome del tema';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione a modificare i temi!';
