<?php 

$_['heading_title']     =  'NOCHEX';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli dell\'account NOCHEX!';
$_['text_edit']     =  'Modifica NOCHEX';
$_['text_nochex']     =  '<a href="https://secure.nochex.com/apply/merchant_info.aspx?partner_id=172198798" target="_blank"> <img src = "vista / immagine / pagamento / nochex.png" alt = "NOCHEX "title =" NOCHEX "style =" confine: 1px solido #EEEEEE; " /> </a>';
$_['text_seller']     =  'Venditore / conto personale';
$_['text_merchant']     =  'Conto Merchant';
$_['entry_email']     =  'E-mail';
$_['entry_account']     =  'Tipo di account';
$_['entry_merchant']     =  'ID Commerciante';
$_['entry_template']     =  'Modello di passaggio';
$_['entry_test']     =  'Test';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento NOCHEX!';
$_['error_email']     =  'E-Mail Obbligatoria!';
$_['error_merchant']     =  'Obbligatorio ID Merchant!';
