<?php 

$_['heading_title']     =  'Account';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il modulo account!';
$_['text_edit']     =  'Modifica modulo account';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo account!';
