<?php 

$_['heading_title']     =  'Aggiornamenti delle scorte';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_amazon']     =  'Amazon UE';
$_['text_no_results']     =  'Nessu risultato!';
$_['entry_date_start']     =  'Data inizio';
$_['entry_date_end']     =  'Data Fine';
$_['column_ref']     =  'arbitro';
$_['column_date_requested']     =  'Data richiesta';
$_['column_date_updated']     =  'Data aggiornata';
$_['column_status']     =  'Stato Categoria';
$_['column_sku']     =  'Amazon SKU';
$_['column_stock']     =  'Azione';
$_['error_api_connection']     =  'Impossibile connettersi all\'API';
