<?php 

$_['heading_title']     =  'Negozio';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Hai modificato il modulo negozio con successo!';
$_['text_edit']     =  'Modifica modulo negozio';
$_['entry_admin']     =  'Solo utente Amministratore';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Attenzione: non hai il permesso di modificare il modulo negozio!';
