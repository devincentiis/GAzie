<?php 

$_['heading_title']     =  'Sitemap di Google';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il feed di Sitemap di Google!';
$_['text_edit']     =  'Modifica Sitemap di Google';
$_['entry_status']     =  'Stato Categoria';
$_['entry_data_feed']     =  'Feed Url:';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione a modificare il feed di Google Sitemap!';
