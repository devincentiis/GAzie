<?php 

$_['heading_title']     =  'statistiche di Google';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato Google Analytics!';
$_['text_edit']     =  'Modifica Google Analytics';
$_['text_signup']     =  'Accedi all\'account <a href="http://www.google.com/analytics/" target="_blank"> <u> Google Analytics </u> </a> e dopo aver creato il tuo profilo del sito copia e incolla il codice analitico in questo campo.';
$_['text_default']     =  'Predefinito';
$_['entry_code']     =  'Codice di Google Analytics';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Non hai i permessi necessari per poter modificare Google Analytics!';
$_['error_code']     =  'Codice richiesto!';
