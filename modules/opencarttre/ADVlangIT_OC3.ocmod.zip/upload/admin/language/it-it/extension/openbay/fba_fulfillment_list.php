<?php 

$_['heading_title']     =  'adempimenti';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_fba']     =  'Fulfillment Da Amazon';
$_['entry_start_date']     =  'Data di inizio (formato YYYY-MM-DD)';
$_['text_no_results']     =  'Nessun completamento è trovato su Amazon';
$_['text_fulfillment_list']     =  'Lista Amazon Fulfillment';
$_['column_seller_fulfillment_order_id']     =  'Seller ID Ordine';
$_['column_displayable_order_id']     =  'Displayable ID Ordine';
$_['column_displayable_order_date']     =  'Data / ora visualizzabile';
$_['column_shipping_speed_category']     =  'Velocità di spedizione';
$_['column_fulfillment_order_status']     =  'Stato:';
$_['column_action']     =  'Azione';
