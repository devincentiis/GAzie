<?php 

$_['heading_title']     =  'Menu';
$_['text_success']     =  'Riuscito: Hai modificato il menu!';
$_['text_list']     =  'Elenco dei menu';
$_['column_name']     =  'Nome del Menu';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il menu!';
