<?php 

$_['heading_title']     =  'Sincronizzare';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_ebay']     =  'eBay';
$_['button_update']     =  'Aggiornare';
$_['entry_sync_categories']     =  'Ottieni categorie eBay';
$_['entry_sync_shop']     =  'Ottieni categorie di negozi';
$_['entry_sync_setting']     =  'Ottenere le impostazioni';
$_['text_complete']     =  'Completare';
$_['text_sync_desc']     =  'Sincronizza il tuo negozio con le più recenti opzioni di spedizione e categorie disponibili da eBay, questi dati sono solo per le opzioni quando elenca un articolo su eBay - non importerà le categorie al tuo negozio ecc.';
$_['text_ebay_categories']     =  'Questo potrebbe richiedere un po \', attendere 5 minuti prima di fare qualsiasi altra cosa.';
$_['text_category_import']     =  'Le tue categorie del negozio eBay sono state importate.';
$_['text_setting_import']     =  'Le impostazioni sono state importate.';
$_['text_sync']     =  'Aggiorna le impostazioni da eBay';
$_['help_sync_categories']     =  'Questo non importa categorie al tuo negozio!';
$_['help_sync_shop']     =  'Questo non importa categorie al tuo negozio!';
$_['help_sync_setting']     =  'Questo importa i tipi di pagamento disponibili, spedizione, località e altro ancora.';
$_['error_settings']     =  'Si è verificato un errore durante il caricamento delle impostazioni.';
$_['error_failed']     =  'Caricamento fallito';
