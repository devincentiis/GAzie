<?php 

$_['heading_title']     =  'Le imposte';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai totalmente modificato le imposte!';
$_['text_edit']     =  'Modifica imposta totale';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare totalmente le imposte!';
