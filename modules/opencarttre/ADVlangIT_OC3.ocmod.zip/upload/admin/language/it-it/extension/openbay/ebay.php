<?php 

$_['heading_title']     =  'eBay';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_dashboard']     =  'Dashboard di eBay';
$_['text_success']     =  'Le modifiche sono state salvate nell\'estensione eBay';
$_['text_heading_settings']     =  'impostazioni';
$_['text_heading_sync']     =  'Sincronizzare';
$_['text_heading_subscription']     =  'Modifica piano';
$_['text_heading_usage']     =  'uso';
$_['text_heading_links']     =  'Articoli link';
$_['text_heading_item_import']     =  'Importa elementi';
$_['text_heading_order_import']     =  'Ordini di importazione';
$_['text_heading_adds']     =  'Componenti aggiuntivi installati';
$_['text_heading_summary']     =  'Riepilogo eBay';
$_['text_heading_profile']     =  'Profili';
$_['text_heading_template']     =  'Modelli';
$_['text_heading_ebayacc']     =  'conto eBay';
$_['text_heading_register']     =  'Registrati qui';
$_['error_category_nosuggestions']     =  'Impossibile caricare categorie suggerite';
$_['error_loading_catalog']     =  'Catalogo eBay search failed';
$_['error_generic_fail']     =  'Un errore sconosciuto è accaduto!';
$_['error_no_products']     =  'Nessun prodotto trovato';
