<?php 

$_['heading_title']     =  'Statistiche vendite';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato la dashboard!';
$_['text_edit']     =  'Modifica tabella dashboard';
$_['text_order']     =  'Ordini';
$_['text_customer']     =  'Nome clientes';
$_['text_day']     =  'Oggi';
$_['text_week']     =  'Settimana';
$_['text_month']     =  'Mese';
$_['text_year']     =  'Anno';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['entry_width']     =  'Larghezza';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il grafico del dashboard!';
