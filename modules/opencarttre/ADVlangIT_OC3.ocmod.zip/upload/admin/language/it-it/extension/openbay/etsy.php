<?php 

$_['heading_title']     =  'Etsy';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_dashboard']     =  'Etsy Dashboard';
$_['text_success']     =  'Le modifiche sono state salvate nell\'estensione Etsy';
$_['text_heading_settings']     =  'impostazioni';
$_['text_heading_sync']     =  'Sincronizzare';
$_['text_heading_register']     =  'Registrati qui';
$_['text_heading_products']     =  'Articoli link';
$_['text_heading_listings']     =  'Etsy elenchi';
$_['error_generic_fail']     =  'Un errore sconosciuto è accaduto!';
$_['error_permission']     =  'Non hai l\'autorizzazione alle impostazioni di Etsy';
