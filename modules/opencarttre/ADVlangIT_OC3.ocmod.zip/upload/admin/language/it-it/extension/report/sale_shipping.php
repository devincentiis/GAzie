<?php 

$_['heading_title']     =  'Rapporto di spedizione';
$_['text_extension']     =  'Estensione';
$_['text_edit']     =  'Modifica rapporto di spedizione';
$_['text_success']     =  'Riuscito: hai modificato il rapporto di spedizione!';
$_['text_filter']     =  'Filtro';
$_['text_year']     =  'Anni';
$_['text_month']     =  'mesi';
$_['text_week']     =  'settimane';
$_['text_day']     =  'giorni';
$_['text_all_status']     =  'Tutti gli stati';
$_['column_date_start']     =  'Data inizio';
$_['column_date_end']     =  'Data Fine';
$_['column_title']     =  'Titolo di spedizione';
$_['column_orders']     =  'No. Ordini';
$_['column_total']     =  'Totale';
$_['entry_date_start']     =  'Data inizio';
$_['entry_date_end']     =  'Data Fine';
$_['entry_group']     =  'Raggruppa per:';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il rapporto di spedizione!';
