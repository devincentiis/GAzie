<?php 

$_['heading_title']     =  'Google reCAPTCHA';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Hai modificato con successo il Google reCAPTCHA!';
$_['text_edit']     =  'Modifica Google reCAPTCHA';
$_['text_signup']     =  'Vai su <a href="https://www.google.com/recaptcha/intro/index.html" target="_blank"><u>Google reCAPTCHA page</u></a> and register your website.';
$_['entry_key']     =  'Chiave sito web';
$_['entry_secret']     =  'Chiave segreta';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Warning: Non hai i permessi per modificare Google reCAPTCHA!';
$_['error_key']     =  'Chiave segreta obbligatorio!';
$_['error_secret']     =  'Chiave segreta obbligatorio!';
