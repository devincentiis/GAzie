<?php 

$_['heading_title']     =  'Skrill';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli di Skrill.';
$_['text_edit']     =  'Modifica Skrill';
$_['text_skrill']     =  '<a href="https://content.skrill.com/it/ecommerce-solutions/opencart/" target="_blank"> <img src = "visualizza / immagine / pagamento / skrill.png" alt = "Skrill" title = "Skrill" style = "border: 1px solid #EEEEEE;" /> </a>';
$_['entry_email']     =  'E-mail';
$_['entry_secret']     =  'Segreto';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_pending_status']     =  'Pending Stato Categoria ';
$_['entry_canceled_status']     =  'Canceled Stato Categoria';
$_['entry_failed_status']     =  'Failed Stato Categoria';
$_['entry_chargeback_status']     =  'Chargeback Stato Categoria';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare Skrill!';
$_['error_email']     =  'E-Mail Obbligatoria!';
