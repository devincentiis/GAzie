<?php 

$_['heading_title']     =  'Ordini di importazione';
$_['text_openbay']     =  'OpenBay Pro';
$_['text_ebay']     =  'eBay';
$_['button_pull_orders']     =  'Inizio';
$_['entry_pull_orders']     =  'Tirare nuovi ordini';
$_['text_sync_pull_notice']     =  'Ciò tirerà nuovi ordini dall\'ultimo controllo automatizzato. Se hai appena installato, allora verrà impostato come default per le ultime 24 ore.';
$_['text_ajax_orders_import']     =  'Ogni nuovo ordine dovrebbe apparire in pochi minuti';
$_['text_complete']     =  'Importato richiesto';
$_['text_failed']     =  'Caricamento fallito';
$_['text_pull']     =  'Richiedi un\'importazione manuale';
$_['error_validation']     =  'Devi registrarsi per il tuo token API e abilitare il modulo.';
