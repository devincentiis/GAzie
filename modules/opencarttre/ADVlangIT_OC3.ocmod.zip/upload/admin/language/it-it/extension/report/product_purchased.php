<?php 

$_['heading_title']     =  'Prodotti Rapporti acquistati';
$_['text_extension']     =  'Estensione';
$_['text_edit']     =  'Modifica prodottos Purchased Report';
$_['text_success']     =  'Riuscito: Hai modificato i prodotti acquistati rapporto!';
$_['text_filter']     =  'Filtro';
$_['text_all_status']     =  'Tutti gli stati';
$_['column_date_start']     =  'Data inizio';
$_['column_date_end']     =  'Data Fine';
$_['column_name']     =  'Nome prodotto';
$_['column_model']     =  'Modello';
$_['column_quantity']     =  'Quantità';
$_['column_total']     =  'Totale';
$_['entry_date_start']     =  'Data inizio';
$_['entry_date_end']     =  'Data Fine';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i prodotti acquistati rapporto!';
