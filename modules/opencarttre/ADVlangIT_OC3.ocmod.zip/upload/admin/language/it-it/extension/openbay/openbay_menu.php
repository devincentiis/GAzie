<?php 

$_['text_openbay_extension']     =  'OpenBay Pro';
$_['text_openbay_dashboard']     =  'Dashboard';
$_['text_openbay_orders']     =  'Aggiornamento dell\'ordine di massa';
$_['text_openbay_items']     =  'Gestire gli elementi';
$_['text_openbay_ebay']     =  'eBay';
$_['text_openbay_amazon']     =  'Amazon (EU)';
$_['text_openbay_amazonus']     =  'Amazon (US)';
$_['text_openbay_etsy']     =  'Etsy';
$_['text_openbay_settings']     =  'impostazioni';
$_['text_openbay_links']     =  'Articoli link';
$_['text_openbay_report_price']     =  'Rapporto sui prezzi';
$_['text_openbay_order_import']     =  'Ordina l\'importazione';
$_['text_openbay_fba']     =  'Fulfillment di Amazon';
$_['text_openbay_fulfillmentlist']     =  'adempimenti';
$_['text_openbay_orderlist']     =  'Ordini';
