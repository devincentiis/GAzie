<?php 

$_['heading_title']     =  'Google Hangouts';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il modulo Google Hangouts!';
$_['text_edit']     =  'Modifica Google Hangouts Module';
$_['entry_code']     =  'Codice di Google Talk';
$_['entry_status']     =  'Stato Categoria';
$_['help_code']     =  'Vai a <a href="https://developers.google.com/+/hangouts/button" target="_blank"> Crea un badge di chatback di Google Hangout </a> e copia & amp; incollare il codice generato nella casella di testo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo Google Hangouts!';
$_['error_code']     =  'Codice richiesto';
