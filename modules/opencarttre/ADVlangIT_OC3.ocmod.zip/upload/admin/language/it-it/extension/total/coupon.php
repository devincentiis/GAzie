<?php 

$_['heading_title']     =  'buono';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato il totale delle cedole!';
$_['text_edit']     =  'Modifica Coupon';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il totale cedola!';
