<?php
// Heading
$_['heading_title'] 		= 'Consenso cookies';
// Text
$_['text_extension']		= 'Estensioni';
$_['text_success']		    = 'Riuscito: hai modificato il modulo per il consenso all\'uso dei cookies!';
$_['text_edit']			    = 'Edita Cookie agreement Module';
// Entry
$_['entry_name']		= 'ID Modulo';
$_['entry_message']		= 'Messaggio';
$_['entry_button_text']			= 'Testo del bottone';
$_['entry_bg_colour'] 	= 'Colore sfondo';
$_['entry_text_colour'] 	= 'Colore testo';
$_['entry_status'] = 'Stato';
$_['entry_cookies_informations'] = 'Link informativa privacy';
$_['entry_informations_text'] = 'Testo del link informativa privacy';
$_['entry_show_type'] = 'Modalità di visualizzazione del popup';

// Placeholder
$_['placeholder_name'] 		= '';
$_['placeholder_message'] 	= '';
$_['placeholder_button_text'] 		= '';
$_['placeholder_bg_colour'] 	= '#ffc520';
$_['placeholder_text_colour'] 	= '#fff';
$_['placeholder_informations_text']   = 'Altre informazioni';
// Error
$_['error_name'] 		= 'ID Modulo vuoto';
$_['error_message'] 		= 'Campo Messaggio vuoto';
$_['error_button_text'] 		= 'Testo del bottone vuoto';
$_['error_bg_colour'] 	= 'Il colore di sfondo non può essere vuoto';
$_['error_text_colour'] 	= 'Il colore del testo non può essere vuoto';
$_['error_informations_text']  = 'Il testo informativa privacy non può essere vuoto';
$_['error_warning'] 		= 'Ci sono problemi con i dati forniti';
$_['error_permission'] 		= 'Non sei autorizzato a modificarlo.';
	
// Button
$_['button_save'] 		= 'Salva il modulo';
$_['button_cancel'] 		= 'Annulla';
