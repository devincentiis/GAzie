<?php 

$_['heading_title']     =  'Rapporti';
$_['text_success']     =  'Riuscito: hai modificato i rapporti!';
$_['text_list']     =  'Elenco dei rapporti';
$_['column_name']     =  'Nome del rapporto';
$_['column_status']     =  'Stato Categoria';
$_['column_sort_order']     =  'Ordina';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i rapporti!';
