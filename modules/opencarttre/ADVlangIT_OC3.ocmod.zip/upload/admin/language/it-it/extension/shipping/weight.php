<?php 

$_['heading_title']     =  'Peso basato sul trasporto';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il trasporto basato sul peso!';
$_['text_edit']     =  'Modifica la spedizione basata sul peso';
$_['entry_rate']     =  'Aliquote';
$_['entry_tax_class']     =  'categoria fiscale';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_rate']     =  'Esempio: 5: 10.00,7: 12.00 Peso: costo, peso: costo, ecc.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare la spedizione in base al peso!';
