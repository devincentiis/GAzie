<?php 

$_['heading_title']     =  'Lay-Buy Layout';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: Hai modificato il modulo Lay-Buy Layout!';
$_['text_edit']     =  'Modifica il modulo Lay-Buy Layout';
$_['entry_status']     =  'Stato Categoria';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo Lay-Buy Layout!';
