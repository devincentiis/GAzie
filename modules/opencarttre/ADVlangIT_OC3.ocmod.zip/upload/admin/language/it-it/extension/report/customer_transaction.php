<?php 

$_['heading_title']     =  'Nome cliente Transaction Report';
$_['text_extension']     =  'Estensione';
$_['text_edit']     =  'Modifica cliente Transaction Report';
$_['text_success']     =  'Riuscito: hai modificato il rapporto di credito al cliente!';
$_['text_filter']     =  'Filtro';
$_['column_customer']     =  'Nome cliente';
$_['column_email']     =  'E-mail';
$_['column_customer_group']     =  'Gruppo Clienti';
$_['column_status']     =  'Stato Categoria';
$_['column_total']     =  'Totale';
$_['column_action']     =  'Azione';
$_['entry_date_start']     =  'Data inizio';
$_['entry_date_end']     =  'Data Fine';
$_['entry_customer']     =  'Nome cliente';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il rapporto di credito al cliente!';
