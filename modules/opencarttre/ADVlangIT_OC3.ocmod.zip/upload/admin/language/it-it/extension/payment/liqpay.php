<?php 

$_['heading_title']     =  'Liqpay';
$_['text_extension']     =  'Estensione';
$_['text_success']     =  'Riuscito: hai modificato i dettagli dell\'account LIQPAY!';
$_['text_edit']     =  'Modifica LIQPAY';
$_['text_pay']     =  'Liqpay';
$_['text_card']     =  'Carta di credito';
$_['text_liqpay']     =  '<img src = "view / image / payment / liqpay.png" alt = "LIQPAY" title = "LIQPAY" style = "confine: 1px solid #EEEEEE;" />';
$_['entry_merchant']     =  'ID Commerciante';
$_['entry_signature']     =  'Firma';
$_['entry_type']     =  'Tipo';
$_['entry_total']     =  'Totale';
$_['entry_order_status']     =  'Stato:';
$_['entry_geo_zone']     =  'Geo Zone';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['help_total']     =  'Il totale dell\'ordine deve arrivare prima che questo metodo di pagamento diventi attivo.';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il pagamento LIQPAY!';
$_['error_merchant']     =  'Obbligatorio ID Merchant!';
$_['error_signature']     =  'Firma richiesta!';
