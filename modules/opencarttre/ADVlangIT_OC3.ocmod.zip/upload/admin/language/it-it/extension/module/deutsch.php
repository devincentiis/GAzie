<?php
// Heading
$_['heading_title']    = 'Lingua tedesca';

// Text
$_['text_extension']   = 'Estensione';
$_['text_success']     = 'La lingua tedesca è stata attivata!';
$_['text_edit']        = 'Abilita la lingua tedesca';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Attenzione permessi mancanti!';