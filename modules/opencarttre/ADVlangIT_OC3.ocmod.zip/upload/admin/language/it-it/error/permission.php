<?php 

$_['heading_title']     =  'Permesso negato!';
$_['text_permission']     =  'Non hai permessi necessari per accedere a questa pagina. Per favore, rivolgiti all\'amministratore.';
