<?php 

$_['heading_title']     =  'Pagina inesistente!';
$_['text_not_found']     =  'La pagina che stavi cercando non pu&ograve; essere trovata. Per favore, contatta l\'amministratore se il problema persiste.';
