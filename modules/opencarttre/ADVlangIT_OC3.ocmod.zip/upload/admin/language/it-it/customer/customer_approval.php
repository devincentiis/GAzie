<?php 

$_['heading_title']     =  'Cliente Approvati';
$_['text_success']     =  'Complimenti: avete modificato le approvazioni dei clienti!';
$_['text_list']     =  'Lista Clienti approvati';
$_['text_default']     =  'Predefinito';
$_['text_customer']     =  'Nome Cliente';
$_['text_affiliate']     =  'Affiliato';
$_['column_name']     =  'Nome cliente';
$_['column_email']     =  'E-mail';
$_['column_customer_group']     =  'Gruppo Clienti';
$_['column_type']     =  'Tipo';
$_['column_date_added']     =  'Aggiunto il';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Nome cliente';
$_['entry_email']     =  'E-mail';
$_['entry_customer_group']     =  'Gruppo Clienti';
$_['entry_type']     =  'Tipo';
$_['entry_date_added']     =  'Aggiunto il';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare le approvazioni dei clienti!';
