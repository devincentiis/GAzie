<?php 

$_['heading_title']     =  'Return Stato Categoriaes';
$_['text_success']     =  'Riuscito: hai modificato gli stati di ritorno!';
$_['text_list']     =  'Return Stato Categoria List';
$_['text_add']     =  'Add Return Stato Categoria';
$_['text_edit']     =  'Edit Return Stato Categoria';
$_['column_name']     =  'Return Stato Categoria Name';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Return Stato Categoria Name';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare gli stati di ritorno!';
$_['error_name']     =  'Return Stato Categoria Name must be between 3 and 32 characters!';
$_['error_default']     =  'Avviso: Questo stato di ritorno non puo\' essere eliminato poiche\' e\' attualmente assegnato come stato di ritorno di default!';
$_['error_return']     =  'Avviso: Questo stato di ritorno non puo\' essere eliminato poiche\' e\' attualmente assegnato a ritorno %s!';
