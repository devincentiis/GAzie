<?php 

$_['heading_title']     =  'Stato Magazzino';
$_['text_success']     =  'Riuscito: hai modificato gli stati delle scorte!';
$_['text_list']     =  'Stock Stato Categoria List';
$_['text_add']     =  'Add Stock Stato Categoria';
$_['text_edit']     =  'Edit Stock Stato Categoria';
$_['column_name']     =  'Stock Stato Categoria Name';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Stock Stato Categoria Name';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare gli stati delle scorte!';
$_['error_name']     =  'Stock Stato Categoria Name must be between 3 and 32 characters!';
$_['error_product']     =  'Avviso: Questo stato di riserva non può essere eliminato poiche\' e\' attualmente assegnato ai prodotti di %s!';
