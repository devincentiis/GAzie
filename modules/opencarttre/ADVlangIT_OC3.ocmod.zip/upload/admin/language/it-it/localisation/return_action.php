<?php 

$_['heading_title']     =  'Azioni di ritorno';
$_['text_success']     =  'Riuscito: hai modificato le azioni di ritorno!';
$_['text_list']     =  'Lista di azioni di ritorno';
$_['text_add']     =  'Aggiungi azione di ritorno';
$_['text_edit']     =  'Modifica azione di ritorno';
$_['column_name']     =  'Nome azione di ritorno';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Nome azione di ritorno';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare le azioni di ritorno!';
$_['error_name']     =  'Nome Azione di ritorno deve essere compresa tra 3 e 64 caratteri!';
$_['error_return']     =  'Avviso: questa azione di ritorno non può essere eliminata poiché è attualmente assegnata ai prodotti restituiti %s!';
