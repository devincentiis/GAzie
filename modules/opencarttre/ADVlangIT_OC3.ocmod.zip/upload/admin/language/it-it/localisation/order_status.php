<?php 

$_['heading_title']     =  'Stato Ordini';
$_['text_success']     =  'Riuscito: hai modificato gli stati dell\'ordine!';
$_['text_list']     =  'Stato: List';
$_['text_add']     =  'Add Stato:';
$_['text_edit']     =  'Edit Stato:';
$_['column_name']     =  'Stato: Name';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Stato: Name';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare gli stati dell\'ordine!';
$_['error_name']     =  'Stato: Name must be between 3 and 32 characters!';
$_['error_default']     =  'Avviso: Questo stato dell\'ordine non può essere eliminato poiché è attualmente assegnato come stato dell\'ordine del negozio predefinito!';
$_['error_download']     =  'Avviso: lo stato dell\'ordine non può essere eliminato poiché è attualmente assegnato allo stato di download predefinito!';
$_['error_store']     =  'Avviso: lo stato dell\'ordine non può essere eliminato poiché è attualmente assegnato ai negozi di %s!';
$_['error_order']     =  'Avviso: lo stato dell\'ordine non può essere eliminato poiché è attualmente assegnato agli ordini di %s!';
