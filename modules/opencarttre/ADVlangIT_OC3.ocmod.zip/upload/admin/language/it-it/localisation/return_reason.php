<?php 

$_['heading_title']     =  'Return Azione resos';
$_['text_success']     =  'Riuscito: avete modificato i motivi di ritorno!';
$_['text_list']     =  'Return Azione reso List';
$_['text_add']     =  'Add Return Azione reso';
$_['text_edit']     =  'Edit Return Azione reso';
$_['column_name']     =  'Return Azione reso Name';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Return Azione reso Name';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare i motivi di ritorno!';
$_['error_name']     =  'Return Azione reso Name must be between 3 and 128 characters!';
$_['error_return']     =  'Avviso: questo motivo di ritorno non può essere eliminato poiché è attualmente assegnato ai prodotti restituiti %s!';
