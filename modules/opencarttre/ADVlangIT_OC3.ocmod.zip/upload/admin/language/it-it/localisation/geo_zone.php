<?php 

$_['heading_title']     =  'Geo Zones';
$_['text_success']     =  'Riuscito: hai modificato le aree geografiche!';
$_['text_list']     =  'Lista Geo Zone';
$_['text_add']     =  'Aggiungi geo zone';
$_['text_edit']     =  'Modifica Geo Zone';
$_['text_geo_zone']     =  'Geo Zones';
$_['column_name']     =  'Nome della zona geo';
$_['column_description']     =  'Descrizione';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Nome della zona geo';
$_['entry_description']     =  'Descrizione';
$_['entry_country']     =  'Nazione';
$_['entry_zone']     =  'Zona';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione a modificare le aree geo!';
$_['error_name']     =  'Il nome della zona geo deve essere compresa tra 3 e 32 caratteri!';
$_['error_description']     =  'Descrizione Il nome deve essere compreso tra 3 e 255 caratteri!';
$_['error_tax_rate']     =  'Attenzione: questa zona geo non può essere eliminata poiché è attualmente assegnata a una o più aliquote fiscali!';
