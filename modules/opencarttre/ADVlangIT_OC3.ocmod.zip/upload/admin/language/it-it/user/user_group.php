<?php 

$_['heading_title']     =  'Gruppi utente';
$_['text_success']     =  'Gruppi utenti modificati correttamente!';
$_['text_list']     =  'Gruppo utente';
$_['text_add']     =  'Aggiungi gruppo utenti';
$_['text_edit']     =  'Modifica gruppo utenti';
$_['column_name']     =  'Nome gruppo';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Nome gruppo';
$_['entry_access']     =  'Permessi di accesso:';
$_['entry_modify']     =  'Permessi di modifica:';
$_['error_permission']     =  'Attenzione: non hai i permessi per modificare i gruppi di utenti!';
$_['error_name']     =  'Il nome del gruppo deve essere tra 3 e 64 caratteri';
$_['error_user']     =  'Questo gruppo non pu&ograve; essere cancellato perch&eacute; &egrave; assegnato a %s utenti!';
