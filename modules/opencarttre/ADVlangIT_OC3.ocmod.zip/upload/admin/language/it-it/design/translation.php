<?php 

$_['heading_title']     =  'Editor delle Lingue';
$_['text_success']     =  'Riuscito: hai modificato editor di lingue!';
$_['text_list']     =  'Lista di traduzione';
$_['text_edit']     =  'Modifica traduzione';
$_['text_add']     =  'Aggiungi transazione';
$_['text_default']     =  'Predefinito';
$_['text_store']     =  'Negozio';
$_['text_language']     =  'Lingua';
$_['column_store']     =  'Negozio';
$_['column_language']     =  'Lingua';
$_['column_route']     =  'Percorso';
$_['column_key']     =  'Chiave';
$_['column_value']     =  'Valore';
$_['column_action']     =  'Azione';
$_['entry_store']     =  'Negozio';
$_['entry_language']     =  'Lingua';
$_['entry_route']     =  'Percorso';
$_['entry_key']     =  'Chiave';
$_['entry_default']     =  'Predefinito';
$_['entry_value']     =  'Valore';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare l\'editor di lingue!';
$_['error_key']     =  'La chiave deve essere compresa tra 3 e 64 caratteri!';
