<?php 

$_['heading_title']     =  'Tema Editor';
$_['text_success']     =  'Riuscito: hai modificato i temi!';
$_['text_edit']     =  'Modifica tema';
$_['text_store']     =  'Scegli il tuo negozio';
$_['text_template']     =  'Scegli un modello';
$_['text_default']     =  'Predefinito';
$_['text_history']     =  'Storia del tema';
$_['text_twig']     =  'L\'editor di temi utilizza il linguaggio template Twig. Puoi leggere qui <a href="http://twig.sensiolabs.org/documentation" target="_blank" class="alert-link"> la sintassi di Twig </a>.';
$_['column_store']     =  'Negozio';
$_['column_route']     =  'Itinerario';
$_['column_theme']     =  'Tema';
$_['column_date_added']     =  'Aggiunto il';
$_['column_action']     =  'Azione';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione a modificare l\'editor di temi!';
$_['error_twig']     =  'Attenzione: è possibile salvare solo file .twig!';
