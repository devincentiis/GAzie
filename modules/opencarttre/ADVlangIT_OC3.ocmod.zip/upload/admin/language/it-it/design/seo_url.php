<?php 

$_['heading_title']     =  'Url SEO';
$_['text_success']     =  'Success: You have modified Url SEO!';
$_['text_list']     =  'Url SEO List';
$_['text_add']     =  'Add Url SEO';
$_['text_edit']     =  'Edit Url SEO';
$_['text_filter']     =  'Filtro';
$_['text_default']     =  'Predefinito';
$_['column_query']     =  'domanda';
$_['column_keyword']     =  'Parola chiave';
$_['column_store']     =  'Negozio';
$_['column_language']     =  'Lingua';
$_['column_action']     =  'Azione';
$_['entry_query']     =  'domanda';
$_['entry_keyword']     =  'Parola chiave';
$_['entry_store']     =  'Negozio';
$_['entry_language']     =  'Lingua';
$_['error_permission']     =  'Attenzione: non hai i permessi per modificare la url SEO!';
$_['error_query']     =  'La query deve essere compresa tra 3 e 64 caratteri!';
$_['error_keyword']     =  'La parola chiave deve essere compresa tra 3 e 64 caratteri!';
$_['error_exists']     =  'Parola chiave gia\' in uso!';
