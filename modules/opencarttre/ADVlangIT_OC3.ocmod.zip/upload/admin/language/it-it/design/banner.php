<?php 

$_['heading_title']     =  'Banner';
$_['text_success']     =  'Hai modificato il banner con successo!';
$_['text_list']     =  'Elenco banner';
$_['text_add']     =  'Aggiungi banner';
$_['text_edit']     =  'Modifica banner';
$_['text_default']     =  'Predefinito';
$_['column_name']     =  'Nome Banner';
$_['column_status']     =  'Stato Categoria';
$_['column_action']     =  'Azione';
$_['entry_name']     =  'Nome Banner';
$_['entry_title']     =  'Titolo';
$_['entry_link']     =  'Collegamento';
$_['entry_image']     =  'Immagine categoria';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['error_permission']     =  'Attenzione: Non hai il permesso di modificare i banner!';
$_['error_name']     =  'Nome Banner deve essere lungo dai 3 ai 64 caratteri!';
$_['error_title']     =  'Titolo Banner deve essere lungo dai 2 ai 64 caratteri!';
