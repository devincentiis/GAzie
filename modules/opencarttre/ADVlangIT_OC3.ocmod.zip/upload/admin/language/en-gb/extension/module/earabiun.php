<?php
// Heading
$_['heading_title']    = 'Arabic language';

// Text
$_['text_extension']   = 'Extension';
$_['text_success']     = 'Arabic language activated!';
$_['text_edit']        = 'Edit Arabic language';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Arabic language!';