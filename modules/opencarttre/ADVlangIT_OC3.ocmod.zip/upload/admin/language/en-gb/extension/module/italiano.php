<?php
// Heading
$_['heading_title']    = 'Italian language';

// Text
$_['text_extension']   = 'Extension';
$_['text_success']     = 'Italian language activated!';
$_['text_edit']        = 'Edit italian language';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify italian language!';