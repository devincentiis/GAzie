<?php
// Heading
$_['heading_title']    = 'Chinese language';

// Text
$_['text_extension']   = 'Extension';
$_['text_success']     = 'Chinese language activated!';
$_['text_edit']        = 'Edit Chinese language';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Chinese language!';