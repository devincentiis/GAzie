<?php
// Heading
$_['heading_title']    = 'Spanish language';

// Text
$_['text_extension']   = 'Extension';
$_['text_success']     = 'Spanish language activated!';
$_['text_edit']        = 'Edit spanish language';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify spanish language!';