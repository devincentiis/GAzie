<?php
// Heading
$_['heading_title']    = 'Idioma español';

// Text
$_['text_extension']   = 'Extensión';
$_['text_success']     = 'Idioma español activado.!';
$_['text_edit']        = 'Habilitar idioma español.';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Atención faltan permisos!';