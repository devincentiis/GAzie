<?php
// Heading
$_['heading_title']    = 'Idioma aleman';

// Text
$_['text_extension']   = 'Extensión';
$_['text_success']     = 'Idioma aleman activado.!';
$_['text_edit']        = 'Habilitar idioma aleman.';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Atención faltan permisos!';