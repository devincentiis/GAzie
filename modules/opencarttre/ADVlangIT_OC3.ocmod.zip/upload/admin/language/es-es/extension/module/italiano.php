<?php
// Heading
$_['heading_title']    = 'Idioma italiano';

// Text
$_['text_extension']   = 'Extensión';
$_['text_success']     = 'Idioma italiano activado.!';
$_['text_edit']        = 'Habilitar idioma italiano.';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Atención faltan permisos!';