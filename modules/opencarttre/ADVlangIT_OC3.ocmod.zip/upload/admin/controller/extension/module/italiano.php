<?php
class ControllerExtensionModuleItaliano extends Controller {
	private $error = [];

	public function index() {
		$this->load->language('extension/module/italiano');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('module_italiano', $this->request->post);
			
			// parallelamente setto pure lo status in language	
			$this->load->model('localisation/language');
			$italian_data = $this->model_localisation_language->getLanguageByCode('it-it');
			$italian_data['status'] = $this->request->post['module_italiano_status'];
			$this->model_localisation_language->editLanguage($italian_data['language_id'],$italian_data);
		
			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/italiano', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/module/italiano', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		if (isset($this->request->post['module_italiano_status'])) {
			$data['module_italiano_status'] = $this->request->post['module_italiano_status'];
		} else {
			$data['module_italiano_status'] = $this->config->get('module_italiano_status');
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/italiano', $data));
	}

	public function install() {
		$this->load->model('extension/module/italiano');
		$this->model_extension_module_italiano->install();
	}

	public function uninstall() {
		$this->load->model('extension/module/italiano');
		$this->model_extension_module_italiano->uninstall();
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/italiano')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		return !$this->error;
	}
}
