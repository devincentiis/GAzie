<?php 

$_['heading_title']     =  'Il tuo account affiliato è stato creato!';
$_['text_message']     =  '<P> Congratulazioni! Il tuo nuovo account è stato creato con successo! </P> <p> Sei membro di affiliati di %s. </P> <p> Se hai domande sul funzionamento di questo sistema di affiliazione, proprietario del negozio. </p> <p> Una conferma è stata inviata all\'indirizzo e-mail fornito. Se non l\'hai ricevuto entro un\'ora, <a href="%s"> contattaci </a>. </P>';
$_['text_approval']     =  '<p> Ti ringraziamo per averci registrato per un conto affiliato con %s! </p> <p> Sarai avvisato via e-mail quando il tuo account è stato attivato dal proprietario del negozio. </p> <p> hai qualsiasi domanda sul funzionamento di questo sistema di affiliazione, <a href="%s"> contatta il proprietario del negozio </a>. </p>';
$_['text_account']     =  'account';
$_['text_success']     =  'Successo';
