<?php
// Heading
$_['heading_title'] = 'Il tuo Ordine &egrave; stato inoltrato!';

// Text
$_['text_customer']  = '<p>Il tuo ordine &egrave; stato preso in carico con successo!</p><p><br/>Puoi vedere la cronologia ordine andando su <a href="%s"><i class="fas fa-user"></i>Cliente</a> cliccando su <a href="%s">Cronologia</a>.</p><p>Se hai qualche dubbio per favore <a href="%s">contattaci</a>.</p><p>Grazie per aver acquistato sul sito!</p>';
$_['text_guest']    = '<p>Il tuo ordine &egrave; stato processato con successo!</p><p>Se hai qualche domanda, per favore <a href="%s">contattaci</a>.</p><p>Grazie per aver acquistato sul sito!</p>';
$_['text_basket']   = 'Cestino';
$_['text_checkout'] = 'Acquisto';
$_['text_success']  = 'Successo';