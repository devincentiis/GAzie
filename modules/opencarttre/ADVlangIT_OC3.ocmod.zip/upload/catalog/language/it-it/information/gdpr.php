<?php
// Heading
$_['heading_title']     =  'Regolamento Generale sulla Protezione dei Dati (GDPR)';

// Text
$_['text_account']      = 'Utente';
$_['text_gdpr']         = 'Puoi vedere la  GDPR policy di %s sulla pagina <a href="%s" target="_blank">%s</a>';
$_['text_verification'] = 'Verifica dell\'utente';
$_['text_email']        = 'Prima di poter eseguire qualsiasi richiesta GDPR, si deve convalidare l\'account: per favore inserisci la tua email qui sotto. ';
$_['text_action']       = 'Scegli un\'azione ';
$_['text_export']       = 'Esportare i dati personali';
$_['text_remove']       = 'Rimuovere i dati personali';
$_['text_warning']      = 'Attenzione perderai l\'accesso al tuo account !';
$_['text_access']       = 'Non avrai più accesso al tuo account su %s';
$_['text_history']      = 'Non avrai più accesso alla cronologia degli ordini, alle fatture, alle liste dei desideri o ai download. ';
$_['text_limit']        = 'Le richieste di cancellazione dell\'account verranno eseguite dopo <strong>%s days</strong> giorni in modo da poter elaborare qualsiasi rilevamento di frode, storno di addebito o rimborso.';
$_['text_success']      = 'Riuscito: una e-mail è stata inviata al tuo indirizzo!';

// Entry
$_['entry_email']       = 'E-Mail';

// Error
$_['error_email']       = 'L\'indirizzo e-mail non sembra essere valido!';
$_['error_action']      = 'Devi selezionare un\'azione GDPR valida !';
$_['error_captcha']      = 'Il codice inserito non corrisponde all\'immagine!';

// Cookie
$_['cookie_head'] = 'Sotto è riportata la tua scelta dei cookie';
$_['cookie_body'] = 'Se vuoi puoi eventualmente selezionare una combinazione differente considerando che le modifiche non sortiranno effetti sul passato ma avranno efficacia dal momento stesso in cui verranno apportate fino alla prossima';
