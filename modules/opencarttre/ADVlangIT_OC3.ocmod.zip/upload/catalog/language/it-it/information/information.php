<?php
// Text
$_['text_error'] = 'Errore 404 Pagina non trovata!';