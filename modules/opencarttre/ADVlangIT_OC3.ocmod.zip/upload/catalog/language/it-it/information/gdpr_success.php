<?php
// Heading
$_['heading_title'] = 'Richiesta GDPR inoltrata con successo';

// Text
$_['text_account']  = 'Account';
$_['text_export']   = 'Abbiamo ricevuto la richiesta di esportazione dati GDPR del tuo account.';
$_['text_remove']   = 'La cancellazione dei dati GDPR del tuo account verrà processato dopo <strong>%s giorni</strong> in modo che eventuali storni di addebito, rimborsi o rilevamento di frodi possano essere elaborati.';
