<?php
// Heading
$_['heading_title']    = 'Site Map';

// Text
$_['text_special']     = 'Promozioni';
$_['text_account']     = 'Il mio Account';
$_['text_edit']        = 'Modifica Account';
$_['text_password']    = 'Password';
$_['text_address']     = 'Indirizzi';
$_['text_history']     = 'Ordini precedenti';
$_['text_download']    = 'Downloads';
$_['text_cart']        = 'Carrello';
$_['text_checkout']    = 'Checkout';
$_['text_search']      = 'Cerca';
$_['text_information'] = 'Informazioni';
$_['text_contact']     = 'Contattaci';