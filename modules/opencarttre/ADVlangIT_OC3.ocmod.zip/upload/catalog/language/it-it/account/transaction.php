<?php
// Heading
$_['heading_title']      = 'Le tue transazioni';

// Column
$_['column_date_added']  = 'Data di creazione';
$_['column_description'] = 'Descrizione';
$_['column_amount']      = 'Importo (%s)';

// Text
$_['text_account']       = 'Account';
$_['text_transaction']   = 'Le tue transazioni';
$_['text_total']         = 'Il tuo saldo attuale è:';
$_['text_no_results']         = 'Non hai transazioni!';