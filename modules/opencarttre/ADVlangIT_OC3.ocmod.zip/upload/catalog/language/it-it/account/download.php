<?php
// Heading
$_['heading_title']     = 'Downloads';

// Text
$_['text_account']      = 'Account';
$_['text_downloads']    = 'Downloads';
$_['text_no_results']   = 'Non ci sono ordini di downloads precedenti!';

// Column
$_['column_order_id']   = 'ID ordine';
$_['column_name']       = 'Name';
$_['column_size']       = 'Grandezza';
$_['column_date_added'] = 'Data';