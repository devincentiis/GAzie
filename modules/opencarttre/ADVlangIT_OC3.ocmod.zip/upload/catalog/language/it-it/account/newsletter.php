<?php
// Heading 
$_['heading_title']    = 'Iscrizioni Newsletter';

// Text
$_['text_account']     = 'Account';
$_['text_newsletter']  = 'Newsletter';
$_['text_success']     = 'Iscrizione alla newsletter effettuata con successo!';

// Entry
$_['entry_newsletter'] = 'Sottoscrivi:';