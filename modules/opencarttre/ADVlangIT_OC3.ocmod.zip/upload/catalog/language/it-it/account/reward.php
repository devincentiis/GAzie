<?php
// Heading 
$_['heading_title']      = 'Punti Fedelt&agrave;';

// Column
$_['column_date_added']  = 'Data di Inserimento';
$_['column_description'] = 'Descrizione';
$_['column_points']      = 'Punti';

// Text
$_['text_account']       = 'Account';
$_['text_reward']        = 'Punti Fedelt&agrave;';
$_['text_total']         = 'Il totale dei tuoi Punti Fedeltà:';
$_['text_no_results']         = 'Non hai Punti Fedeltà!';