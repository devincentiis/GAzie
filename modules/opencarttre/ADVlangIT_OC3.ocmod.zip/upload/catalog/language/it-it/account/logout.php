<?php
// Heading 
$_['heading_title'] = 'Uscita Account';

// Text
$_['text_message']  = '<p>Disconnessione account effettuata.</p><p>Il tuo carrello &egrave; stato salvato e verr&agrave; ripristinato al prossimo accesso.</p>';
$_['text_account']  = 'Account';
$_['text_logout']   = 'Esci';