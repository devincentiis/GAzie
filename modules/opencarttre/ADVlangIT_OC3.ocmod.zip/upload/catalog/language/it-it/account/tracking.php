<?php 

$_['heading_title']     =  'Tracciamento affiliati';
$_['text_account']     =  'account';
$_['text_description']     =  'Per essere sicuri di essere rimborsati per i rinvii inviati a noi, dobbiamo seguire il referral inserendo un codice di monitoraggio nel collegamento dell\'URL a noi. È possibile utilizzare gli strumenti riportati di seguito per generare collegamenti al sito web di %s.';
$_['entry_code']     =  'Il tuo Codice di Tracciamento';
$_['entry_generator']     =  'Tracciamento del generatore di collegamenti';
$_['entry_link']     =  'Collegamento di monitoraggio';
$_['help_generator']     =  'Digitare il nome di un prodotto a cui si desidera collegare';
