<?php 

$_['code']               =  'it';
$_['direction']          =  'ltr';
$_['date_format_short']  =  'd / m / Y';
$_['date_format_long']   =  'l dS F Y';
$_['time_format']        =  'h: i: s A';
$_['datetime_format']    =  'd / m / Y H: i: s';
$_['decimal_point']      =  '.';
$_['thousand_point']     =  ',';

// Text
$_['text_home']          =  '<i class = "fa fa-home"> </i>';
$_['text_yes']           =  'Si';
$_['text_no']            =  'No';
$_['text_none']          =  '--- Nessuno ---';
$_['text_select']        =  ' --- Seleziona --- ';
$_['text_all_zones']     =  'Tutte le zone';
$_['text_pagination']    =  'Mostra %d a %d di %d (%d pagine)';
$_['text_loading']       =  'Caricamento in corso...';
$_['text_no_results']    =  'Nessun risultato!';
$_['text_tax']           =  'Imposte escluse:';
$_['text_label_sale']    =  'Vendita';
$_['text_label_new']     =  'New';
$_['text_booking']     	 =  'Prenotazione';


// Buttons
$_['button_address_add'] =  'Aggiungi indiizzo';
$_['button_back']        =  'Indietro';
$_['button_continue']    =  'Continua';
$_['button_cart']        =  'Aggiungi al carrello';
$_['button_cancel']      =  'Annulla';
$_['button_compare']     =  'Confronta questo prodotto';
$_['button_wishlist']    =  'Aggiungi alla lista dei preferiti';
$_['button_checkout']    =  'Acquista';
$_['button_confirm']     =  'Conferma Ordine';
$_['button_coupon']      =  'Applica';
$_['button_delete']      =  'Elimina';
$_['button_download']    =  'Scaricare';
$_['button_edit']        =  'Modifica';
$_['button_filter']      =  'Affina la ricerca';
$_['button_new_address'] =  'Nuovo indirizzo';
$_['button_change_address']     =  'Cambia indirizzo';
$_['button_reviews']     =  'Recensioni';
$_['button_write']       =  'Scrivi una recensione';
$_['button_login']       =  'Accedi';
$_['button_update']      =  'Aggiorna';
$_['button_remove']      =  'Rimuovi';
$_['button_reorder']     =  'Riordina';
$_['button_return']      =  'Reso';
$_['button_shopping']    =  'Continua lo shopping';
$_['button_search']      =  'Ricerca';
$_['button_shipping']    =  'Applica';
$_['button_submit']      =  'Invia';
$_['button_guest']       =  'Acquisto ospite';
$_['button_view']        =  'Vedi';
$_['button_voucher']     =  'Applica';
$_['button_upload']      =  'Caricare un file';
$_['button_reward']      =  'Applica';
$_['button_quote']       =  'Calcola le spese di trasporto';
$_['button_list']        =  'Elenco';
$_['button_grid']        =  'Griglia';
$_['button_map']         =  'Visualizza Google Map';
$_['button_quickview']   =  'Vista rapida';


// Error
$_['error_exception']    =  'Codice di errore (%s): %s in %s sulla riga %s';
$_['error_upload_1']     =  'Attenzione: Il file caricato eccede la dimensione massima caricabile impostata nel php.ini (upload_max_filesize)!';
$_['error_upload_2']     =  'Attenzione: Il file caricato eccede la dimensione massima caricabile impostata nel parametro MAX_FILE_SIZE nel form HTML!';
$_['error_upload_3']     =  'Attenzione: Il file caricato &eacute; stato caricato solo parzialmente!';
$_['error_upload_4']     =  'Attenzione: Nessun file caricato!';
$_['error_upload_6']     =  'Attenzione: cartella temporanea mancante!';
$_['error_upload_7']     =  'Attenzione: scrittura del file su disco fallita!';
$_['error_upload_8']     =  'Attenzione: file caricato con estensione non permessa!';
$_['error_upload_999']   =  'Attenzione: errore sconosciuto!';
$_['error_curl']         =  'CURL: Codice di errore (%s): %s';
$_['datepicker']         =  'it-it';


