<?php 

$_['text_subject']     =  '%s - Commissione di affiliazione';
$_['text_received']     =  'Complimenti! Hai ricevuto un pagamento di commissione dal programma di affiliazione di %s';
$_['text_amount']     =  'Hai ricevuto:';
$_['text_total']     =  'L\'importo totale della commissione è ora:';
