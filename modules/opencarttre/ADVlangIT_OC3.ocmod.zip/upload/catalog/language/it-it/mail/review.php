<?php
// Text
$_['text_subject']  = '%s - Recensione Prodotto';
$_['text_waiting']  = 'Hai una nuova recensione del prodotto in attesa.';
$_['text_product']  = 'Prodotto: %s';
$_['text_reviewer'] = 'Recensione: %s';
$_['text_rating']   = 'Voto: %s';
$_['text_review']   = 'Testo Recensione:';