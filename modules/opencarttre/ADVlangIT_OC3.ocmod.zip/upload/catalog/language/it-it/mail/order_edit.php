<?php
// Text
$_['text_subject']      = '%s - Aggiornamenti Ordine %s';
$_['text_order_id']     = 'ID Ordine:';
$_['text_date_added']   = 'Data Ordine:';
$_['text_order_status'] = 'Il tuo ordine è stato aggiornato al seguente stato:';
$_['text_comment']      = 'Commenti Ordine:';
$_['text_link']         = 'Per visualizzare il tuo ordine clicca sul link sottostante:';
$_['text_footer']       = 'Si prega di rispondere a questa e-mail se avete domande.';