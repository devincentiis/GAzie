<?php
// Text
$_['text_subject']        = '%s - Grazie per esserti registrata/o';
$_['text_welcome']        = 'Benvenuta/o e grazie per esserti registrata/o sul sito %s';
$_['text_login']          = 'Il tuo account è ora stato creato e puoi accedere utilizzando il tuo indirizzo email e la password, visitando il sito web o al seguente URL:';
$_['text_approval']       = 'Il tuo account deve essere approvato prima di poter accedere. Una volta approvato, puoi accedere utilizzando il tuo indirizzo E-Mail e la password visitando il nostro sito web o al seguente URL:';
$_['text_service']        = 'Dopo aver effettuato l\'accesso, potrai usufruire di altri servizi tra cui la visione degli ordini passati, la stampa degli stessi e la modifica delle informazioni sul tuo account.';
$_['text_thanks']         = 'Grazie,';
$_['text_new_customer']   = 'Nuovo utente registrato';
$_['text_signup']         = 'Un nuovo cliente si è registrato:';
$_['text_customer_group'] = 'Gruppo clienti:';
$_['text_firstname']      = 'Nome:';
$_['text_lastname']       = 'Cognome:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = 'Telefono:';

$_['button_login']        = 'Accedi';