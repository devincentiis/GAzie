<?php
// Text
$_['text_subject']  = 'Ti è stata inviata una GIFT CARD da %s';
$_['text_greeting'] = 'Congratulazioni, hai ricevuto un buono regalo (GIFT CARD) %s';
$_['text_from']     = 'Questo buono regalo ti è stato inviato da %s';
$_['text_message']  = 'Con un messaggio che dice';
$_['text_redeem']   = 'Per riscattare questo buono regalo, annota il codice di riscatto che è <b> % s </ b>, quindi fai clic sul link sottostante e acquista il prodotto su cui desideri utilizzare questo buono regalo. È possibile inserire il codice del buono regalo nella pagina del carrello prima di iniziare la procedura di pagamento.';
$_['text_footer']   = 'Si prega di rispondere a questa e-mail se avete domande.';