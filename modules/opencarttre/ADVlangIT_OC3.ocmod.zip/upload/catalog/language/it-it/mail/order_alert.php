<?php
// Text
$_['text_subject']      = '%s - Ordine %s';
$_['text_received']     = 'Hai ricevuto un nuovo ordine.';
$_['text_order_id']     = 'ID Ordine:';
$_['text_date_added']   = 'Data Ordine:';
$_['text_order_status'] = 'Stato Ordine:';
$_['text_product']      = 'Prodotti';
$_['text_total']        = 'Totali';
$_['text_comment']      = 'Commenti:';
