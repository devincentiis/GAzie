<?php
// Text
$_['text_subject']  = '%s - Richiesta di reimpostazione della password:';
$_['text_greeting'] = 'È stata richiesta una nuova password per l\'account cliente %s .';
$_['text_change']   = 'Per resettare la tua password clicca sul link sottostante:';
$_['text_ip']       = 'L\'IP utilizzato per fare questa richiesta era:';