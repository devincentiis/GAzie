<?php
// Text
$_['text_success']       = 'Hai modificato i clienti con successo';

// Error
$_['error_permission']   = 'Avviso. Non hai l/autorizzazione per accedere alle API!';
$_['error_customer']     = 'Devi selezionare un Cliente!';
$_['error_firstname']    = 'Il nome deve essere compreso tra 1 e 32 caratteri!';
$_['error_lastname']     = 'Il cognome deve essere compreso tra 1 e 32 caratteri!';
$_['error_email']        = 'L/indirizzo e-mail non sembra essere valido!';
$_['error_telephone']    = 'Il telefono deve essere compreso tra 3 e 32 caratteri!';
$_['error_custom_field'] = '%s richiesto!';