<?php 

$_['text_success']     =  'Riuscito: la tua valuta è stata cambiata!';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione ad accedere alle API!';
$_['error_currency']     =  'Attenzione: il codice valuta non è valido!';
