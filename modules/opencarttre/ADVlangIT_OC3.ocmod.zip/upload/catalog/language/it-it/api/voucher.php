<?php 

$_['text_success']     =  'Riuscito: Lo sconto del buono regalo è stato applicato!';
$_['text_cart']     =  'Riuscito: hai modificato il tuo carrello di spesa!';
$_['text_for']     =  '%s buono regalo per %s';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione ad accedere alle API!';
$_['error_voucher']     =  'Avviso: Il buono regalo è invalido o il saldo è stato esaurito!';
$_['error_to_name']     =  'Il nome del Destinatario deve essere lungo da 1 a 64 caratteri!';
$_['error_from_name']     =  'Il tuo nome deve essere da 1 a 64 caratteri!';
$_['error_email']     =  'L\'indirizzo Email non &egrave valido!';
$_['error_theme']     =  'È necessario selezionare un tema!';
$_['error_amount']     =  'L\'importo deve essere compreso tra %s e %s!';
