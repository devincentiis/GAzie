<?php
// Text
$_['text_success'] = 'Riuscito: la sessione API è stata avviata correttamente!';

// Error
$_['error_key']    = 'Avviso: chiave API errata!';
$_['error_ip']     = 'Avviso: il tuo IP %s non è autorizzato ad accedere a questa API';