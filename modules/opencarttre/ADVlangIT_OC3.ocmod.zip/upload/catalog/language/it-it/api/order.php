<?php 

$_['text_success']     =  'Hai modificato gli ordini con successo!';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione ad accedere alle API!';
$_['error_customer']     =  'Attenzione: Nome cliente richiesto!';
$_['error_payment_address']     =  'Avviso: Indirizzo di pagamento richiesto!';
$_['error_payment_method']     =  'Attenzione: Metodo di pagamento richiesto!';
$_['error_no_payment']     =  'Attenzione: non sono disponibili opzioni di pagamento!';
$_['error_shipping_address']     =  'Avviso: Indirizzo di spedizione richiesto!';
$_['error_shipping_method']     =  'Attenzione: Metodo di spedizione richiesto!';
$_['error_no_shipping']     =  'Attenzione: non sono disponibili opzioni di spedizione!';
$_['error_stock']     =  'Attenzione: i prodotti contrassegnati con *** non sono disponibili nella quantità desiderata o non sono disponibili!';
$_['error_minimum']     =  'Avviso: L\'importo minimo di ordine per %s è %s!';
$_['error_not_found']     =  'Attenzione: l\'ordine non è stato trovato!';
