<?php 

$_['text_success']     =  'E\' stato applicato il tuo sconto bonus con successo!';
$_['error_permission']     =  'Avviso: Non hai l\'autorizzazione ad accedere alle API!';
$_['error_reward']     =  'Attenzione: Inserisci l\'importo dei punti di ricompensa da utilizzare!';
$_['error_points']     =  'Avviso: non hai %s punti di ricompensa!';
$_['error_maximum']     =  'Attenzione: il numero massimo di punti applicabili è %s!';
