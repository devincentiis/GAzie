<?php
// Text
$_['text_success']     = 'Riuscito: hai modificato il tuo carrello!';

// Error
$_['error_permission'] = 'Avviso. Non sei autorizzato ad accedere alle API!';
$_['error_stock']      = 'I prodotti contrassegnati con *** non sono disponibili nella quantità desiderata o non disponibili!';
$_['error_minimum']    = 'Importo minimo dell/ordine per %s è %s!';
$_['error_store']      = 'Il prodotto non può essere acquistato dal negozio che hai scelto!';
$_['error_required']   = '%s richiesto!';