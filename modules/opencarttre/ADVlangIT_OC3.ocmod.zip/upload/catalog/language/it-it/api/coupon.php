<?php
// Text
$_['text_success']     = 'Complimenti: è stato applicato lo sconto coupon!';

// Error
$_['error_permission'] = 'Avviso. Non hai l/autorizzazione per accedere alle API!';
$_['error_coupon']     = 'Attenzione: il coupon non è valido, è scaduto o ha raggiunto il limite di utilizzo!';