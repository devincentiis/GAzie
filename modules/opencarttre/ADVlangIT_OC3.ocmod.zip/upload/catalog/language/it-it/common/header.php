<?php
// Text
$_['text_home']          = 'Home';
$_['text_wishlist']      = 'Lista dei preferiti (%s)';
$_['text_shopping_cart'] = 'Carrello della Spesa';
$_['text_category']      = 'Menù';
$_['text_account']       = 'Clienti';
$_['text_register']      = 'Registrazione';
$_['text_login']         = 'Accesso';
$_['text_order']         = 'Cronologia Ordini';
$_['text_transaction']   = 'Transazioni';
$_['text_download']      = 'Download';
$_['text_logout']        = 'Esci';
$_['text_checkout']      = 'Cassa';
$_['text_search']        = 'Cerca';
$_['text_all']           = 'Mostra Tutto';
$_['text_setting']       = 'Impostazioni';
$_['this_website_is_using_cookies'] = "Questo sito si avvale di cookies.";
$_['cookies_popup_text'] = "Noi usiamo i cookies per assicurarti una migliore navigazione del sito. Se continui senza cambiare le impostazioni supponiamo che tu sia consapevole di ricevere tutti i cookie da questo sito web.";
$_['cookie_popup_continue'] = "Continua";
$_['cookie_popup_learn_more'] = "Più informazioni";