<?php
// Text
$_['text_success'] = 'Grazie per averci fatto conoscere la tua scelta';
$_['text_cookie'] = 'Questo sito usa i cookies per <a href="%s" class="btn btn-xs alert-link agree"> maggiori informazioni CLICCA QUI</a>';
$_['text_cookie_title'] = 'Questo sito web utilizza i cookie.';
$_['text_cookie_body'] = 'Li utilizza con il fine di personalizzare  i contenuti e gli annunci, per analizzare il traffico, e per fornire le funzionalità dei social media. Potrebbe condividere le informazioni sul tuo utilizzo di questo sito con partner di social media, pubblicità e analisi. Normalmente questi li combinano con altre informazioni che hai fornito loro o che hanno raccolto su altri siti che hai visitato.  Per <a href="%s" class="btn btn-xs alert-link agree"> maggiori informazioni clicca qui.</a>';
$_['text_cookie_necessary']= 'Necessari';
$_['text_cookie_necessary_title']= 'Obbligatorio - non può essere deselezionato. I cookie tecnici sono necessari, aiutano a rendere fruibile un sito web abilitando le funzioni di base come la navigazione della pagina e l\'accesso alle aree protette del sito. Il sito web non può funzionare correttamente senza questi cookie.';
$_['text_cookie_preferences']= 'Preferenze';
$_['text_cookie_preferences_title']= 'I cookie di preferenza consentono a un sito web di ricordare le informazioni che cambiano il modo in cui il sito web si comporta o appare, come la tua lingua preferita o la regione in cui ti trovi.';
$_['text_cookie_statistics']= 'Statistici';
$_['text_cookie_statistics_title']= 'I cookie statistici aiutano i proprietari di siti web a capire come i visitatori interagiscono con i siti raccogliendo e riportando informazioni in forma anonima.';
$_['text_cookie_marketing']= 'Marketing';
$_['text_cookie_marketing_title']= 'I cookie di marketing vengono utilizzati per tracciare i visitatori sui siti Web. L\'intenzione è quella di visualizzare annunci pertinenti e coinvolgenti per il singolo utente e quindi di maggior valore per gli editori e gli inserzionisti di terze parti.';

// Button
$_['button_agree']    = 'Accetta';
$_['button_disagree'] = 'Rifiuta';
$_['button_close'] = 'Accetta e chiudi ';
$_['button_notallow']    = 'Solo i necessari';
$_['button_onlyselected'] = 'Solo selezionati';
$_['button_allowall'] = 'Accetta e chiudi ';