<?php 

$_['text_currency']     =  'Valuta';
