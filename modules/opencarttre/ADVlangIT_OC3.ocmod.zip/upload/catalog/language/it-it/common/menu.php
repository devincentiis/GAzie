<?php 

$_['text_all']     =  'Mostra tutto';
