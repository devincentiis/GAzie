<?php 

$_['text_language']     =  'Lingua';
