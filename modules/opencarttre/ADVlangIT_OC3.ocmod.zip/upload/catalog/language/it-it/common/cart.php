<?php
// Text
$_['text_items']     = '%s nel carrello';
$_['text_empty']     = 'Il tuo carrello è vuoto!';
$_['text_cart']      = 'Vedi carrello';
$_['text_checkout']  = 'Completa l\'ordine';
$_['text_recurring'] = 'Profilo di pagamento';