<?php
// Text
$_['text_search'] = 'Cerca prodotto';