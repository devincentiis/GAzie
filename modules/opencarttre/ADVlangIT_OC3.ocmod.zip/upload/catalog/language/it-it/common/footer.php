<?php
// Text
$_['text_information']  = 'Informazioni';
$_['text_service']      = 'Servizio Clienti';
$_['text_extra']        = 'Extra';
$_['text_contact']      = 'Contatti';
$_['text_return']       = 'Resi';
$_['text_sitemap']      = 'Mappa del Sito';
$_['text_gdpr']         = 'GDPR';
$_['text_manufacturer'] = 'Brand';
$_['text_voucher']      = 'Buoni Regalo';
$_['text_affiliate']    = 'Affiliati';
$_['text_special']      = 'Speciali';
$_['text_account']      = 'Il tuo Account';
$_['text_order']        = 'I tuoi Ordini';
$_['text_wishlist']     = 'Lista dei preferiti';
$_['text_newsletter']   = 'Newsletter';
$_['text_powered']      = 'Powered By <a href="https://www.opencart.com">OpenCart</a> & <a href="https://www.devincentiis.it">ADVisor</a> <br /> %s &copy; %s';