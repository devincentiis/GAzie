<?php
// Heading
$_['heading_title']    = 'Sito in Manutenzione';

// Text
$_['text_maintenance'] = 'Lavori in corso!';
$_['text_message']     = '<h1 style="text-align:center;">Attualmente stiamo eseguendo alcuni interventi di manutenzione programmata. <br/><br>Torneremo on-line il prima possibile. Si prega di ricontrollare presto.</h1>';