<?php
// Text
$_['text_search']              = 'Cerca';
$_['text_brand']               = 'Marchio';
$_['text_manufacturer']        = 'Produttore:';
$_['text_model']               = 'Codice prodotto:';
$_['text_reward']              = 'Punti premio:';
$_['text_points']              = 'Punti premi per prezzo:';
$_['text_stock']               = 'Disponibilità:';
$_['text_instock']             = 'In magazzino';
$_['text_tax']                 = 'imp.:';
$_['text_discount']            = ' o più ';
$_['text_option']              = 'Opzioni disponibili';
$_['text_minimum']             = 'Quantità minima acquistabile %s';
$_['text_reviews']             = '%s recensioni';
$_['text_write']               = 'Scrivi una recensione';
$_['text_login']               = 'Effettua <a href="%s">l\'accesso</a> o <a href="%s">registrati</a> per recensire';
$_['text_no_reviews']          = 'Non ci sono recensioni per questo prodotto.';
$_['text_note']                = '<span class="text-danger">Nota:</span> HTML non tradotto!';
$_['text_success']             = 'Grazie per la tua opinione. È stato inviato al webmaster per l\'approvazione.';
$_['text_related']             = 'Prodotti collegati';
$_['text_tags']                = 'Tags:';
$_['text_error']               = 'Prodotto non trovato!';
$_['text_payment_recurring']   = 'Profilo di pagamento';
$_['text_trial_description']   = '%s ogni %d %s(s) per %d pagamento(i) then';
$_['text_payment_description'] = '%s ogni %d %s(s) per %d pagamento(i)';
$_['text_payment_cancel']      = '%s ogni %d %s(s) fino alla cancellazione';
$_['text_day']                 = 'giorno';
$_['text_week']                = 'settimana';
$_['text_semi_month']          = 'quindici gg';
$_['text_month']               = 'mese';
$_['text_year']                = 'anno';
$_['text_advbooking_addprdct'] = 'Aggiungi';
$_['text_remain_under_stock']  = '*** solo %s posti disponibili ***';

// Entry
$_['entry_qty']                = 'Qtà';
$_['entry_name']               = 'Il tuo nome';
$_['entry_review']             = 'Tua recensione';
$_['entry_rating']             = 'Rating';
$_['entry_good']               = 'Buono';
$_['entry_bad']                = 'Scadente';

// Tabs
$_['tab_description']          = 'Descrizione';
$_['tab_attribute']            = 'Specifiche';
$_['tab_review']               = 'Recensioni (%s)';

// Error
$_['error_name']               = 'Warning: Review Name must be between 3 and 25 characters!';
$_['error_text']               = 'Warning: Review Text must be between 25 and 1000 characters!';
$_['error_rating']             = 'Warning: Please select a review rating!';

// Alert
$_['alert_max1_overbooking']   = 'La quantità verrà ridotta alla attuale capienza su unica sala (';
$_['alert_max2_overbooking']   = '), telefonare per prenotazioni su più sale';
$_['alert_option_overbooking'] = 'La quantità verrà ridotta alla attuale capienza della sala: ';
$_['alert_today_overtime'] 	   = 'Non è possibile prenotare per questa data';