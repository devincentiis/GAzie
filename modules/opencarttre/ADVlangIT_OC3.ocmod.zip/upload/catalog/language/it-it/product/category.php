<?php
// Text
$_['text_refine']       = 'Raffina ricerca';
$_['text_product']      = 'Prodotti';
$_['text_error']        = 'Categoria non trovata!';
$_['text_no_results']        = 'Non sono presenti prodotti in questa categoria.';
$_['text_quantity']     = 'Q.ta:';
$_['text_manufacturer'] = 'Marca:';
$_['text_model']        = 'Codice prodotto:';
$_['text_points']       = 'Punti:';
$_['text_price']        = 'Prezzo:';
$_['text_tax']          = 'Imposte escluse:';
$_['text_compare']      = 'Compara (%s)';
$_['text_sort']         = 'Ordina per:';
$_['text_default']      = 'Default';
$_['text_name_asc']     = 'Nome (A - Z)';
$_['text_name_desc']    = 'Nome (Z - A)';
$_['text_price_asc']    = 'Prezzo (Low &gt; High)';
$_['text_price_desc']   = 'Price (High &gt; Low)';
$_['text_rating_asc']   = 'Voto (Lowest)';
$_['text_rating_desc']  = 'Voto (Highest)';
$_['text_model_asc']    = 'Modello (A - Z)';
$_['text_model_desc']   = 'Modello (Z - A)';
$_['text_limit']        = 'Visualizza:';