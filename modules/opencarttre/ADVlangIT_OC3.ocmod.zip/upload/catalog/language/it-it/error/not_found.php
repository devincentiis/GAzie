<?php 

$_['heading_title']     =  'Impossibile trovare la pagina che hai richiesto!';
$_['text_error']     =  'Impossibile trovare la pagina che hai richiesto.';
