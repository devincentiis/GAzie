<?php 

$_['text_upload']     =  'Il tuo file &egrave; stato caricato correttamente!';
$_['error_filename']     =  'Nome file must be between 3 and 64 characters!';
$_['error_filetype']     =  'Tipo file non valido!';
$_['error_upload']     =  'Upload richiesto!';
