<?php 

$_['text_title']     =  'PiliExpress';
$_['text_description']     =  'PiliExpress (仅限 霹雳 爸爸 支付, solo per checkout Pilibaba)';
