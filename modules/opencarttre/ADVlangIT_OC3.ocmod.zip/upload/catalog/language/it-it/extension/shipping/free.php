<?php 

$_['text_title']     =  'Spedizione Gratuita';
$_['text_description']     =  'Spedizione Gratuita';
