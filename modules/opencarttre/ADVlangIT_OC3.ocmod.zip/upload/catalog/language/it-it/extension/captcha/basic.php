<?php 

$_['text_captcha']     =  'Captcha';
$_['entry_captcha']     =  'Inserisci il codice nella casella sottostante';
$_['error_captcha']     =  'Il codice di verifica non corrisponde all\'immagine!';
