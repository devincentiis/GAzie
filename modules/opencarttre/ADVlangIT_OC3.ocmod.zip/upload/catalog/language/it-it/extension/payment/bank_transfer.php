<?php
// Text
$_['text_title']       = 'Bonifico Bancario';
$_['text_instruction'] = 'Istruzioni per il Bonifico Bancario';
$_['text_description'] = 'Si prega di trasferire l\'importo totale al seguente conto bancario.';
$_['text_payment']     = 'Non appena riceveremo il pagamento, l\'ordine sar&agrave; evaso.';