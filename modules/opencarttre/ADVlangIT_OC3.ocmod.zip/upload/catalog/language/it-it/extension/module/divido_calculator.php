<?php 

$_['text_checkout_title']     =  'Pagare in rate';
$_['text_choose_plan']     =  'Scegli il tuo piano';
$_['text_choose_deposit']     =  'Scegli il tuo deposito';
$_['text_monthly_payments']     =  'pagamenti mensili di';
$_['text_months']     =  'mesi';
$_['text_term']     =  'Termine';
$_['text_deposit']     =  'Depositare';
$_['text_credit_amount']     =  'Costo del credito';
$_['text_amount_payable']     =  'Totale pagabile';
$_['text_total_interest']     =  'Interesse totale APR';
$_['text_monthly_installment']     =  'Rata mensile';
$_['text_redirection']     =  'Sarai reindirizzato a Divido per completare questa applicazione di finanziamento quando confermerai l\'ordine';
