<?php 

$_['heading_title']     =  'Klarna Checkout';
$_['heading_title_success']     =  'L\'ordine Klarna Checkout è stato messo!';
$_['text_title']     =  'Klarna Checkout';
$_['text_basket']     =  'Carrello';
$_['text_checkout']     =  'Cassa';
$_['text_success']     =  'Successo';
$_['text_choose_shipping_method']     =  'Scegli il metodo di spedizione';
$_['text_sales_tax']     =  'Tassa di vendita';
$_['text_newsletter']     =  'Iscriviti alla nostra Newsletter';
