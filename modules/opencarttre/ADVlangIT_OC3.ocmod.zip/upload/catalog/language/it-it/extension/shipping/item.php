<?php 

$_['text_title']     =  'Per articolo';
$_['text_description']     =  'Tasso di spedizione per elemento';
