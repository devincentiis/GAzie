<?php 

$_['text_title']     =  'PayPal Express Checkout';
$_['text_canceled']     =  'Riuscito: Hai già eseguito con successo questo pagamento!';
$_['button_cancel']     =  'Annulla il pagamento ricorrente';
$_['error_not_cancelled']     =  'Errori';
$_['error_not_found']     =  'Impossibile annullare il profilo ricorrente';
