<?php 

$_['heading_title']     =  'Speciali';
$_['text_tax']     =  'Ex Tax:';
