<?php 

$_['text_title']     =  'Carta di credito o di debito';
$_['text_secure_connection']     =  'Creazione di una connessione protetta ...';
$_['error_connection']     =  'Impossibile connettersi a PayPal. Si prega di contattare l\'amministratore del negozio per l\'assistenza o scegliere un metodo di pagamento diverso.';
