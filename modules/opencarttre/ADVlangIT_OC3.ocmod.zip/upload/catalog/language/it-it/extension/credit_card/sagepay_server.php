<?php 

$_['heading_title']     =  'Schede server Sagepay';
$_['text_no_results']     =  'Non hai carte salvate';
$_['text_account']     =  'account';
$_['text_card']     =  'Gestione della scheda del server SagePay';
$_['text_fail_card']     =  'Si è verificato un problema che rimuove la tua scheda SagePay. Per ulteriori informazioni, contattare l\'amministratore del negozio.';
$_['text_success_card']     =  'La carta SagePay è stata rimossa con successo';
$_['text_success_add_card']     =  'La scheda SagePay è stata aggiunta con successo';
$_['column_type']     =  'Tipo di carta';
$_['column_digits']     =  'Ultime cifre';
$_['column_expiry']     =  'Scadenza';
$_['entry_cc_owner']     =  'Titolare della carta';
$_['entry_cc_type']     =  'Tipo di carta';
$_['entry_cc_number']     =  'Numero di carta';
$_['entry_cc_expire_date']     =  'Data di scadenza della carta';
$_['entry_cc_cvv2']     =  'Codice di sicurezza della carta (CVV2)';
$_['entry_cc_choice']     =  'Scegli una scheda esistente';
$_['button_add_card']     =  'Aggiungi scheda';
$_['button_new_card']     =  'Aggiungi Nuovo Card';
