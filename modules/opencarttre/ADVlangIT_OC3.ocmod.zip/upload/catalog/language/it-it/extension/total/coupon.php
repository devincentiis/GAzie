<?php
// Heading
$_['heading_title'] = 'CODICE PROMOZIONALE';

// Text
$_['text_coupon']   = 'CODICE PROMOZIONALE (%s)';
$_['text_success']  = 'Complimenti: il codice promozionale è stato applicato!';

// Entry
$_['entry_coupon']  = 'Digita qui il codice';

// Error
$_['error_coupon']  = 'Attenzione: il codice promozionale digitato non è valido, è scaduto oppure ha superato il limite di utilizzo!';
$_['error_empty']   = 'Attenzione: per favore digita un codice promozionale!';