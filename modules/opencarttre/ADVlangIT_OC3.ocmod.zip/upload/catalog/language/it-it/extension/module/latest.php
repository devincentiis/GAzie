<?php 

$_['heading_title']     =  'Più recente';
$_['text_tax']     =  'Ex Tax:';
