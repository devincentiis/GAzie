<?php 

$_['text_title']     =  'PayPal';
$_['text_testmode']     =  'Avviso: Il gateway di pagamento è in modalità \'Sandbox\'. Il tuo account non verrà addebitato.';
$_['text_total']     =  'Spedizione, trattare, sconti e imposte';
