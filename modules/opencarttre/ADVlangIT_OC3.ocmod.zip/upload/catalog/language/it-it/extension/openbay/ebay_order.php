<?php 

$_['text_total_shipping']     =  'spedizione';
$_['text_total_discount']     =  'Sconto';
$_['text_total_tax']     =  'Imposta';
$_['text_total_sub']     =  'Totale parziale';
$_['text_total']     =  'Totale';
$_['text_smp_id']     =  'Venditore Manager ID vendita:';
$_['text_buyer']     =  'Nome utente acquirente:';
