<?php 

$_['text_title']     =  'Citylink';
$_['text_weight']     =  'Peso:';
