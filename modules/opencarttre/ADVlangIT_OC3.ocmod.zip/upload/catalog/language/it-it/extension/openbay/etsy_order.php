<?php 

$_['text_total_shipping']     =  'spedizione';
$_['text_total_discount']     =  'Sconto';
$_['text_total_tax']     =  'Imposta';
$_['text_total_sub']     =  'Totale parziale';
$_['text_total']     =  'Totale';
