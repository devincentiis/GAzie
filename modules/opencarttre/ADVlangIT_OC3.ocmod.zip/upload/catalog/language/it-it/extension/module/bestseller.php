<?php 

$_['heading_title']     =  'I più venduti';
$_['text_tax']     =  'Ex Tax:';
