<?php
// Heading
$_['heading_title'] = 'GIFT CARD';

// Text
$_['text_voucher']  = 'GIFT CARD (%s)';
$_['text_success']  = 'Complimenti: la Gift Card è stata applicata con successo!';

// Entry
$_['entry_voucher'] = 'Digita il codice della tua Gift Card';

// Error
$_['error_voucher'] = 'Attenzione: il codice della tua Gift Card non è valido! Riprovare.';
$_['error_empty']   = 'Attenzione: Si prega di inserire il codice della Gift Card!';