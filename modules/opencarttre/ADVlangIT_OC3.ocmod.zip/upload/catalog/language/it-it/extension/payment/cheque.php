<?php 

$_['text_title']     =  'Verifica / ordine di soldi';
$_['text_instruction']     =  'Istruzioni di verifica / soldi';
$_['text_payable']     =  'Fai pagare a:';
$_['text_address']     =  'Inviare a:';
$_['text_payment']     =  'Il tuo ordine non verrà spedito fino a quando non riceviamo il pagamento.';
