<?php
// Heading
$_['heading_title'] = 'Prenotazioni';

// Text
$_['text_tax']      = 'imp.:';