<?php 

$_['text_title']     =  'posta reale';
$_['text_weight']     =  'Peso:';
$_['text_insurance']     =  'Assicurato fino a:';
$_['text_special_delivery']     =  'Consegna speciale il prossimo giorno';
$_['text_1st_class_signed']     =  'Messaggio firmato prima classe';
$_['text_2nd_class_signed']     =  'Messaggio firmato secondo livello';
$_['text_1st_class_standard']     =  'Posto Standard di prima classe';
$_['text_2nd_class_standard']     =  'Secondario di classe standard';
$_['text_international_standard']     =  'Standard internazionale';
$_['text_international_tracked_signed']     =  'International Tracked & Firmato';
$_['text_international_tracked']     =  'Tracciato internazionale';
$_['text_international_signed']     =  'Internazionale firmata';
$_['text_international_economy']     =  'Economia internazionale';
