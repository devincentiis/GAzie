<?php 

$_['heading_title']     =  'Categorie';
