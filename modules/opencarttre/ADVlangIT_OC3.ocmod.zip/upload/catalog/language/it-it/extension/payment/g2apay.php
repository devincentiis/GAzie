<?php 

$_['text_title']     =  'Carta di credito / debito / Paypal / Portafoglio (G2APay)';
