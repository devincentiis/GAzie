<?php 

$_['text_title']     =  'Fedex';
$_['text_weight']     =  'Peso:';
$_['text_eta']     =  'Tempo stimato:';
$_['text_europe_first_international_priority']     =  'Europa prima priorità internazionale';
$_['text_fedex_1_day_freight']     =  'Cargo Fedex 1 Day';
$_['text_fedex_2_day']     =  'Fedex 2 giorni';
$_['text_fedex_2_day_am']     =  'Fedex 2 giorno AM';
$_['text_fedex_2_day_freight']     =  'Trasporto di 2 giorni Fedex';
$_['text_fedex_3_day_freight']     =  'Trasporto Fedex 3 giorni';
$_['text_fedex_express_saver']     =  'Fedex Express Saver';
$_['text_fedex_first_freight']     =  'Fedex First Freight';
$_['text_fedex_freight_economy']     =  'Fedex Freight Economia';
$_['text_fedex_freight_priority']     =  'Priorità del trasporto di Fedex';
$_['text_fedex_ground']     =  'Fedex Ground';
$_['text_first_overnight']     =  'Prima notte';
$_['text_ground_home_delivery']     =  'Consegna a domicilio a terra';
$_['text_international_economy']     =  'Economia internazionale';
$_['text_international_economy_freight']     =  'Trasporto internazionale di economia';
$_['text_international_first']     =  'Prima Internazionale';
$_['text_international_priority']     =  'Priorità internazionale';
$_['text_international_priority_freight']     =  'Trasporto internazionale di priorità';
$_['text_priority_overnight']     =  'Priorità Pernottamento';
$_['text_smart_post']     =  'Smart Post';
$_['text_standard_overnight']     =  'Standard Pernottamento';
