<?php 

$_['text_title']     =  'Carta di credito / carta di debito (Paymate)';
$_['text_unable']     =  'Impossibile individuare o aggiornare lo stato dell\'ordine';
$_['text_declined']     =  'Il pagamento è stato rifiutato da Paymate';
$_['text_failed']     =  'Transazione Paymate non riuscita';
$_['text_failed_message']     =  '<p> Purtroppo si è verificato un errore di elaborazione della transazione Paymate. </p> <p> <b> Avvertenza: </b> %s </p> <p> Verifica l\'equilibrio dell\'account Paymate prima di tentare di rielaborare questo ordine </p> <p> Se ritieni che questa transazione sia stata completata correttamente o che sta visualizzando una deduzione nell\'account Paymate, <a href="%s"> contattaci </a> con i dettagli dell\'ordine. </p>';
$_['text_basket']     =  'Cestino';
$_['text_checkout']     =  'Cassa';
$_['text_success']     =  'Successo';
