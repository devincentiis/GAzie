<?php 

$_['text_title']     =  'Alipay';
