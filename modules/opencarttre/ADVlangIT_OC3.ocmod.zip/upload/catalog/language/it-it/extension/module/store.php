<?php 

$_['heading_title']     =  'Scegli un Negozio';
$_['text_default']     =  'Predefinito';
$_['text_store']     =  'Scegli il negozio che desideri visitare.';
