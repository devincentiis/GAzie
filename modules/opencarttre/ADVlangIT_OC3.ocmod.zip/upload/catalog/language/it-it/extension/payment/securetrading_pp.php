<?php 

$_['text_title']     =  'Carta di credito / debito';
$_['button_confirm']     =  'Conferma password';
$_['text_postcode_check']     =  'Codice Postale check: %s';
$_['text_security_code_check']     =  'Controllo CVV2: %s';
$_['text_address_check']     =  'Controllo indirizzo: %s';
$_['text_not_given']     =  'Non data';
$_['text_not_checked']     =  'Non controllato';
$_['text_match']     =  'Matched';
$_['text_not_match']     =  'Non abbinato';
$_['text_payment_details']     =  'dettagli di pagamento';
$_['entry_card_type']     =  'Tipo di carta';
