<?php 

$_['heading_title']     =  'Use Punti (Available %s)';
$_['text_reward']     =  'Punti (%s)';
$_['text_order_id']     =  'ID Ordine: #%s';
$_['text_success']     =  'Riuscito: è stato applicato il tuo sconto bonus!';
$_['entry_reward']     =  'Punti da utilizzare (Max %s)';
$_['error_reward']     =  'Attenzione: Inserisci l\'importo dei punti di ricompensa da utilizzare!';
$_['error_points']     =  'Avviso: non hai %s punti di ricompensa!';
$_['error_maximum']     =  'Attenzione: il numero massimo di punti applicabili è %s!';
