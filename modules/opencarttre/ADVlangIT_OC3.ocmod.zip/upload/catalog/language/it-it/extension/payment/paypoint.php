<?php 

$_['heading_title']     =  'Grazie per lo shopping con %s ....';
$_['text_title']     =  'Carta di credito / carta di debito (PayPoint)';
$_['text_response']     =  'Risposta da PayPoint:';
$_['text_success']     =  '... il tuo pagamento è stato ricevuto correttamente.';
$_['text_success_wait']     =  '<b> <span style = "color: # FF0000"> Si prega di aspettare ... </span> </b> mentre abbiamo finito di elaborare l\'ordine. <br> Se non si riaccende automaticamente in 10 secondi, fai clic su <a href="%s"> qui </a>.';
$_['text_failure']     =  '... Il tuo pagamento è stato annullato!';
$_['text_failure_wait']     =  '<b> <span style = "color: # FF0000"> Si prega di attendere ... </span> </b> <br> Se non si riaccende automaticamente in 10 secondi, fare clic su <a href = " %s "> qui </a>.';
