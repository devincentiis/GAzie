<?php 

$_['text_credit']     =  'Conserva il credito';
$_['text_order_id']     =  'ID Ordine: #%s';
