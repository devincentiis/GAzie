<?php 

$_['text_title']     =  'Carta di credito / carta di debito (SagePay)';
$_['text_credit_card']     =  'Dettagli della carta di credito';
$_['entry_cc_owner']     =  'Titolare della carta';
$_['entry_cc_number']     =  'Numero di carta';
$_['entry_cc_expire_date']     =  'Data di scadenza della carta';
$_['entry_cc_cvv2']     =  'Codice di sicurezza della carta (CVV2)';
