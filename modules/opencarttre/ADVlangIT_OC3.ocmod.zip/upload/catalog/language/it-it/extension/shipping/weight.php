<?php 

$_['text_title']     =  'Peso basato sul trasporto';
$_['text_weight']     =  'Peso:';
