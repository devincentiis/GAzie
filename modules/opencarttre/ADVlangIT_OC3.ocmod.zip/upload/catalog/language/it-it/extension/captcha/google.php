<?php 

$_['text_captcha']     =  'Captcha';
$_['entry_captcha']     =  'Completa la validazione di captcha qui sotto';
$_['error_captcha']     =  'La verifica non è corretta!';
