<?php 

$_['text_title']     =  'EC-Ship';
$_['text_weight']     =  'Peso:';
$_['text_air_registered_mail']     =  'Posta elettronica registrata';
$_['text_air_parcel']     =  'Pacchetto aria';
$_['text_e_express_service_to_us']     =  'Servizio e-Express per gli Stati Uniti';
$_['text_e_express_service_to_canada']     =  'Servizio e-Express nel Canada';
$_['text_e_express_service_to_united_kingdom']     =  'Servizio e-Express nel Regno Unito';
$_['text_e_express_service_to_russia']     =  'servizio e-Express in Russia';
$_['text_e_express_service_one']     =  'Servizio e-Express';
$_['text_e_express_service_two']     =  'Servizio e-Express';
$_['text_speed_post']     =  'SpeedPost (servizio standard)';
$_['text_smart_post']     =  'Smart Post';
$_['text_local_courier_post']     =  'Corriere Postale Locale (Collezione Contatore)';
$_['text_local_parcel']     =  'Pacchetto locale';
$_['text_unavailable']     =  'Nessun servizio di trasporto disponibile';
