<?php 

$_['heading_title']     =  'Lay-Buy Pagine informative';
$_['text_reference_info']     =  'Reference Pagine informative';
$_['text_laybuy_ref_no']     =  'ID di riferimento Lay-Buy:';
$_['text_paypal_profile_id']     =  'Profilo di PayPal:';
$_['text_payment_plan']     =  'Piano di pagamento';
$_['text_status']     =  'Stato Categoria:';
$_['text_amount']     =  'Quantità:';
$_['text_downpayment_percent']     =  'Pagamento anticipato:';
$_['text_months']     =  'mesi:';
$_['text_downpayment_amount']     =  'Importo anticipato:';
$_['text_payment_amounts']     =  'Importi di pagamento:';
$_['text_first_payment_due']     =  'Primo pagamento dovuto:';
$_['text_last_payment_due']     =  'Ultimo pagamento dovuto:';
$_['text_downpayment']     =  'Acconto';
$_['text_month']     =  'Mese';
$_['column_instalment']     =  'Rata';
$_['column_amount']     =  'Quantità';
$_['column_date']     =  'Data';
$_['column_pp_trans_id']     =  'PayPal ID transazione';
$_['column_status']     =  'Stato Categoria';
