<?php 

$_['text_paid_amazon']     =  'Pagato in Amazon';
$_['text_total_shipping']     =  'spedizione';
$_['text_total_shipping_tax']     =  'Tassa di spedizione';
$_['text_total_giftwrap']     =  'Confezione regalo';
$_['text_total_giftwrap_tax']     =  'Tassa di avvolgere del regalo';
$_['text_total_sub']     =  'Totale parziale';
$_['text_tax']     =  'Imposta';
$_['text_total']     =  'Totale';
$_['text_gift_message']     =  'Messaggi di regalo';
