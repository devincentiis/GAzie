<?php 

$_['heading_title']     =  'Informazioni';
$_['text_contact']     =  'Contattaci';
$_['text_sitemap']     =  'Mappa del sito';
