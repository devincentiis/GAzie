<?php 

$_['heading_title']     =  'In primo piano';
$_['text_tax']     =  'Ex Tax:';
