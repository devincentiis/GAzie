<?php 

$_['text_title']     =  'Pilibaba (霹雳 爸爸 支付)';
$_['text_redirecting']     =  'Reindirizzamento ...';
