<?php 

$_['text_title']     =  'Servizio Postale degli Stati Uniti';
$_['text_weight']     =  'Peso:';
$_['text_eta']     =  'Tempo stimato:';
