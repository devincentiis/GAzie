<?php 

$_['express_text_title']     =  'Conferma password order';
$_['text_title']     =  'PayPal Express Checkout';
$_['text_cart']     =  'Carrello';
$_['text_shipping_updated']     =  'Servizio di spedizione aggiornato';
$_['text_trial']     =  ' %s ogni %s %s per i pagamenti di %s';
$_['text_recurring']     =  ' %s ogni %s %s';
$_['text_recurring_item']     =  'Articolo ricorrente';
$_['text_length']     =  'per i pagamenti di %s';
$_['express_entry_coupon']     =  'Inserisci il tuo coupon qui:';
$_['button_express_coupon']     =  'Inserisci';
$_['button_express_confirm']     =  'Conferma password';
$_['button_express_login']     =  'Continua a PayPal';
$_['button_express_shipping']     =  'Aggiorna spedizione';
$_['error_heading_title']     =  'c\'era un errore';
$_['error_too_many_failures']     =  'Il tuo pagamento è fallito troppe volte';
$_['error_unavailable']     =  'Utilizza l\'assegno completo con questo ordine';
$_['error_no_shipping']     =  'Attenzione: non sono disponibili opzioni di spedizione. <a href="%s"> contattaci </a> per assistenza!';
