<?php 

$_['text_title']     =  'Pagamento alla consegna';
