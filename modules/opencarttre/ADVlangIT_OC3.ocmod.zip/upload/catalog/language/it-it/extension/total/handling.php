<?php
// Text
$_['text_handling'] = 'Spese di Gestione';