<?php 

$_['text_title']     =  'Carta di credito / carta di debito (Payza)';
