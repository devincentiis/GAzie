<?php 

$_['text_title']     =  'Tasso fisso';
$_['text_description']     =  'tariffa di spedizione fissa';
