<?php 

$_['text_title']     =  'Raccogliere';
$_['text_description']     =  'Pickup Dall\'Azienda';
