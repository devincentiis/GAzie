<?php
// Heading
$_['heading_title']    = 'Profilo utente';

// Text
$_['text_register']    = 'Registrati';
$_['text_login']       = 'Accedi';
$_['text_logout']      = 'Esci';
$_['text_forgotten']   = 'Password dimenticata';
$_['text_account']     = 'Profilo';
$_['text_edit']        = 'Modifica Profilo';
$_['text_password']    = 'Password';
$_['text_address']     = 'Indirizzo';
$_['text_wishlist']    = 'Lista dei preferiti';
$_['text_order']       = 'Cronologia ordini';
$_['text_download']    = 'Downloads';
$_['text_reward']      = 'Punti Premio';
$_['text_return']      = 'Resi';
$_['text_transaction'] = 'Transazioni';
$_['text_newsletter']  = 'Newsletter';
$_['text_recurring']   = 'Pagamenti ricorrenti';