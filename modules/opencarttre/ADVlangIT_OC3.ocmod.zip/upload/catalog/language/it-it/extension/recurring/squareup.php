<?php 

$_['text_title']     =  'Piazza';
$_['text_canceled']     =  'Riuscito: l\'utente ha cancellato questo pagamento con successo! Ti abbiamo inviato una e-mail di conferma.';
$_['text_confirm_cancel']     =  'Sei sicuro di cancellare i pagamenti ricorrenti?';
$_['text_order_history_cancel']     =  'Hai annullato il tuo profilo ricorrente. La tua carta non verrà più addebitata.';
$_['button_cancel']     =  'Annulla il pagamento ricorrente';
$_['error_not_cancelled']     =  'Errori';
$_['error_not_found']     =  'Impossibile annullare il profilo ricorrente';
