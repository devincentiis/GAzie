<?php 

$_['heading_title']     =  'Carte di credito quadrate';
$_['text_account']     =  'account';
$_['text_back']     =  'Indietro';
$_['text_delete']     =  'Elimina';
$_['text_no_cards']     =  'Non ci sono schede memorizzate nel nostro database.';
$_['text_card_ends_in']     =  'Scheda %s che termina in &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; %s';
$_['text_warning_card']     =  'Confermi di voler rimuovere questa scheda? Puoi aggiungerlo più tardi alla tua prossima casella.';
$_['text_success_card_delete']     =  'Successo! Questa scheda è stata rimossa.';
