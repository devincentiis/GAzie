<?php 

$_['heading_title']     =  'Sul nostro negozio eBay';
