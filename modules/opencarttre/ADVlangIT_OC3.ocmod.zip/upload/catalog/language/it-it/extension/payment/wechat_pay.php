<?php 

$_['heading_title']     =  'Codice Pay Wechat QR Code';
$_['text_title']     =  'Pay Wechat';
$_['text_checkout']     =  'Cassa';
$_['text_qrcode']     =  'QR Code';
$_['text_qrcode_description']     =  'Scansione del codice QR nell\'applicazione WeChat per pagare il tuo ordine!';
