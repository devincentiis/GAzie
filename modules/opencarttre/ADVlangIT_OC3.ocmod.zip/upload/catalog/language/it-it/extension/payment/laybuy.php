<?php 

$_['heading_title']     =  'Scegli il tuo piano di pagamento';
$_['text_title']     =  'INVIAMO SU LAY-BUY powered by PayPal';
$_['text_plan_preview']     =  'Anteprima piano';
$_['text_payment']     =  'Pagamento';
$_['text_due_date']     =  'Scadenza';
$_['text_amount']     =  'Quantità';
$_['text_downpayment']     =  'Acconto';
$_['text_today']     =  'Oggi';
$_['text_delivery_msg']     =  'I tuoi prodotti / servizi saranno consegnati una volta ricevuto il pagamento finale.';
$_['text_fee_msg']     =  'Una tassa amministrativa del 0,9 %è dovuta a Lay-Buys.com.';
$_['text_month']     =  'Mese';
$_['text_months']     =  'mesi';
$_['text_status_1']     =  'in attesa di';
$_['text_status_5']     =  'Completato';
$_['text_status_7']     =  'Annullato';
$_['text_status_50']     =  'Revise Requested';
$_['text_status_51']     =  'Revised';
$_['text_comment']     =  'Aggiornato da Lay-Buy';
$_['entry_initial']     =  'Pagamento iniziale';
$_['entry_months']     =  'mesi';
$_['button_confirm']     =  'Conferma password Order';
