<?php 

$_['text_title']     =  'Parcelforce 48';
$_['text_description']     =  'Parcelforce 48';
$_['text_weight']     =  'Peso:';
$_['text_insurance']     =  'Assicurato fino a:';
$_['text_time']     =  'Tempo stimato: Entro 48 ore';
